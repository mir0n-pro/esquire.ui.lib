import { Observable } from 'rxjs';
import { EsqDictionaryApi, EsqRestApi, EsqEntityLayer, EsqObjectKind, EsqExplorerCallApi, EsqExplorerHostDummy, EsqValidationError, EsqTreeNode, EsqAccessProfile, SelectMode, EsqExplorerHost, EsqEntityCommandHandler, EsqNodeCommandContext, EsqEntityCommandContext } from '@mir0n-pro/esquire.ui/api';
import * as i0 from '@angular/core';
import { OnInit, OnDestroy, ElementRef, Renderer2, NgZone, AfterViewInit, EventEmitter, QueryList, AfterViewChecked } from '@angular/core';
import { DataSource } from '@angular/cdk/collections';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { MatButton } from '@angular/material/button';
import { MatTabGroup } from '@angular/material/tabs';

declare class EsqDictionary implements EsqDictionaryApi {
    private datastore;
    private loadingMap;
    private restApi;
    private subRequested;
    constructor(restApi: EsqRestApi);
    dictionary(entityKind: number): Observable<EsqEntityLayer[]>;
    dictionaryFromCache(entityKind: number): EsqEntityLayer[];
    _dictionary(entityKind: number): Promise<EsqEntityLayer[]>;
    private loadFromCache;
    private loadDictionary;
}

declare class EsqResizeDirective implements OnInit, OnDestroy {
    private el;
    private renderer;
    private zone;
    resizableTable: HTMLElement | null;
    private startX;
    private startWidth;
    private isResizing;
    private home;
    private sidecontent;
    private resizer;
    private destroy$;
    private sideNavigationMode;
    private activePointerId;
    constructor(el: ElementRef, renderer: Renderer2, zone: NgZone);
    ngOnInit(): void;
    private createResizer;
    private initializeResizeListener;
    private onPointerOver;
    private onPointerDown;
    private onPointerMove;
    private onPointerEnd;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EsqResizeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EsqResizeDirective, "[esqResize]", never, { "resizableTable": { "alias": "resizableTable"; "required": false; }; }, {}, never, never, true, never>;
}

declare class EsqDialogResizeDirective implements AfterViewInit, OnDestroy {
    private el;
    private renderer;
    private zone;
    private static readonly PERSIST_BOUNDS;
    set esqDialogConfig(val: string);
    private _key;
    private _user;
    private pane;
    private destroy$;
    private resizing;
    private activeEdge;
    private startX;
    private startY;
    private startLeft;
    private startTop;
    private startWidth;
    private startHeight;
    private activeHandle;
    private activePointerId;
    constructor(el: ElementRef, renderer: Renderer2, zone: NgZone);
    ngAfterViewInit(): void;
    private init;
    private cookieName;
    private saveState;
    private restoreState;
    private createHandles;
    private addHandlePointerdown;
    private onPointerDown;
    private onPointerMove;
    private onPointerEnd;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EsqDialogResizeDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<EsqDialogResizeDirective, "[esqDialogResize]", never, { "esqDialogConfig": { "alias": "esqDialogResize"; "required": false; }; }, {}, never, never, true, never>;
}

declare class EsqTabStringComponent implements OnInit, AfterViewInit, OnDestroy {
    value: string;
    valueChange: EventEmitter<string>;
    readOnly: boolean;
    maxLength: number;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    ngAfterViewInit(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EsqTabStringComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EsqTabStringComponent, "esq-tab-string", never, { "value": { "alias": "value"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

declare class EsqTabListComponent implements OnInit, AfterViewInit, OnDestroy {
    displayedColumns: string[];
    listElementHoveredIndex: number;
    listElementFocusedIndex: number;
    matRows: QueryList<ElementRef>;
    esqListElements: string[];
    esqListNodeType: EsqObjectKind;
    esqListHeader: string;
    esqEnableAdd: boolean;
    esqEnableRemove: boolean;
    esqEnableSort: boolean;
    esqExplorerCallApi: EsqExplorerCallApi;
    tabListElements: TabListElement[];
    tabListDataSource: DataSource<TabListElement>;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    ngAfterViewInit(): void;
    onListClick(index: number): void;
    onListDoubleClick(index: number): void;
    onListKeydown(event: KeyboardEvent, index: number): void;
    onListArrowdown(index: number): void;
    onListArrowup(index: number): void;
    doSelectListElement(index: number): void;
    canDetailsBtn(): boolean;
    doDetailsBtn(): void;
    canAddBtn(): boolean;
    doAddBtn(): void;
    canUpBtn(): boolean;
    doUpBtn(): void;
    canDownBtn(): boolean;
    doDownBtn(): void;
    canRemoveBtn(): boolean;
    doRemoveBtn(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EsqTabListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EsqTabListComponent, "esq-tab-list", never, { "esqListElements": { "alias": "esqListElements"; "required": false; }; "esqListNodeType": { "alias": "esqListNodeType"; "required": false; }; "esqListHeader": { "alias": "esqListHeader"; "required": false; }; "esqEnableAdd": { "alias": "esqEnableAdd"; "required": false; }; "esqEnableRemove": { "alias": "esqEnableRemove"; "required": false; }; "esqEnableSort": { "alias": "esqEnableSort"; "required": false; }; "esqExplorerCallApi": { "alias": "esqExplorerCallApi"; "required": false; }; }, {}, never, never, true, never>;
}
interface TabListElement {
    id: number;
    sort: number;
    name: string;
    icon: string;
}

declare class EsqEntityDetailsDialog extends EsqExplorerHostDummy implements OnInit, AfterViewInit, AfterViewChecked, OnDestroy {
    btnClose: MatButton;
    btnSave: MatButton;
    tabGroup: MatTabGroup;
    protected dialogRef: MatDialogRef<EsqEntityDetailsDialog>;
    protected restApi: EsqRestApi;
    protected dictionaryApi: EsqDictionaryApi;
    callApi: EsqExplorerCallApi;
    readOnly: boolean;
    userId: string;
    details: any;
    details$: Observable<any> | undefined;
    dictionary$: Observable<EsqEntityLayer[]> | undefined;
    protected dictionary: EsqEntityLayer[];
    protected pendingTabRestore: number | null;
    saving: boolean;
    loading: i0.WritableSignal<boolean>;
    protected originalDetails: any;
    protected needsTreeRefresh: boolean;
    protected givenEntityId: string;
    protected givenEntityKind: number;
    headerIcon: string;
    headerName: string;
    constructor(dialogRef: MatDialogRef<EsqEntityDetailsDialog>, data: any);
    hasChanges(): boolean;
    onClose(): Promise<void>;
    protected treeRefreshResult(): string;
    onSave(): Promise<void>;
    subdictionary(kindId: any): EsqEntityLayer[];
    focusField(error: EsqValidationError): void;
    onRefresh(): void;
    ngOnInit(): void;
    setLoading(loading: boolean): void;
    loadData(restoreTab?: number): void;
    saveData(body: any, restoreTab?: number, treeRefresh?: boolean): void;
    ngOnDestroy(): void;
    ngAfterViewChecked(): void;
    ngAfterViewInit(): void;
    tabContent(title: string): string;
    isCreating(): boolean;
    onCreate(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EsqEntityDetailsDialog, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EsqEntityDetailsDialog, "details-dialog", never, {}, {}, never, never, true, never>;
}

declare class EsqNodeDetailsDialog extends EsqEntityDetailsDialog {
    node: EsqTreeNode;
    constructor(dialogRef: MatDialogRef<EsqNodeDetailsDialog>, data: any);
    nodeStatusIcon(): string;
    nodeTypeName(): string;
    nodeTypeFromFormat(format: string): EsqObjectKind;
    fieldReadOnly(readwrite: number, personal?: string): boolean;
    static ɵfac: i0.ɵɵFactoryDeclaration<EsqNodeDetailsDialog, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EsqNodeDetailsDialog, "details-dialog", never, {}, {}, never, never, true, never>;
}

declare class EsqExplorerCallApiMill {
    dialog: MatDialog;
    dictionaryApi: EsqDictionaryApi;
    restApi: EsqRestApi;
    private host;
    protected lastUserId: string;
    private commandRegistry;
    constructor(dialog: MatDialog, dictionaryApi: EsqDictionaryApi, restApi: EsqRestApi);
    instance(): EsqExplorerCallApi;
    setUserId(userId: string): void;
    protected doEntityCommand(cmd: string, subCmd: string | null, entity_id: string, entity_name: string, entityKind: number, accessProfile: EsqAccessProfile | null, selectMode?: SelectMode): Promise<void>;
    protected getParentEntityId(node: EsqTreeNode): string;
    protected doCreate(node: EsqTreeNode, typeId?: number): Promise<void>;
    protected doNodeCommand(cmd: string, subCmd: string | null, node: EsqTreeNode, accessProfile: EsqAccessProfile | null, selectMode?: SelectMode): Promise<void>;
    confirmDlg(kind: EsqObjectKind | null, header: string, text: string, flag: EsqExplorerCallApi.ConfirmFlag, focus?: number): Promise<number>;
    getHost(): EsqExplorerHost;
    protected esqExplorerCallApi(): EsqExplorerCallApi;
}

declare class EsqConfirmDialog implements AfterViewInit {
    buttons: QueryList<MatButton>;
    protected dialogRef: MatDialogRef<EsqConfirmDialog>;
    kind: EsqObjectKind | null;
    header: string;
    text: string;
    flag: EsqExplorerCallApi.ConfirmFlag;
    focus: number;
    userId: string;
    constructor(dialogRef: MatDialogRef<EsqConfirmDialog>, data: any);
    ngAfterViewInit(): void;
    protected onButtonKeydown(event: KeyboardEvent, idx: number): void;
    onOkYes(): void;
    onNoCancel(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<EsqConfirmDialog, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EsqConfirmDialog, "esq-confirm-dialog", never, {}, {}, never, never, true, never>;
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 04/01/2026 mir0n  initial: command handler registry for calle() dispatcher
*                   added confirmNotImplemented callback for unregistered commands
* 04/17/2026 mir0n  import consolidation
*/

/**
 * Registry for entity command handlers
 * Manages handler registration and command dispatching
 */
declare class EsqCommandHandlerRegistry {
    private handlers;
    private confirmNotImplemented?;
    /**
     * Set callback for handling unregistered commands
     */
    setNotImplementedHandler(callback: (cmd: string) => Promise<void>): void;
    /**
     * Register a command handler
     * Handlers are checked in registration order
     */
    register(handler: EsqEntityCommandHandler): void;
    /**
     * Find the first handler that can process the command
     */
    findHandler(cmd: string): EsqEntityCommandHandler | undefined;
    /**
     * Execute command with node context (from call())
     * Shows "Not implemented" dialog if no handler found
     */
    executeWithNode(cmd: string, context: EsqNodeCommandContext): Promise<void>;
    /**
     * Execute command with entity context (from calle())
     * Shows "Not implemented" dialog if no handler found
     */
    executeWithEntity(cmd: string, context: EsqEntityCommandContext): Promise<void>;
}

declare class EsqTabFieldComponent implements OnInit, AfterViewInit, OnDestroy {
    field: any;
    details: any[];
    callApi: EsqExplorerCallApi;
    readOnly: boolean;
    enableDetails: boolean;
    userId: string;
    constructor();
    ngOnInit(): void;
    ngOnDestroy(): void;
    ngAfterViewInit(): void;
    fieldReadOnly(readwrite: number, personal?: string): boolean;
    clearToNull(field: any): void;
    formatNumber(value: any, format?: string): string;
    parseNumber(formatted: string): number | null;
    onNumberInput(field: any, event: Event): void;
    nodeTypeFromFormat(format: string): EsqObjectKind;
    static ɵfac: i0.ɵɵFactoryDeclaration<EsqTabFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EsqTabFieldComponent, "esq-tab-field", never, { "field": { "alias": "field"; "required": false; }; "details": { "alias": "details"; "required": false; }; "callApi": { "alias": "callApi"; "required": false; }; "readOnly": { "alias": "readOnly"; "required": false; }; "enableDetails": { "alias": "enableDetails"; "required": false; }; "userId": { "alias": "userId"; "required": false; }; }, {}, never, never, true, never>;
}

declare class EsqSingleEntryDialog implements OnInit, AfterViewInit, OnDestroy {
    btnClose: MatButton;
    private dialogRef;
    readOnly: boolean;
    details: any;
    dictionary: EsqEntityLayer[];
    title: string;
    titleIcon: string;
    userId: string;
    constructor(dialogRef: MatDialogRef<EsqSingleEntryDialog>, data: any);
    closeDialog(): void;
    ngOnInit(): void;
    ngOnDestroy(): void;
    ngAfterViewInit(): void;
    tabContent(index: number): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<EsqSingleEntryDialog, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EsqSingleEntryDialog, "details-dialog", never, {}, {}, never, never, true, never>;
}

export { EsqCommandHandlerRegistry, EsqConfirmDialog, EsqDialogResizeDirective, EsqDictionary, EsqEntityDetailsDialog, EsqExplorerCallApiMill, EsqNodeDetailsDialog, EsqResizeDirective, EsqSingleEntryDialog, EsqTabFieldComponent, EsqTabListComponent, EsqTabStringComponent };
export type { TabListElement };
