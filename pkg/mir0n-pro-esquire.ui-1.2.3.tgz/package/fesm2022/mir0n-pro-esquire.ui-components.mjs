import { from, firstValueFrom, Subject, fromEvent, tap, catchError, EMPTY, of, finalize } from 'rxjs';
import { EsqObjectKindFactory, EsqUtils, EsqEntityDictionary, EsqExplorerCallApi, EsqExplorerHostDummy, EsqNodeStatusFactory, EsqTreeNode, SelectMode } from '@mir0n-pro/esquire.ui/api';
import * as i0 from '@angular/core';
import { Input, Directive, EventEmitter, Output, ViewEncapsulation, Component, ElementRef, ViewChildren, signal, HostListener, ViewChild, Inject } from '@angular/core';
import { takeUntil } from 'rxjs/operators';
import * as i7 from '@angular/common';
import { NgClass, CommonModule } from '@angular/common';
import * as i1 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import * as i2 from '@angular/material/button';
import { MatButtonModule, MatButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';
import * as i3 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i4 from '@angular/material/table';
import { MatTableDataSource, MatTableModule, MatRow } from '@angular/material/table';
import * as i1$1 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import * as i4$1 from '@angular/cdk/drag-drop';
import { DragDropModule } from '@angular/cdk/drag-drop';
import * as i5$1 from '@angular/material/toolbar';
import { MatToolbarModule } from '@angular/material/toolbar';
import * as i6 from '@angular/material/tabs';
import { MatTabsModule, MatTabGroup } from '@angular/material/tabs';
import * as i7$1 from '@angular/material/divider';
import { MatDividerModule } from '@angular/material/divider';
import * as i5 from '@angular/material/menu';
import { MatMenuModule } from '@angular/material/menu';
import { MatDivider } from '@angular/material/list';
import { provideNativeDateAdapter } from '@angular/material/core';
import * as i2$1 from '@angular/cdk/text-field';
import { TextFieldModule } from '@angular/cdk/text-field';

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 12/24/2025 mir0n debug log added
* 02/28/2026 mir0n  added loading Set to prevent concurrent duplicate loads
*                   added subRequested flag; proactively loads sub-entity kinds
*                   added dictionaryFromCache() public method
* 03/28/2026 mir0n  loading Set → loadingMap: concurrent callers await the same in-flight Promise
* 04/07/2026 mir0n  entityKind naming (was entity_kind)
* 04/17/2026 mir0n  import consolidation
*/
class EsqDictionary {
    datastore = [];
    loadingMap = new Map();
    restApi;
    subRequested = false;
    constructor(restApi) {
        this.restApi = restApi;
    }
    dictionary(entityKind) {
        if (!this.subRequested) {
            let kindObj = EsqObjectKindFactory.instanceOf(entityKind);
            if (kindObj.usr && !this.subRequested) {
                this.subRequested = true;
                [EsqObjectKindFactory.PERSON_PRIMARY.id, EsqObjectKindFactory.ADDRESS_POSTAL.id, EsqObjectKindFactory.ADDRESS_BIZ.id]
                    .forEach(id => {
                    this._dictionary(id);
                });
            }
        }
        return from(this._dictionary(entityKind));
    }
    dictionaryFromCache(entityKind) {
        return this.loadFromCache(entityKind);
    }
    async _dictionary(entityKind) {
        var ret = this.loadFromCache(entityKind);
        if (ret && ret.length == 0) {
            await this.loadDictionary(entityKind).catch(console.error);
            ret = this.loadFromCache(entityKind);
        }
        EsqUtils.log('_dictionary ', ret);
        return ret;
    }
    loadFromCache(entityKind) {
        var ret = [];
        let found = this.datastore.filter((x) => x.kind == entityKind);
        if (found && found.length > 0) {
            ret = found[0].layers;
        }
        return ret;
    }
    loadDictionary(entityKind) {
        if (this.loadingMap.has(entityKind)) {
            return this.loadingMap.get(entityKind);
        }
        EsqUtils.log('loadDictionary[ ');
        var p = firstValueFrom(this.restApi.esquireDictionary(entityKind))
            .then((_dict) => {
            if (_dict) {
                var dict = new EsqEntityDictionary(entityKind, _dict);
                this.datastore[this.datastore.length] = dict;
            }
            this.loadingMap.delete(entityKind);
            EsqUtils.log(']loadDictionary');
        })
            .catch((err) => {
            this.loadingMap.delete(entityKind);
            console.error(err);
        });
        this.loadingMap.set(entityKind, p);
        return p;
    }
}

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* based on https://dev.to/chintanonweb/mastering-resizable-columns-in-angular-table-a-step-by-step-guide-for-developers-4f5n
*
* History :
* 05/03/2026 mir0n Mobile point device friendly
*/
class EsqResizeDirective {
    el;
    renderer;
    zone;
    resizableTable = null;
    startX;
    startWidth;
    isResizing = false;
    home;
    sidecontent;
    resizer;
    destroy$ = new Subject();
    sideNavigationMode = false;
    activePointerId = null;
    constructor(el, renderer, zone) {
        this.el = el;
        this.renderer = renderer;
        this.zone = zone;
    }
    ngOnInit() {
        const prnt = this.el.nativeElement;
        if (prnt.
            nodeName == 'MAT-SIDENAV-CONTAINER') {
            var sn;
            var sc;
            for (let i = 0; i < prnt.children.length; i++) {
                if (prnt.children[i] instanceof HTMLElement) {
                    if (prnt.children[i].nodeName == 'MAT-SIDENAV') {
                        sn = prnt.children[i];
                    }
                    else if (prnt.children[i].nodeName == 'MAT-SIDENAV-CONTENT') {
                        sc = prnt.children[i];
                    }
                }
            }
            if (sn && sc) {
                this.sideNavigationMode = true;
                this.sidecontent = sc;
                this.home = sn;
            }
        }
        if (!this.home) {
            this.home = prnt;
        }
        this.createResizer();
        this.initializeResizeListener();
    }
    createResizer() {
        this.resizer = this.renderer.createElement('div');
        //this.renderer.addClass(this.resizer, 'column-resizer');
        this.renderer.setStyle(this.resizer, 'position', 'absolute');
        this.renderer.setStyle(this.resizer, 'right', '0');
        this.renderer.setStyle(this.resizer, 'top', '0');
        this.renderer.setStyle(this.resizer, 'width', '8px');
        this.renderer.setStyle(this.resizer, 'cursor', 'col-resize');
        this.renderer.setStyle(this.resizer, 'touch-action', 'none');
        if (this.sideNavigationMode) {
            const h = this.home.offsetHeight;
            this.renderer.setStyle(this.resizer, 'height', `${h}px`);
        }
        else { // for a header column
            this.renderer.setStyle(this.resizer, 'height', '100%');
            //    const h:number = this.home.offsetHeight; 
            //    this.renderer.setStyle(this.resizer, 'height', `${h}px`);
        }
        //this.renderer.createText('.');
        this.renderer.appendChild(this.home, this.resizer);
    }
    initializeResizeListener() {
        this.zone.runOutsideAngular(() => {
            fromEvent(this.resizer, 'pointerdown')
                .pipe(takeUntil(this.destroy$))
                .subscribe((event) => this.onPointerDown(event));
            fromEvent(this.resizer, 'pointerover')
                .pipe(takeUntil(this.destroy$))
                .subscribe((event) => this.onPointerOver(event));
            fromEvent(document, 'pointermove')
                .pipe(takeUntil(this.destroy$))
                .subscribe((event) => this.onPointerMove(event));
            fromEvent(document, 'pointerup')
                .pipe(takeUntil(this.destroy$))
                .subscribe(() => this.onPointerEnd());
            fromEvent(document, 'pointercancel')
                .pipe(takeUntil(this.destroy$))
                .subscribe(() => this.onPointerEnd());
        });
    }
    onPointerOver(event) {
        if (this.isResizing)
            return;
        if (this.sideNavigationMode) {
            const h = this.home.offsetHeight;
            this.renderer.setStyle(this.resizer, 'height', `${h}px`);
        }
        this.renderer.setStyle(this.resizer, 'border-right', '1px solid black');
    }
    onPointerDown(event) {
        event.preventDefault();
        this.isResizing = true;
        this.startX = event.pageX;
        this.startWidth = this.home.offsetWidth;
        this.activePointerId = event.pointerId;
        try {
            this.resizer.setPointerCapture(event.pointerId);
        }
        catch { }
    }
    onPointerMove(event) {
        if (!this.isResizing)
            return;
        const delta = event.pageX - this.startX;
        var width = Math.max(this.startWidth + delta, 10); // just in case it has no min-width defined
        this.renderer.setStyle(this.home, 'width', `${width}px`);
        if (this.sidecontent) {
            width = this.home.offsetWidth;
            this.renderer.setStyle(this.sidecontent, 'margin-left', `${width}px`);
        }
    }
    onPointerEnd() {
        if (!this.isResizing)
            return;
        this.isResizing = false;
        this.renderer.setStyle(this.resizer, 'border-right', '0');
        if (this.activePointerId !== null) {
            try {
                this.resizer.releasePointerCapture(this.activePointerId);
            }
            catch { }
            this.activePointerId = null;
        }
    }
    ngOnDestroy() {
        this.destroy$.next();
        this.destroy$.complete();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqResizeDirective, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.16", type: EsqResizeDirective, isStandalone: true, selector: "[esqResize]", inputs: { resizableTable: "resizableTable" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqResizeDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[esqResize]',
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: i0.NgZone }], propDecorators: { resizableTable: [{
                type: Input
            }] } });

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 03/27/2026 mir0n  initial: Windows-style all-edge resize; [esqDialogResize]="key:user" for cookie-based position/size persistence
* 05/03/2026 mir0n Mobile point device friendly
*/
class EsqDialogResizeDirective {
    el;
    renderer;
    zone;
    // Set to false to globally disable position/size persistence
    static PERSIST_BOUNDS = true;
    // [esqDialogResize]="'key:' + userId"  →  parsed as key:user for persistence
    // esqDialogResize (plain attribute)    →  empty string, no persistence
    set esqDialogConfig(val) {
        var idx = val ? val.indexOf(':') : -1;
        if (idx > 0) {
            this._key = val.substring(0, idx);
            this._user = val.substring(idx + 1);
        }
        else {
            this._key = '';
            this._user = '';
        }
    }
    _key = '';
    _user = '';
    pane;
    destroy$ = new Subject();
    resizing = false;
    activeEdge = '';
    startX = 0;
    startY = 0;
    startLeft = 0;
    startTop = 0;
    startWidth = 0;
    startHeight = 0;
    activeHandle = null;
    activePointerId = null;
    constructor(el, renderer, zone) {
        this.el = el;
        this.renderer = renderer;
        this.zone = zone;
    }
    ngAfterViewInit() {
        setTimeout(() => this.init(), 0);
    }
    init() {
        var el = this.el.nativeElement;
        while (el.parentElement && !el.classList.contains('cdk-overlay-pane')) {
            el = el.parentElement;
        }
        if (!el.classList.contains('cdk-overlay-pane')) {
            return;
        }
        this.pane = el;
        this.renderer.setStyle(this.pane, 'resize', 'none');
        // Establish a CSS stacking context on the pane via transform so handles
        // render above the dialog container immediately — without waiting for
        // cdkDrag to apply its own transform on first drag.
        if (!this.pane.style.transform) {
            this.renderer.setStyle(this.pane, 'transform', 'translate3d(0px, 0px, 0px)');
        }
        this.createHandles();
        this.restoreState();
        this.zone.runOutsideAngular(() => {
            fromEvent(document, 'pointermove')
                .pipe(takeUntil(this.destroy$))
                .subscribe(e => this.onPointerMove(e));
            fromEvent(document, 'pointerup')
                .pipe(takeUntil(this.destroy$))
                .subscribe(() => this.onPointerEnd());
            fromEvent(document, 'pointercancel')
                .pipe(takeUntil(this.destroy$))
                .subscribe(() => this.onPointerEnd());
            // Save position after drag ends (toolbar is the cdkDragHandle)
            this.el.nativeElement.addEventListener('pointerup', () => this.saveState());
        });
    }
    // ── Persistence ─────────────────────────────────────────────────────────────
    cookieName() {
        if (!EsqDialogResizeDirective.PERSIST_BOUNDS)
            return '';
        if (!this._key || !this._user)
            return '';
        return 'esq_dlg_' + this._key + '_' + this._user;
    }
    saveState() {
        var name = this.cookieName();
        if (!name || !this.pane)
            return;
        var r = this.pane.getBoundingClientRect();
        var val = JSON.stringify({ left: Math.round(r.left), top: Math.round(r.top), width: Math.round(r.width), height: Math.round(r.height) });
        var exp = new Date();
        exp.setFullYear(exp.getFullYear() + 1);
        document.cookie = name + '=' + encodeURIComponent(val) + '; path=/; expires=' + exp.toUTCString() + '; SameSite=Lax';
    }
    restoreState() {
        var name = this.cookieName();
        if (!name || !this.pane)
            return;
        var prefix = name + '=';
        var parts = document.cookie.split(';');
        var raw = null;
        for (var i = 0; i < parts.length; i++) {
            var c = parts[i].trim();
            if (c.startsWith(prefix)) {
                raw = decodeURIComponent(c.substring(prefix.length));
                break;
            }
        }
        if (!raw)
            return;
        try {
            var s = JSON.parse(raw);
            this.renderer.setStyle(this.pane, 'position', 'fixed');
            this.renderer.setStyle(this.pane, 'left', s.left + 'px');
            this.renderer.setStyle(this.pane, 'top', s.top + 'px');
            this.renderer.setStyle(this.pane, 'width', s.width + 'px');
            this.renderer.setStyle(this.pane, 'height', s.height + 'px');
            this.renderer.setStyle(this.pane, 'max-width', 'none');
            this.renderer.setStyle(this.pane, 'max-height', 'none');
            this.renderer.setStyle(this.pane, 'transform', 'translate3d(0px, 0px, 0px)');
        }
        catch { }
    }
    // ────────────────────────────────────────────────────────────────────────────
    createHandles() {
        // Edge thickness bumped from 6 -> 10 and corners from 6 -> 14 so a finger can
        // grab them. The 'se' grip stays a touch larger for the visible resize affordance.
        var defs = [
            { edge: 'n', top: '0', left: '10px', right: '10px', bottom: '', width: '', height: '10px', cursor: 'n-resize', cls: '' },
            { edge: 's', top: '', left: '10px', right: '10px', bottom: '0', width: '', height: '10px', cursor: 's-resize', cls: '' },
            { edge: 'e', top: '10px', left: '', right: '0', bottom: '10px', width: '10px', height: '', cursor: 'e-resize', cls: '' },
            { edge: 'w', top: '10px', left: '0', right: '', bottom: '10px', width: '10px', height: '', cursor: 'w-resize', cls: '' },
            { edge: 'ne', top: '0', left: '', right: '0', bottom: '', width: '14px', height: '14px', cursor: 'ne-resize', cls: '' },
            { edge: 'nw', top: '0', left: '0', right: '', bottom: '', width: '14px', height: '14px', cursor: 'nw-resize', cls: '' },
            { edge: 'se', top: '', left: '', right: '0', bottom: '0', width: '16px', height: '16px', cursor: 'se-resize', cls: 'esq-dialog-resize-se' },
            { edge: 'sw', top: '', left: '0', right: '', bottom: '0', width: '14px', height: '14px', cursor: 'sw-resize', cls: '' },
        ];
        for (var i = 0; i < defs.length; i++) {
            var def = defs[i];
            var handle = this.renderer.createElement('div');
            this.renderer.setStyle(handle, 'position', 'absolute');
            this.renderer.setStyle(handle, 'z-index', '1000');
            this.renderer.setStyle(handle, 'cursor', def.cursor);
            this.renderer.setStyle(handle, 'touch-action', 'none');
            if (def.top)
                this.renderer.setStyle(handle, 'top', def.top);
            if (def.left)
                this.renderer.setStyle(handle, 'left', def.left);
            if (def.right)
                this.renderer.setStyle(handle, 'right', def.right);
            if (def.bottom)
                this.renderer.setStyle(handle, 'bottom', def.bottom);
            if (def.width)
                this.renderer.setStyle(handle, 'width', def.width);
            if (def.height)
                this.renderer.setStyle(handle, 'height', def.height);
            if (def.cls)
                this.renderer.addClass(handle, def.cls);
            this.addHandlePointerdown(handle, def.edge);
            this.renderer.appendChild(this.pane, handle);
        }
    }
    addHandlePointerdown(handle, edge) {
        this.zone.runOutsideAngular(() => {
            handle.addEventListener('pointerdown', (e) => this.onPointerDown(e, edge, handle));
        });
    }
    onPointerDown(event, edge, handle) {
        event.preventDefault();
        event.stopPropagation();
        var rect = this.pane.getBoundingClientRect();
        this.startX = event.clientX;
        this.startY = event.clientY;
        this.startLeft = rect.left;
        this.startTop = rect.top;
        this.startWidth = rect.width;
        this.startHeight = rect.height;
        this.renderer.setStyle(this.pane, 'position', 'fixed');
        this.renderer.setStyle(this.pane, 'left', rect.left + 'px');
        this.renderer.setStyle(this.pane, 'top', rect.top + 'px');
        this.renderer.setStyle(this.pane, 'width', rect.width + 'px');
        this.renderer.setStyle(this.pane, 'height', rect.height + 'px');
        this.renderer.setStyle(this.pane, 'transform', 'none');
        this.renderer.setStyle(this.pane, 'max-width', 'none');
        this.renderer.setStyle(this.pane, 'max-height', 'none');
        this.activeEdge = edge;
        this.resizing = true;
        this.activeHandle = handle;
        this.activePointerId = event.pointerId;
        try {
            handle.setPointerCapture(event.pointerId);
        }
        catch { }
    }
    onPointerMove(event) {
        if (!this.resizing) {
            return;
        }
        var dx = event.clientX - this.startX;
        var dy = event.clientY - this.startY;
        var style = window.getComputedStyle(this.pane);
        var minW = parseFloat(style.minWidth) || 100;
        var minH = parseFloat(style.minHeight) || 100;
        if (this.activeEdge.includes('e')) {
            this.renderer.setStyle(this.pane, 'width', Math.max(this.startWidth + dx, minW) + 'px');
        }
        if (this.activeEdge.includes('s')) {
            this.renderer.setStyle(this.pane, 'height', Math.max(this.startHeight + dy, minH) + 'px');
        }
        if (this.activeEdge.includes('w')) {
            var newWidth = Math.max(this.startWidth - dx, minW);
            this.renderer.setStyle(this.pane, 'width', newWidth + 'px');
            this.renderer.setStyle(this.pane, 'left', (this.startLeft + this.startWidth - newWidth) + 'px');
        }
        if (this.activeEdge.includes('n')) {
            var newHeight = Math.max(this.startHeight - dy, minH);
            this.renderer.setStyle(this.pane, 'height', newHeight + 'px');
            this.renderer.setStyle(this.pane, 'top', (this.startTop + this.startHeight - newHeight) + 'px');
        }
    }
    onPointerEnd() {
        if (this.resizing) {
            this.resizing = false;
            this.activeEdge = '';
            if (this.activeHandle && this.activePointerId !== null) {
                try {
                    this.activeHandle.releasePointerCapture(this.activePointerId);
                }
                catch { }
            }
            this.activeHandle = null;
            this.activePointerId = null;
            this.saveState();
        }
    }
    ngOnDestroy() {
        this.destroy$.next();
        this.destroy$.complete();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqDialogResizeDirective, deps: [{ token: i0.ElementRef }, { token: i0.Renderer2 }, { token: i0.NgZone }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.16", type: EsqDialogResizeDirective, isStandalone: true, selector: "[esqDialogResize]", inputs: { esqDialogConfig: ["esqDialogResize", "esqDialogConfig"] }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqDialogResizeDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[esqDialogResize]',
                    standalone: true,
                }]
        }], ctorParameters: () => [{ type: i0.ElementRef }, { type: i0.Renderer2 }, { type: i0.NgZone }], propDecorators: { esqDialogConfig: [{
                type: Input,
                args: ['esqDialogResize']
            }] } });

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 02/01/2026 mir0n EsqTabLStringComponent renamed with EsqTabStringComponent
* 02/17/2026 mir0n made editable with two-way [(value)] binding
*                  added readOnly, maxLength inputs
*/
class EsqTabStringComponent {
    value;
    valueChange = new EventEmitter();
    readOnly = false;
    maxLength = 2000;
    constructor() {
    }
    ngOnInit() {
    }
    ngOnDestroy() {
    }
    ngAfterViewInit() {
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqTabStringComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.16", type: EsqTabStringComponent, isStandalone: true, selector: "esq-tab-string", inputs: { value: "value", readOnly: "readOnly", maxLength: "maxLength" }, outputs: { valueChange: "valueChange" }, ngImport: i0, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<!--    maxlength=\"15\" -->\r\n<div class=\"esq-tab-string-container\"\r\n    [ngClass] = \"{'disabled' : readOnly, 'enabled' : !readOnly}\">\r\n    <textarea\r\n        class = \"esq-tab-string-textarea\"\r\n        [ngClass] = \"{'disabled' : readOnly, 'enabled' : !readOnly}\"\r\n        id = \"text\"\r\n        autofocus\r\n        [readonly]=\"readOnly\"\r\n        [attr.maxlength]=\"maxLength\"\r\n        [(ngModel)]=\"value\"\r\n        (ngModelChange)=\"valueChange.emit($event)\"\r\n    ></textarea>\r\n    \r\n</div>  \r\n", styles: [".esq-tab-string-container{width:100%;height:100%;overflow-y:auto!important;overflow-x:hidden!important;padding:4px;box-shadow:inset 0 2px 3px #0003}.esq-tab-string-container .enabled{background-color:#fff}.esq-tab-string-container .disabled{background-color:#f0f0f0}.esq-tab-string-textarea{width:99%;height:95%;border:none;outline:none;box-sizing:none;resize:none}.esq-tab-string-textarea .enabled{background-color:#fff}.esq-tab-string-textarea .disabled{background-color:#f0f0f0}.esq-tab-string-elevation-z2{-webkit-user-select:none;user-select:none;display:grid;font-size:10pt;font-weight:400;grid-template-columns:auto repeat(5,32px);gap:0px;align-items:center}\n"], dependencies: [{ kind: "directive", type: NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqTabStringComponent, decorators: [{
            type: Component,
            args: [{ selector: 'esq-tab-string', imports: [
                        NgClass,
                        FormsModule
                    ], encapsulation: ViewEncapsulation.None, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<!--    maxlength=\"15\" -->\r\n<div class=\"esq-tab-string-container\"\r\n    [ngClass] = \"{'disabled' : readOnly, 'enabled' : !readOnly}\">\r\n    <textarea\r\n        class = \"esq-tab-string-textarea\"\r\n        [ngClass] = \"{'disabled' : readOnly, 'enabled' : !readOnly}\"\r\n        id = \"text\"\r\n        autofocus\r\n        [readonly]=\"readOnly\"\r\n        [attr.maxlength]=\"maxLength\"\r\n        [(ngModel)]=\"value\"\r\n        (ngModelChange)=\"valueChange.emit($event)\"\r\n    ></textarea>\r\n    \r\n</div>  \r\n", styles: [".esq-tab-string-container{width:100%;height:100%;overflow-y:auto!important;overflow-x:hidden!important;padding:4px;box-shadow:inset 0 2px 3px #0003}.esq-tab-string-container .enabled{background-color:#fff}.esq-tab-string-container .disabled{background-color:#f0f0f0}.esq-tab-string-textarea{width:99%;height:95%;border:none;outline:none;box-sizing:none;resize:none}.esq-tab-string-textarea .enabled{background-color:#fff}.esq-tab-string-textarea .disabled{background-color:#f0f0f0}.esq-tab-string-elevation-z2{-webkit-user-select:none;user-select:none;display:grid;font-size:10pt;font-weight:400;grid-template-columns:auto repeat(5,32px);gap:0px;align-items:center}\n"] }]
        }], ctorParameters: () => [], propDecorators: { value: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], readOnly: [{
                type: Input
            }], maxLength: [{
                type: Input
            }] } });

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 02/12/2026 mir0n  EsqNodeType in explicit file
* 02/13/2026 mir0n  EsqNodeType renamed with EsqObjectKind
* 02/17/2026 mir0n  use CMD_DEFAULT constant from EsqExplorerCallApi
* 04/02/2026 mir0n  calle(): added subCmd, selectMode
* 04/17/2026 mir0n  import consolidation
*/
class EsqTabListComponent {
    displayedColumns = ['name'];
    listElementHoveredIndex = -1;
    listElementFocusedIndex = -1;
    matRows; // Assuming MatRow is a directive applied to your rows
    esqListElements;
    esqListNodeType;
    esqListHeader = '';
    esqEnableAdd = false;
    esqEnableRemove = false;
    esqEnableSort = false;
    esqExplorerCallApi;
    tabListElements = [];
    tabListDataSource;
    constructor() {
        this.tabListDataSource = new MatTableDataSource([]);
    }
    ngOnInit() {
        if (this.esqListElements && this.esqListNodeType) {
            var i = 0;
            this.esqListElements.forEach((x) => {
                this.tabListElements[this.tabListElements.length] = {
                    id: ++i,
                    sort: i,
                    name: x,
                    icon: this.esqListNodeType.icon
                };
            });
            if (this.tabListElements.length > 0) {
                this.listElementFocusedIndex = 0;
                this.tabListDataSource = new MatTableDataSource(this.tabListElements);
            }
        }
    }
    ngOnDestroy() {
        this.tabListDataSource = new MatTableDataSource([]);
        this.tabListElements = [];
    }
    ngAfterViewInit() {
    }
    onListClick(index) {
        this.doSelectListElement(index);
    }
    onListDoubleClick(index) {
        this.doSelectListElement(index);
        this.doDetailsBtn();
    }
    onListKeydown(event, index) {
        switch (event.key) {
            case 'ArrowUp':
                event.preventDefault();
                this.onListArrowup(index);
                break;
            case 'ArrowDown':
                event.preventDefault();
                this.onListArrowdown(index);
                break;
            case 'Enter':
            case ' ': // Spacebar
                event.preventDefault();
                if (this.listElementFocusedIndex >= 0) {
                    this.doSelectListElement(this.listElementFocusedIndex);
                }
                break;
        }
    }
    onListArrowdown(index) {
        var nextIndex = -1;
        if (index < this.tabListElements.length - 1) {
            nextIndex = index + 1;
        }
        if (nextIndex >= 0) {
            this.doSelectListElement(nextIndex);
        }
    }
    onListArrowup(index) {
        var nextIndex = -1;
        if (this.tabListElements.length > 0 && index > 0) {
            nextIndex = index - 1;
        }
        if (nextIndex >= 0) {
            this.doSelectListElement(nextIndex);
        }
    }
    doSelectListElement(index) {
        this.listElementFocusedIndex = index;
        if (index >= 0) {
            setTimeout(() => {
                const nextRows = this.matRows.toArray();
                const nextRowElement = nextRows[index].nativeElement;
                nextRowElement.focus();
            }, 0);
        }
    }
    canDetailsBtn() {
        return this.tabListElements.length > 0 && this.listElementFocusedIndex >= 0
            && this.esqListNodeType && this.esqListNodeType.detailed;
    }
    doDetailsBtn() {
        if (this.esqExplorerCallApi && !!this.esqListNodeType && this.canDetailsBtn()) {
            var el = this.tabListElements[this.listElementFocusedIndex];
            if (el) {
                this.esqExplorerCallApi.calle(EsqExplorerCallApi.CMD_DEFAULT, null, '', el.name, this.esqListNodeType.id, null);
            }
        }
    }
    canAddBtn() {
        return this.esqEnableAdd && this.listElementFocusedIndex >= 0;
    }
    doAddBtn() {
        if (this.canAddBtn()) {
            //do noting for now
        }
    }
    canUpBtn() {
        return this.esqEnableSort && this.listElementFocusedIndex > 0 && this.tabListElements.length > 1;
    }
    doUpBtn() {
        if (this.canUpBtn()) {
            //do noting for now
        }
    }
    canDownBtn() {
        return this.esqEnableSort
            && this.listElementFocusedIndex >= 0 && this.tabListElements.length > 1
            && this.listElementFocusedIndex < this.tabListElements.length - 1;
    }
    doDownBtn() {
        if (this.canDownBtn()) {
            //do noting for now
        }
    }
    canRemoveBtn() {
        return this.esqEnableRemove && this.listElementFocusedIndex >= 0;
    }
    doRemoveBtn() {
        if (this.canRemoveBtn()) {
            //do noting for now
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqTabListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.16", type: EsqTabListComponent, isStandalone: true, selector: "esq-tab-list", inputs: { esqListElements: "esqListElements", esqListNodeType: "esqListNodeType", esqListHeader: "esqListHeader", esqEnableAdd: "esqEnableAdd", esqEnableRemove: "esqEnableRemove", esqEnableSort: "esqEnableSort", esqExplorerCallApi: "esqExplorerCallApi" }, viewQueries: [{ propertyName: "matRows", predicate: MatRow, descendants: true, read: ElementRef }], ngImport: i0, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<div class=\"esq-tab-list-container\">\r\n  <table mat-table\r\n    [dataSource]=\"tabListDataSource\" \r\n    class=\"esq-tab-list\"\r\n  >\r\n    <ng-container matColumnDef=\"name\">\r\n      <th mat-header-cell *matHeaderCellDef class=\"mat-elevation-z2  esq-tab-list-elevation-z5\" >\r\n          <div>{{esqListHeader}}</div>\r\n          <button matIconButton class = \"esq-icon-button\" matTooltip = \"Details\" disabled=\"{{!canDetailsBtn()}}\" (click)=\"doDetailsBtn()\">\r\n            <mat-icon  [ngClass]=\"{'esq-icon-green': canDetailsBtn() }\">check_circle_outline</mat-icon>\r\n          </button>\r\n          <button matIconButton class = \"esq-icon-button\" matTooltip = \"Add\"  disabled=\"{{!canAddBtn()}}\" (click)=\"doAddBtn()\">\r\n            <mat-icon [ngClass]=\"{'esq-icon-green': canAddBtn()}\">add_circle_outline</mat-icon>\r\n          </button>\r\n          <button matIconButton  class = \"esq-icon-button\" matTooltip = \"Move up\"  disabled=\"{{!canUpBtn()}}\" (click)=\"doUpBtn()\">\r\n            <mat-icon [ngClass]=\"{'esq-icon-blue': canUpBtn()}\">arrow_circle_up</mat-icon>\r\n          </button>            \r\n          <button matIconButton class = \"esq-icon-button\" matTooltip = \"Move down\"  disabled=\"{{!canDownBtn()}}\" (click)=\"doDownBtn()\">\r\n            <mat-icon [ngClass]=\"{'esq-icon-blue': canDownBtn()}\">arrow_circle_down</mat-icon>\r\n        </button>\r\n        <button matIconButton class = \"esq-icon-button\" matTooltip = \"Remove\"  disabled=\"{{!canRemoveBtn()}}\" (click)=\"doRemoveBtn()\">\r\n          <mat-icon [ngClass]=\"{'esq-icon-red': canRemoveBtn()}\">remove_circle_outline</mat-icon>\r\n        </button>\r\n        <!-- close_small cancel_presentation cancel close remove_circle_outline-->\r\n      </th>\r\n      <td mat-cell *matCellDef=\"let element\" class=\"mat-cell esq-tab-list-ellipsis-cell\"> \r\n          <span class=\"esq-tab-list-ellipsis-text\">\r\n              <img src=\"{{element.icon}}\" class=\"esq-tab-list-base-icon\"/>\r\n              {{element.name}}\r\n          </span>\r\n      </td>\r\n    </ng-container>\r\n    <tr mat-header-row *matHeaderRowDef=\"displayedColumns; sticky: true\" class=\"mat-header-row esq-tab-list-header-row\"></tr>\r\n    <tr mat-row *matRowDef=\"let row; let i = index; columns: displayedColumns;\" \r\n      class=\"mat-row esq-tab-list-row\"\r\n          [ngClass]=\"{'esq-active-list-highlight': i === listElementFocusedIndex,  'esq-mouse-list-highlight': listElementHoveredIndex === i}\"\r\n          (mouseover)=\"listElementHoveredIndex = i\"\r\n          (mouseout)=\"listElementHoveredIndex = -1\"      \r\n          (click)=\"onListClick(i)\"\r\n          (dblclick)=\"onListDoubleClick(i)\"\r\n          (keydown)=\"onListKeydown($event, i)\"\r\n          [tabindex]=\"i === listElementFocusedIndex ? 0 : -1\"\r\n\r\n    ></tr>\r\n  </table>\r\n</div>  \r\n", styles: [".esq-tab-list-container{width:98%;height:98%;overflow-y:auto!important;overflow-x:hidden!important;background-color:#f5f5f5;padding:4px;box-shadow:inset 0 2px 3px #0003}.esq-tab-list-elevation-z1{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400}.esq-tab-list-elevation-z2{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400;display:grid;grid-template-columns:auto repeat(3,22px);gap:0px;align-items:center}.esq-tab-list-elevation-z5{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400;display:grid;grid-template-columns:auto repeat(5,22px);gap:0px;align-items:center}.esq-icon-button{transform:scale(.75)!important}.esq-icon-green{color:green}.esq-icon-blue{color:#00f}.esq-icon-red{color:red}.esq-tab-list-ellipsis-cell{max-width:24px;overflow:hidden;height:24px!important;-webkit-user-select:none!important;user-select:none!important;border:none}.esq-tab-list-ellipsis-text{white-space:nowrap;height:24px;text-overflow:ellipsis;display:block;width:100%;border:0!important;outline:none!important;box-shadow:none!important}.esq-tab-list-base-icon{position:relative;height:16px;width:16px;vertical-align:middle;bottom:0;left:0}.esq-tab-list-header-row{align-items:center;height:36px;background-color:#f5f5f5}.mat-row .mat-cell{border-bottom:1px solid rgba(0,0,0,.12)}.mat-row:last-child .mat-cell{border-bottom:1px solid rgba(0,0,0,.12)}.esq-tab-list-row{font-size:10pt;font-weight:400;height:24px;background-color:#f5f5f5;border-bottom:none}.esq-active-list-highlight{background-color:#add8e6}.esq-active-list-outlight{background-color:#9df0c7}.esq-mouse-list-highlight{background-color:#e8f5fa}.mat-column-name{width:auto}.mat-header-cell:not(.mat-column-name),.mat-cell:not(.mat-column-name){width:70px;min-width:70px;max-width:70px}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i7.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatTableModule }, { kind: "component", type: i4.MatTable, selector: "mat-table, table[mat-table]", exportAs: ["matTable"] }, { kind: "directive", type: i4.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i4.MatHeaderRowDef, selector: "[matHeaderRowDef]", inputs: ["matHeaderRowDef", "matHeaderRowDefSticky"] }, { kind: "directive", type: i4.MatColumnDef, selector: "[matColumnDef]", inputs: ["matColumnDef"] }, { kind: "directive", type: i4.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i4.MatRowDef, selector: "[matRowDef]", inputs: ["matRowDefColumns", "matRowDefWhen"] }, { kind: "directive", type: i4.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i4.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "component", type: i4.MatHeaderRow, selector: "mat-header-row, tr[mat-header-row]", exportAs: ["matHeaderRow"] }, { kind: "component", type: i4.MatRow, selector: "mat-row, tr[mat-row]", exportAs: ["matRow"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqTabListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'esq-tab-list', imports: [
                        MatButtonModule,
                        MatTooltipModule,
                        MatIcon,
                        CommonModule,
                        MatTableModule
                    ], encapsulation: ViewEncapsulation.None, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<div class=\"esq-tab-list-container\">\r\n  <table mat-table\r\n    [dataSource]=\"tabListDataSource\" \r\n    class=\"esq-tab-list\"\r\n  >\r\n    <ng-container matColumnDef=\"name\">\r\n      <th mat-header-cell *matHeaderCellDef class=\"mat-elevation-z2  esq-tab-list-elevation-z5\" >\r\n          <div>{{esqListHeader}}</div>\r\n          <button matIconButton class = \"esq-icon-button\" matTooltip = \"Details\" disabled=\"{{!canDetailsBtn()}}\" (click)=\"doDetailsBtn()\">\r\n            <mat-icon  [ngClass]=\"{'esq-icon-green': canDetailsBtn() }\">check_circle_outline</mat-icon>\r\n          </button>\r\n          <button matIconButton class = \"esq-icon-button\" matTooltip = \"Add\"  disabled=\"{{!canAddBtn()}}\" (click)=\"doAddBtn()\">\r\n            <mat-icon [ngClass]=\"{'esq-icon-green': canAddBtn()}\">add_circle_outline</mat-icon>\r\n          </button>\r\n          <button matIconButton  class = \"esq-icon-button\" matTooltip = \"Move up\"  disabled=\"{{!canUpBtn()}}\" (click)=\"doUpBtn()\">\r\n            <mat-icon [ngClass]=\"{'esq-icon-blue': canUpBtn()}\">arrow_circle_up</mat-icon>\r\n          </button>            \r\n          <button matIconButton class = \"esq-icon-button\" matTooltip = \"Move down\"  disabled=\"{{!canDownBtn()}}\" (click)=\"doDownBtn()\">\r\n            <mat-icon [ngClass]=\"{'esq-icon-blue': canDownBtn()}\">arrow_circle_down</mat-icon>\r\n        </button>\r\n        <button matIconButton class = \"esq-icon-button\" matTooltip = \"Remove\"  disabled=\"{{!canRemoveBtn()}}\" (click)=\"doRemoveBtn()\">\r\n          <mat-icon [ngClass]=\"{'esq-icon-red': canRemoveBtn()}\">remove_circle_outline</mat-icon>\r\n        </button>\r\n        <!-- close_small cancel_presentation cancel close remove_circle_outline-->\r\n      </th>\r\n      <td mat-cell *matCellDef=\"let element\" class=\"mat-cell esq-tab-list-ellipsis-cell\"> \r\n          <span class=\"esq-tab-list-ellipsis-text\">\r\n              <img src=\"{{element.icon}}\" class=\"esq-tab-list-base-icon\"/>\r\n              {{element.name}}\r\n          </span>\r\n      </td>\r\n    </ng-container>\r\n    <tr mat-header-row *matHeaderRowDef=\"displayedColumns; sticky: true\" class=\"mat-header-row esq-tab-list-header-row\"></tr>\r\n    <tr mat-row *matRowDef=\"let row; let i = index; columns: displayedColumns;\" \r\n      class=\"mat-row esq-tab-list-row\"\r\n          [ngClass]=\"{'esq-active-list-highlight': i === listElementFocusedIndex,  'esq-mouse-list-highlight': listElementHoveredIndex === i}\"\r\n          (mouseover)=\"listElementHoveredIndex = i\"\r\n          (mouseout)=\"listElementHoveredIndex = -1\"      \r\n          (click)=\"onListClick(i)\"\r\n          (dblclick)=\"onListDoubleClick(i)\"\r\n          (keydown)=\"onListKeydown($event, i)\"\r\n          [tabindex]=\"i === listElementFocusedIndex ? 0 : -1\"\r\n\r\n    ></tr>\r\n  </table>\r\n</div>  \r\n", styles: [".esq-tab-list-container{width:98%;height:98%;overflow-y:auto!important;overflow-x:hidden!important;background-color:#f5f5f5;padding:4px;box-shadow:inset 0 2px 3px #0003}.esq-tab-list-elevation-z1{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400}.esq-tab-list-elevation-z2{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400;display:grid;grid-template-columns:auto repeat(3,22px);gap:0px;align-items:center}.esq-tab-list-elevation-z5{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400;display:grid;grid-template-columns:auto repeat(5,22px);gap:0px;align-items:center}.esq-icon-button{transform:scale(.75)!important}.esq-icon-green{color:green}.esq-icon-blue{color:#00f}.esq-icon-red{color:red}.esq-tab-list-ellipsis-cell{max-width:24px;overflow:hidden;height:24px!important;-webkit-user-select:none!important;user-select:none!important;border:none}.esq-tab-list-ellipsis-text{white-space:nowrap;height:24px;text-overflow:ellipsis;display:block;width:100%;border:0!important;outline:none!important;box-shadow:none!important}.esq-tab-list-base-icon{position:relative;height:16px;width:16px;vertical-align:middle;bottom:0;left:0}.esq-tab-list-header-row{align-items:center;height:36px;background-color:#f5f5f5}.mat-row .mat-cell{border-bottom:1px solid rgba(0,0,0,.12)}.mat-row:last-child .mat-cell{border-bottom:1px solid rgba(0,0,0,.12)}.esq-tab-list-row{font-size:10pt;font-weight:400;height:24px;background-color:#f5f5f5;border-bottom:none}.esq-active-list-highlight{background-color:#add8e6}.esq-active-list-outlight{background-color:#9df0c7}.esq-mouse-list-highlight{background-color:#e8f5fa}.mat-column-name{width:auto}.mat-header-cell:not(.mat-column-name),.mat-cell:not(.mat-column-name){width:70px;min-width:70px;max-width:70px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { matRows: [{
                type: ViewChildren,
                args: [MatRow, { read: ElementRef }]
            }], esqListElements: [{
                type: Input
            }], esqListNodeType: [{
                type: Input
            }], esqListHeader: [{
                type: Input
            }], esqEnableAdd: [{
                type: Input
            }], esqEnableRemove: [{
                type: Input
            }], esqEnableSort: [{
                type: Input
            }], esqExplorerCallApi: [{
                type: Input
            }] } });

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 02/04/2026 mir0n  no "entityKind" field anymore
* 02/12/2026 mir0n  EsqNodeType in explicit file
* 02/13/2026 mir0n  EsqNodeType renamed with EsqObjectKind
* 02/17/2026 mir0n  use CMD_DEFAULT constant from EsqExplorerCallApi
* 03/03/2026 mir0n  added esqListElementsChange output; esqAddMenuElements, readonly inputs
*                   addIknElements built from esqAddMenuElements in ngOnInit
*                   canAddBtn(): enabled when esqAddMenuElements has items (not index-based)
*                   canAddMenuItem(): filters already-present and kind-exclusive items
*                   doAddMenuItem(): appends item, emits change, refreshes view, re-focuses
*                   doRemoveBtn(): filter by focused item id (not by index)
*                   canDetailsBtn(): checks kind.detailed flag
*                   Add button wired to MatMenu; all buttons use [disabled] binding
* 03/06/2026 mir0n  ngOnChanges: rebuild list on external esqListElements change (refresh fix)
*                   lastEmitted tracking: skip rebuild when change was self-emitted (add/remove)
*                   buildList() extracted from ngOnInit for reuse
* 04/02/2026 mir0n  calle(): added subCmd, selectMode
* 04/17/2026 mir0n  import consolidation
*/
class EsqTabIknListComponent {
    displayedColumns = ['name'];
    listElementHoveredIndex = -1;
    listElementFocusedIndex = -1;
    matRows; // Assuming MatRow is a directive applied to your rows
    esqListElements;
    esqListElementsChange = new EventEmitter();
    esqAddMenuElements;
    esqListHeader = '';
    readonly = false;
    esqEnableAdd = false;
    esqEnableRemove = false;
    esqEnableSort = false;
    esqEnableDetails = false;
    esqExplorerCallApi;
    tabIknElements = [];
    tabListDataSource;
    addIknElements = [];
    lastEmitted = null;
    constructor() {
        this.tabListDataSource = new MatTableDataSource([]);
    }
    buildList() {
        this.tabIknElements = [];
        this.listElementFocusedIndex = -1;
        if (this.esqListElements) {
            var i = 0;
            this.esqListElements.forEach((x) => {
                this.tabIknElements[this.tabIknElements.length] = {
                    sort: ++i,
                    id: x.id ?? i,
                    name: x.name,
                    kind: x.kind ?? -1,
                    icon: ""
                };
            });
            if (this.tabIknElements.length > 0) {
                this.tabIknElements.forEach((x) => {
                    x.icon = (x.kind < 0) ? "" : EsqObjectKindFactory.instanceOf(x.kind).icon;
                });
                this.listElementFocusedIndex = 0;
            }
            this.tabListDataSource = new MatTableDataSource(this.tabIknElements);
        }
    }
    ngOnInit() {
        this.buildList();
        if (this.esqAddMenuElements && this.esqAddMenuElements.length > 0) {
            this.esqAddMenuElements.forEach((x) => {
                var eok = EsqObjectKindFactory.instanceOf(x.kind);
                this.addIknElements[this.addIknElements.length] = ({
                    sort: 0,
                    id: x.id,
                    name: x.name,
                    kind: x.kind,
                    icon: eok.icon
                });
            });
            if (!this.readonly) {
                this.esqEnableAdd = true;
                this.esqEnableRemove = true;
            }
        }
    }
    ngOnChanges(changes) {
        if (changes['esqListElements'] && !changes['esqListElements'].firstChange) {
            if (this.esqListElements !== this.lastEmitted) {
                this.buildList();
            }
            this.lastEmitted = null;
        }
    }
    ngOnDestroy() {
        this.tabListDataSource = new MatTableDataSource([]);
        this.tabIknElements = [];
    }
    ngAfterViewInit() {
    }
    onListClick(index) {
        this.doSelectListElement(index);
    }
    onListDoubleClick(index) {
        this.doSelectListElement(index);
        this.doDetailsBtn();
    }
    onListKeydown(event, index) {
        switch (event.key) {
            case 'ArrowUp':
                event.preventDefault();
                this.onListArrowup(index);
                break;
            case 'ArrowDown':
                event.preventDefault();
                this.onListArrowdown(index);
                break;
            case 'Enter':
            case ' ': // Spacebar
                event.preventDefault();
                if (this.listElementFocusedIndex >= 0) {
                    this.doSelectListElement(this.listElementFocusedIndex);
                }
                break;
        }
    }
    onListArrowdown(index) {
        var nextIndex = -1;
        if (index < this.tabIknElements.length - 1) {
            nextIndex = index + 1;
        }
        if (nextIndex >= 0) {
            this.doSelectListElement(nextIndex);
        }
    }
    onListArrowup(index) {
        var nextIndex = -1;
        if (this.tabIknElements.length > 0 && index > 0) {
            nextIndex = index - 1;
        }
        if (nextIndex >= 0) {
            this.doSelectListElement(nextIndex);
        }
    }
    doSelectListElement(index) {
        this.listElementFocusedIndex = index;
        if (index >= 0) {
            setTimeout(() => {
                const nextRows = this.matRows.toArray();
                const nextRowElement = nextRows[index].nativeElement;
                nextRowElement.focus();
            }, 0);
        }
    }
    canDetailsBtn() {
        var ret = this.esqEnableDetails
            && this.esqExplorerCallApi
            && this.tabIknElements.length > 0
            && this.listElementFocusedIndex >= 0;
        if (ret) {
            var el = this.tabIknElements[this.listElementFocusedIndex];
            var kind = EsqObjectKindFactory.instanceOf(el.kind);
            ret = kind.detailed;
        }
        return ret;
    }
    doDetailsBtn() {
        if (this.canDetailsBtn()) {
            var el = this.tabIknElements[this.listElementFocusedIndex];
            if (el) {
                this.esqExplorerCallApi.calle(EsqExplorerCallApi.CMD_DEFAULT, null, String(el.id), '', el.kind, null);
            }
        }
    }
    canAddBtn() {
        return this.esqEnableAdd && this.esqAddMenuElements?.length > 0;
    }
    canAddMenuItem(item) {
        var ret = this.esqEnableAdd && this.esqAddMenuElements?.length > 0;
        if (ret) {
            for (var i = 0; i < this.tabIknElements.length; i++) {
                if (this.tabIknElements[i].name == item.name) {
                    ret = false;
                    break;
                }
                //xxx: only one admin role possible : TODO: make is generic
                if (item.kind == 980 && this.tabIknElements[i].kind == 980) {
                    ret = false;
                    break;
                }
            }
        }
        return ret;
    }
    doAddMenuItem(item) {
        var tie = {
            sort: this.tabIknElements.length + 1,
            id: item.id,
            name: item.name,
            kind: item.kind,
            icon: item.icon
        };
        var element = {
            id: item.id,
            name: item.name,
            kind: item.kind
        };
        var next = [...(this.esqListElements ?? []), element];
        this.lastEmitted = next;
        this.esqListElementsChange.emit(next);
        this.tabIknElements.push(tie);
        this.tabListDataSource = new MatTableDataSource(this.tabIknElements);
        this.listElementFocusedIndex = this.tabIknElements.length - 1;
        // Re-focus the new line (optional)
        setTimeout(() => {
            const rows = this.matRows?.toArray?.() ?? [];
            const row = rows[this.listElementFocusedIndex];
            row?.nativeElement?.focus?.();
        }, 0);
    }
    canUpBtn() {
        return this.esqEnableSort && this.listElementFocusedIndex > 0 && this.tabIknElements.length > 1;
    }
    doUpBtn() {
        if (this.canUpBtn()) {
            //do nothing for now
        }
    }
    canDownBtn() {
        return this.esqEnableSort
            && this.listElementFocusedIndex >= 0 && this.tabIknElements.length > 1
            && this.listElementFocusedIndex < this.tabIknElements.length - 1;
    }
    doDownBtn() {
        if (this.canDownBtn()) {
            //do noting for now
        }
    }
    canRemoveBtn() {
        return this.esqEnableRemove && this.listElementFocusedIndex >= 0;
    }
    doRemoveBtn() {
        if (this.canRemoveBtn()) {
            const index = this.listElementFocusedIndex;
            var focused = this.tabIknElements[index];
            // Create a NEW array matched by focused item identity, not by index
            const next = (this.esqListElements ?? []).filter(x => !(x.id === focused.id));
            // Notify parent: this is what usually enables "Save"
            this.lastEmitted = next;
            this.esqListElementsChange.emit(next);
            // Update local view model
            this.tabIknElements.splice(index, 1);
            // Refresh datasource
            this.tabListDataSource = new MatTableDataSource(this.tabIknElements);
            // Fix focus index
            if (this.tabIknElements.length === 0) {
                this.listElementFocusedIndex = -1;
            }
            else {
                this.listElementFocusedIndex = Math.min(index, this.tabIknElements.length - 1);
                // 5) Re-focus the next row (optional)
                setTimeout(() => {
                    const rows = this.matRows?.toArray?.() ?? [];
                    const row = rows[this.listElementFocusedIndex];
                    row?.nativeElement?.focus?.();
                }, 0);
            }
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqTabIknListComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: EsqTabIknListComponent, isStandalone: true, selector: "esq-tab-ikn-list", inputs: { esqListElements: "esqListElements", esqAddMenuElements: "esqAddMenuElements", esqListHeader: "esqListHeader", readonly: "readonly", esqEnableAdd: "esqEnableAdd", esqEnableRemove: "esqEnableRemove", esqEnableSort: "esqEnableSort", esqEnableDetails: "esqEnableDetails", esqExplorerCallApi: "esqExplorerCallApi" }, outputs: { esqListElementsChange: "esqListElementsChange" }, viewQueries: [{ propertyName: "matRows", predicate: MatRow, descendants: true, read: ElementRef }], usesOnChanges: true, ngImport: i0, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<div class=\"esq-tab-list-container\">\r\n  <table mat-table\r\n    [dataSource]=\"tabListDataSource\" \r\n    class=\"esq-tab-list\"\r\n  >\r\n    <ng-container matColumnDef=\"name\">\r\n      <th mat-header-cell *matHeaderCellDef class=\"mat-elevation-z2  esq-tab-list-elevation-z2\" >\r\n          <div>{{esqListHeader}}</div>\r\n          <button matIconButton class = \"esq-icon-button\" matTooltip = \"Details\" [disabled]=\"!canDetailsBtn()\" (click)=\"doDetailsBtn()\">\r\n            <mat-icon  [ngClass]=\"{'esq-icon-green': canDetailsBtn() }\">check_circle_outline</mat-icon>\r\n          </button>\r\n          <button matIconButton class = \"esq-icon-button\" matTooltip = \"Add\"  [disabled]=\"!canAddBtn()\" [matMenuTriggerFor]=\"addMenu\">\r\n            <mat-icon [ngClass]=\"{'esq-icon-green': canAddBtn()}\">add_circle_outline</mat-icon>\r\n          </button>\r\n          <mat-menu #addMenu=\"matMenu\">\r\n            @for (item of addIknElements; track item.id) {\r\n              <button mat-menu-item\r\n                class=\"esq-menu-item\"\r\n                [disabled]=\"!canAddMenuItem(item)\"\r\n                (click)=\"doAddMenuItem(item)\">\r\n                @if (item.kind) {\r\n                  <img [src]=\"item.icon || ''\" class=\"esq-menu-icon\"/>\r\n                }\r\n                {{item.name}}\r\n              </button>\r\n            }\r\n          </mat-menu>\r\n<!--\r\n          <button matIconButton  class = \"esq-icon-button\" matTooltip = \"Move up\"  [disabled]=\"!canUpBtn()\" (click)=\"doUpBtn()\">\r\n            <mat-icon [ngClass]=\"{'esq-icon-blue': canUpBtn()}\">arrow_circle_up</mat-icon>\r\n          </button>            \r\n          <button matIconButton class = \"esq-icon-button\" matTooltip = \"Move down\"  [disabled]=\"!canDownBtn()\" (click)=\"doDownBtn()\">\r\n            <mat-icon [ngClass]=\"{'esq-icon-blue': canDownBtn()}\">arrow_circle_down</mat-icon>\r\n        </button>\r\n-->\r\n        <button matIconButton class = \"esq-icon-button\" matTooltip = \"Remove\"  [disabled]=\"!canRemoveBtn()\" (click)=\"doRemoveBtn()\">\r\n          <mat-icon [ngClass]=\"{'esq-icon-red': canRemoveBtn()}\">remove_circle_outline</mat-icon>\r\n        </button>\r\n        <!-- close_small cancel_presentation cancel close remove_circle_outline-->\r\n      </th>\r\n      <td mat-cell *matCellDef=\"let element\" class=\"mat-cell esq-tab-list-ellipsis-cell\"> \r\n          <span class=\"esq-tab-list-ellipsis-text\">\r\n              @if (element.icon.length > 0) {\r\n                    <img src=\"{{element.icon}}\" class=\"esq-tab-list-base-icon\"/>\r\n              }\r\n              {{element.name}}\r\n          </span>\r\n      </td>\r\n    </ng-container>\r\n    <tr mat-header-row *matHeaderRowDef=\"displayedColumns; sticky: true\" class=\"mat-header-row esq-tab-list-header-row\"></tr>\r\n    <tr mat-row *matRowDef=\"let row; let i = index; columns: displayedColumns;\" \r\n      class=\"mat-row esq-tab-list-row\"\r\n          [ngClass]=\"{'esq-active-list-highlight': i === listElementFocusedIndex,  'esq-mouse-list-highlight': listElementHoveredIndex === i}\"\r\n          (mouseover)=\"listElementHoveredIndex = i\"\r\n          (mouseout)=\"listElementHoveredIndex = -1\"      \r\n          (click)=\"onListClick(i)\"\r\n          (dblclick)=\"onListDoubleClick(i)\"\r\n          (keydown)=\"onListKeydown($event, i)\"\r\n          [tabindex]=\"i === listElementFocusedIndex ? 0 : -1\"\r\n\r\n    ></tr>\r\n  </table>\r\n</div>  \r\n", styles: [".esq-tab-list-container{width:98%;height:98%;overflow-y:auto!important;overflow-x:hidden!important;background-color:#f5f5f5;padding:4px;box-shadow:inset 0 2px 3px #0003}.esq-tab-list-elevation-z1{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400}.esq-tab-list-elevation-z2{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400;display:grid;grid-template-columns:auto repeat(3,22px);gap:0px;align-items:center}.esq-tab-list-elevation-z5{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400;display:grid;grid-template-columns:auto repeat(5,22px);gap:0px;align-items:center}.esq-icon-button{transform:scale(.75)!important}.esq-icon-green{color:green}.esq-icon-blue{color:#00f}.esq-icon-red{color:red}.esq-tab-list-ellipsis-cell{max-width:24px;overflow:hidden;height:24px!important;-webkit-user-select:none!important;user-select:none!important;border:none}.esq-tab-list-ellipsis-text{white-space:nowrap;height:24px;text-overflow:ellipsis;display:block;width:100%;border:0!important;outline:none!important;box-shadow:none!important}.esq-tab-list-base-icon{position:relative;height:16px;width:16px;vertical-align:middle;bottom:0;left:0}.esq-tab-list-header-row{align-items:center;height:36px;background-color:#f5f5f5}.mat-row .mat-cell{border-bottom:1px solid rgba(0,0,0,.12)}.mat-row:last-child .mat-cell{border-bottom:1px solid rgba(0,0,0,.12)}.esq-tab-list-row{font-size:10pt;font-weight:400;height:24px;background-color:#f5f5f5;border-bottom:none}.esq-active-list-highlight{background-color:#add8e6}.esq-active-list-outlight{background-color:#9df0c7}.esq-mouse-list-highlight{background-color:#e8f5fa}.mat-column-name{width:auto}.mat-header-cell:not(.mat-column-name),.mat-cell:not(.mat-column-name){width:70px;min-width:70px;max-width:70px}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i7.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatTableModule }, { kind: "component", type: i4.MatTable, selector: "mat-table, table[mat-table]", exportAs: ["matTable"] }, { kind: "directive", type: i4.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i4.MatHeaderRowDef, selector: "[matHeaderRowDef]", inputs: ["matHeaderRowDef", "matHeaderRowDefSticky"] }, { kind: "directive", type: i4.MatColumnDef, selector: "[matColumnDef]", inputs: ["matColumnDef"] }, { kind: "directive", type: i4.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i4.MatRowDef, selector: "[matRowDef]", inputs: ["matRowDefColumns", "matRowDefWhen"] }, { kind: "directive", type: i4.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i4.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "component", type: i4.MatHeaderRow, selector: "mat-header-row, tr[mat-header-row]", exportAs: ["matHeaderRow"] }, { kind: "component", type: i4.MatRow, selector: "mat-row, tr[mat-row]", exportAs: ["matRow"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i5.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: i5.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i5.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqTabIknListComponent, decorators: [{
            type: Component,
            args: [{ selector: 'esq-tab-ikn-list', imports: [
                        MatButtonModule,
                        MatTooltipModule,
                        MatIcon,
                        CommonModule,
                        MatTableModule,
                        MatMenuModule,
                    ], encapsulation: ViewEncapsulation.None, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<div class=\"esq-tab-list-container\">\r\n  <table mat-table\r\n    [dataSource]=\"tabListDataSource\" \r\n    class=\"esq-tab-list\"\r\n  >\r\n    <ng-container matColumnDef=\"name\">\r\n      <th mat-header-cell *matHeaderCellDef class=\"mat-elevation-z2  esq-tab-list-elevation-z2\" >\r\n          <div>{{esqListHeader}}</div>\r\n          <button matIconButton class = \"esq-icon-button\" matTooltip = \"Details\" [disabled]=\"!canDetailsBtn()\" (click)=\"doDetailsBtn()\">\r\n            <mat-icon  [ngClass]=\"{'esq-icon-green': canDetailsBtn() }\">check_circle_outline</mat-icon>\r\n          </button>\r\n          <button matIconButton class = \"esq-icon-button\" matTooltip = \"Add\"  [disabled]=\"!canAddBtn()\" [matMenuTriggerFor]=\"addMenu\">\r\n            <mat-icon [ngClass]=\"{'esq-icon-green': canAddBtn()}\">add_circle_outline</mat-icon>\r\n          </button>\r\n          <mat-menu #addMenu=\"matMenu\">\r\n            @for (item of addIknElements; track item.id) {\r\n              <button mat-menu-item\r\n                class=\"esq-menu-item\"\r\n                [disabled]=\"!canAddMenuItem(item)\"\r\n                (click)=\"doAddMenuItem(item)\">\r\n                @if (item.kind) {\r\n                  <img [src]=\"item.icon || ''\" class=\"esq-menu-icon\"/>\r\n                }\r\n                {{item.name}}\r\n              </button>\r\n            }\r\n          </mat-menu>\r\n<!--\r\n          <button matIconButton  class = \"esq-icon-button\" matTooltip = \"Move up\"  [disabled]=\"!canUpBtn()\" (click)=\"doUpBtn()\">\r\n            <mat-icon [ngClass]=\"{'esq-icon-blue': canUpBtn()}\">arrow_circle_up</mat-icon>\r\n          </button>            \r\n          <button matIconButton class = \"esq-icon-button\" matTooltip = \"Move down\"  [disabled]=\"!canDownBtn()\" (click)=\"doDownBtn()\">\r\n            <mat-icon [ngClass]=\"{'esq-icon-blue': canDownBtn()}\">arrow_circle_down</mat-icon>\r\n        </button>\r\n-->\r\n        <button matIconButton class = \"esq-icon-button\" matTooltip = \"Remove\"  [disabled]=\"!canRemoveBtn()\" (click)=\"doRemoveBtn()\">\r\n          <mat-icon [ngClass]=\"{'esq-icon-red': canRemoveBtn()}\">remove_circle_outline</mat-icon>\r\n        </button>\r\n        <!-- close_small cancel_presentation cancel close remove_circle_outline-->\r\n      </th>\r\n      <td mat-cell *matCellDef=\"let element\" class=\"mat-cell esq-tab-list-ellipsis-cell\"> \r\n          <span class=\"esq-tab-list-ellipsis-text\">\r\n              @if (element.icon.length > 0) {\r\n                    <img src=\"{{element.icon}}\" class=\"esq-tab-list-base-icon\"/>\r\n              }\r\n              {{element.name}}\r\n          </span>\r\n      </td>\r\n    </ng-container>\r\n    <tr mat-header-row *matHeaderRowDef=\"displayedColumns; sticky: true\" class=\"mat-header-row esq-tab-list-header-row\"></tr>\r\n    <tr mat-row *matRowDef=\"let row; let i = index; columns: displayedColumns;\" \r\n      class=\"mat-row esq-tab-list-row\"\r\n          [ngClass]=\"{'esq-active-list-highlight': i === listElementFocusedIndex,  'esq-mouse-list-highlight': listElementHoveredIndex === i}\"\r\n          (mouseover)=\"listElementHoveredIndex = i\"\r\n          (mouseout)=\"listElementHoveredIndex = -1\"      \r\n          (click)=\"onListClick(i)\"\r\n          (dblclick)=\"onListDoubleClick(i)\"\r\n          (keydown)=\"onListKeydown($event, i)\"\r\n          [tabindex]=\"i === listElementFocusedIndex ? 0 : -1\"\r\n\r\n    ></tr>\r\n  </table>\r\n</div>  \r\n", styles: [".esq-tab-list-container{width:98%;height:98%;overflow-y:auto!important;overflow-x:hidden!important;background-color:#f5f5f5;padding:4px;box-shadow:inset 0 2px 3px #0003}.esq-tab-list-elevation-z1{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400}.esq-tab-list-elevation-z2{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400;display:grid;grid-template-columns:auto repeat(3,22px);gap:0px;align-items:center}.esq-tab-list-elevation-z5{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400;display:grid;grid-template-columns:auto repeat(5,22px);gap:0px;align-items:center}.esq-icon-button{transform:scale(.75)!important}.esq-icon-green{color:green}.esq-icon-blue{color:#00f}.esq-icon-red{color:red}.esq-tab-list-ellipsis-cell{max-width:24px;overflow:hidden;height:24px!important;-webkit-user-select:none!important;user-select:none!important;border:none}.esq-tab-list-ellipsis-text{white-space:nowrap;height:24px;text-overflow:ellipsis;display:block;width:100%;border:0!important;outline:none!important;box-shadow:none!important}.esq-tab-list-base-icon{position:relative;height:16px;width:16px;vertical-align:middle;bottom:0;left:0}.esq-tab-list-header-row{align-items:center;height:36px;background-color:#f5f5f5}.mat-row .mat-cell{border-bottom:1px solid rgba(0,0,0,.12)}.mat-row:last-child .mat-cell{border-bottom:1px solid rgba(0,0,0,.12)}.esq-tab-list-row{font-size:10pt;font-weight:400;height:24px;background-color:#f5f5f5;border-bottom:none}.esq-active-list-highlight{background-color:#add8e6}.esq-active-list-outlight{background-color:#9df0c7}.esq-mouse-list-highlight{background-color:#e8f5fa}.mat-column-name{width:auto}.mat-header-cell:not(.mat-column-name),.mat-cell:not(.mat-column-name){width:70px;min-width:70px;max-width:70px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { matRows: [{
                type: ViewChildren,
                args: [MatRow, { read: ElementRef }]
            }], esqListElements: [{
                type: Input
            }], esqListElementsChange: [{
                type: Output
            }], esqAddMenuElements: [{
                type: Input
            }], esqListHeader: [{
                type: Input
            }], readonly: [{
                type: Input
            }], esqEnableAdd: [{
                type: Input
            }], esqEnableRemove: [{
                type: Input
            }], esqEnableSort: [{
                type: Input
            }], esqEnableDetails: [{
                type: Input
            }], esqExplorerCallApi: [{
                type: Input
            }] } });

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 02/04/2026 mir0n  no "entityKind" field anymore
* 02/12/2026 mir0n  EsqNodeType in explicit file
* 02/13/2026 mir0n  EsqNodeType renamed with EsqObjectKind
* 04/17/2026 mir0n  import consolidation
*/
class EsqTabIknfTableComponent {
    displayedColumns = ['name'];
    listElementHoveredIndex = -1;
    listElementFocusedIndex = -1;
    matRows; // Assuming MatRow is a directive applied to your rows
    esqListElements;
    esqListHeader = '';
    tabIknfElements = [];
    tabIknfDataSource;
    listColumns = [];
    listColumnsDisplayed = [];
    constructor() {
        this.tabIknfDataSource = new MatTableDataSource([]);
    }
    ngOnInit() {
        if (this.esqListElements) {
            var i = 0;
            this.esqListElements.forEach((x) => {
                this.tabIknfElements[this.tabIknfElements.length] = {
                    sort: ++i,
                    id: x.id ?? i,
                    kind: x.kind ?? -1,
                    icon: "",
                    name: x.name,
                    flag0: (x.flags?.[0]?.trim() ? x.flags[0] : "N"),
                    flag1: (x.flags?.[1]?.trim() ? x.flags[1] : "N"),
                    flag2: (x.flags?.[2]?.trim() ? x.flags[2] : "N"),
                    flag3: (x.flags?.[3]?.trim() ? x.flags[3] : "N"),
                    flag4: (x.flags?.[4]?.trim() ? x.flags[4] : "N"),
                    flag5: (x.flags?.[5]?.trim() ? x.flags[5] : "N"),
                    flag6: (x.flags?.[6]?.trim() ? x.flags[6] : "N"),
                    flag7: (x.flags?.[7]?.trim() ? x.flags[7] : "N"),
                };
            });
            if (this.tabIknfElements.length > 0) {
                this.tabIknfElements.forEach((x) => {
                    x.icon = (x.kind < 0) ? "" : EsqObjectKindFactory.instanceOf(x.kind).icon;
                });
                this.listElementFocusedIndex = 0;
                this.tabIknfDataSource = new MatTableDataSource(this.tabIknfElements);
            }
        }
        const headersArray = (this.esqListHeader ?? '')
            .split(/[,\n;]+/)
            .map(h => h.trim())
            .filter(Boolean);
        for (const header of headersArray) {
            var i = this.listColumns.length;
            if (i == 0) {
                this.listColumns[i] = { columnDef: 'name', header: header };
                this.listColumnsDisplayed[i] = 'name';
            }
            else {
                this.listColumns[i] = { columnDef: 'flag' + (i - 1), header: header };
                this.listColumnsDisplayed[i] = 'flag' + (i - 1);
            }
        }
    }
    ngOnDestroy() {
        this.tabIknfDataSource = new MatTableDataSource([]);
        this.tabIknfElements = [];
    }
    ngAfterViewInit() {
    }
    onListClick(index) {
        this.doSelectListElement(index);
    }
    onListKeydown(event, index) {
        switch (event.key) {
            case 'ArrowUp':
                event.preventDefault();
                this.onListArrowup(index);
                break;
            case 'ArrowDown':
                event.preventDefault();
                this.onListArrowdown(index);
                break;
        }
    }
    onListArrowdown(index) {
        var nextIndex = -1;
        if (index < this.tabIknfElements.length - 1) {
            nextIndex = index + 1;
        }
        if (nextIndex >= 0) {
            this.doSelectListElement(nextIndex);
        }
    }
    onListArrowup(index) {
        var nextIndex = -1;
        if (this.tabIknfElements.length > 0 && index > 0) {
            nextIndex = index - 1;
        }
        if (nextIndex >= 0) {
            this.doSelectListElement(nextIndex);
        }
    }
    doSelectListElement(index) {
        this.listElementFocusedIndex = index;
        if (index >= 0) {
            setTimeout(() => {
                const nextRows = this.matRows.toArray();
                const nextRowElement = nextRows[index].nativeElement;
                nextRowElement.focus();
            }, 0);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqTabIknfTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: EsqTabIknfTableComponent, isStandalone: true, selector: "esq-tab-iknf-table", inputs: { esqListElements: "esqListElements", esqListHeader: "esqListHeader" }, viewQueries: [{ propertyName: "matRows", predicate: MatRow, descendants: true, read: ElementRef }], ngImport: i0, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<div class=\"esq-tab-list-container\">\r\n    <table mat-table\r\n       [dataSource]=\"tabIknfDataSource\"\r\n       class=\"esq-tab-list\"\r\n    >\r\n        @for (column of listColumns; track column.columnDef; let i = $index) {\r\n            <ng-container [matColumnDef]=\"column.columnDef!\" >\r\n                <th mat-header-cell *matHeaderCellDef  esqResize class=\"mat-elevation-z2 esq-tab-list-elevation-z1\">\r\n                    {{column.header}}\r\n                </th>\r\n                <td mat-cell *matCellDef=\"let element\" class=\"mat-cell esq-tab-list-ellipsis-cell\">\r\n                    @if (column.columnDef === 'name') {\r\n                        <span class=\"esq-tab-list-ellipsis-text\">\r\n                            @if (element.icon.length > 0) {\r\n                                <img src=\"{{element.icon}}\" class=\"esq-tab-list-base-icon\"/>\r\n                            }\r\n                            {{element.name}}\r\n                        </span>\r\n                    } @else {\r\n                        <span class=\"esq-tab-list-ellipsis-text\">\r\n                            {{element[column.columnDef!] }}\r\n                        </span>\r\n                    }\r\n                </td>\r\n            </ng-container>\r\n        }\r\n        <tr mat-header-row\r\n            *matHeaderRowDef=\"listColumnsDisplayed; sticky: true\"\r\n            class=\"mat-header-row esq-tab-list-header-row\">\r\n        </tr>\r\n        <tr mat-row\r\n            *matRowDef=\"let node; let i = index; columns: listColumnsDisplayed;\"\r\n            class=\"mat-row esq-tab-list-row\"\r\n            [ngClass]=\"{'esq-active-list-highlight': i === listElementFocusedIndex,  'esq-mouse-list-highlight': listElementHoveredIndex === i}\"\r\n            (mouseover)=\"listElementHoveredIndex = i\"\r\n            (mouseout)=\"listElementHoveredIndex = -1\"\r\n            (click)=\"onListClick(i)\"\r\n            (keydown)=\"onListKeydown($event, i)\"\r\n            [tabindex]=\"i === listElementFocusedIndex ? 0 : -1\"\r\n        >\r\n        </tr>\r\n    </table>\r\n\r\n</div>  \r\n", styles: [".esq-tab-list-container{width:98%;height:98%;overflow-y:auto!important;overflow-x:hidden!important;background-color:#f5f5f5;padding:4px;box-shadow:inset 0 2px 3px #0003}.esq-tab-list-elevation-z1{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400}.esq-tab-list-elevation-z2{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400;display:grid;grid-template-columns:auto repeat(3,22px);gap:0px;align-items:center}.esq-tab-list-elevation-z5{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400;display:grid;grid-template-columns:auto repeat(5,22px);gap:0px;align-items:center}.esq-icon-button{transform:scale(.75)!important}.esq-icon-green{color:green}.esq-icon-blue{color:#00f}.esq-icon-red{color:red}.esq-tab-list-ellipsis-cell{max-width:24px;overflow:hidden;height:24px!important;-webkit-user-select:none!important;user-select:none!important;border:none}.esq-tab-list-ellipsis-text{white-space:nowrap;height:24px;text-overflow:ellipsis;display:block;width:100%;border:0!important;outline:none!important;box-shadow:none!important}.esq-tab-list-base-icon{position:relative;height:16px;width:16px;vertical-align:middle;bottom:0;left:0}.esq-tab-list-header-row{align-items:center;height:36px;background-color:#f5f5f5}.mat-row .mat-cell{border-bottom:1px solid rgba(0,0,0,.12)}.mat-row:last-child .mat-cell{border-bottom:1px solid rgba(0,0,0,.12)}.esq-tab-list-row{font-size:10pt;font-weight:400;height:24px;background-color:#f5f5f5;border-bottom:none}.esq-active-list-highlight{background-color:#add8e6}.esq-active-list-outlight{background-color:#9df0c7}.esq-mouse-list-highlight{background-color:#e8f5fa}.mat-column-name{width:auto}.mat-header-cell:not(.mat-column-name),.mat-cell:not(.mat-column-name){width:70px;min-width:70px;max-width:70px}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i7.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatTableModule }, { kind: "component", type: i4.MatTable, selector: "mat-table, table[mat-table]", exportAs: ["matTable"] }, { kind: "directive", type: i4.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i4.MatHeaderRowDef, selector: "[matHeaderRowDef]", inputs: ["matHeaderRowDef", "matHeaderRowDefSticky"] }, { kind: "directive", type: i4.MatColumnDef, selector: "[matColumnDef]", inputs: ["matColumnDef"] }, { kind: "directive", type: i4.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i4.MatRowDef, selector: "[matRowDef]", inputs: ["matRowDefColumns", "matRowDefWhen"] }, { kind: "directive", type: i4.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i4.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "component", type: i4.MatHeaderRow, selector: "mat-header-row, tr[mat-header-row]", exportAs: ["matHeaderRow"] }, { kind: "component", type: i4.MatRow, selector: "mat-row, tr[mat-row]", exportAs: ["matRow"] }, { kind: "directive", type: EsqResizeDirective, selector: "[esqResize]", inputs: ["resizableTable"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqTabIknfTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'esq-tab-iknf-table', imports: [
                        MatButtonModule,
                        MatTooltipModule,
                        CommonModule,
                        MatTableModule,
                        EsqResizeDirective,
                    ], encapsulation: ViewEncapsulation.None, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<div class=\"esq-tab-list-container\">\r\n    <table mat-table\r\n       [dataSource]=\"tabIknfDataSource\"\r\n       class=\"esq-tab-list\"\r\n    >\r\n        @for (column of listColumns; track column.columnDef; let i = $index) {\r\n            <ng-container [matColumnDef]=\"column.columnDef!\" >\r\n                <th mat-header-cell *matHeaderCellDef  esqResize class=\"mat-elevation-z2 esq-tab-list-elevation-z1\">\r\n                    {{column.header}}\r\n                </th>\r\n                <td mat-cell *matCellDef=\"let element\" class=\"mat-cell esq-tab-list-ellipsis-cell\">\r\n                    @if (column.columnDef === 'name') {\r\n                        <span class=\"esq-tab-list-ellipsis-text\">\r\n                            @if (element.icon.length > 0) {\r\n                                <img src=\"{{element.icon}}\" class=\"esq-tab-list-base-icon\"/>\r\n                            }\r\n                            {{element.name}}\r\n                        </span>\r\n                    } @else {\r\n                        <span class=\"esq-tab-list-ellipsis-text\">\r\n                            {{element[column.columnDef!] }}\r\n                        </span>\r\n                    }\r\n                </td>\r\n            </ng-container>\r\n        }\r\n        <tr mat-header-row\r\n            *matHeaderRowDef=\"listColumnsDisplayed; sticky: true\"\r\n            class=\"mat-header-row esq-tab-list-header-row\">\r\n        </tr>\r\n        <tr mat-row\r\n            *matRowDef=\"let node; let i = index; columns: listColumnsDisplayed;\"\r\n            class=\"mat-row esq-tab-list-row\"\r\n            [ngClass]=\"{'esq-active-list-highlight': i === listElementFocusedIndex,  'esq-mouse-list-highlight': listElementHoveredIndex === i}\"\r\n            (mouseover)=\"listElementHoveredIndex = i\"\r\n            (mouseout)=\"listElementHoveredIndex = -1\"\r\n            (click)=\"onListClick(i)\"\r\n            (keydown)=\"onListKeydown($event, i)\"\r\n            [tabindex]=\"i === listElementFocusedIndex ? 0 : -1\"\r\n        >\r\n        </tr>\r\n    </table>\r\n\r\n</div>  \r\n", styles: [".esq-tab-list-container{width:98%;height:98%;overflow-y:auto!important;overflow-x:hidden!important;background-color:#f5f5f5;padding:4px;box-shadow:inset 0 2px 3px #0003}.esq-tab-list-elevation-z1{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400}.esq-tab-list-elevation-z2{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400;display:grid;grid-template-columns:auto repeat(3,22px);gap:0px;align-items:center}.esq-tab-list-elevation-z5{-webkit-user-select:none;user-select:none;font-size:10pt;font-weight:400;display:grid;grid-template-columns:auto repeat(5,22px);gap:0px;align-items:center}.esq-icon-button{transform:scale(.75)!important}.esq-icon-green{color:green}.esq-icon-blue{color:#00f}.esq-icon-red{color:red}.esq-tab-list-ellipsis-cell{max-width:24px;overflow:hidden;height:24px!important;-webkit-user-select:none!important;user-select:none!important;border:none}.esq-tab-list-ellipsis-text{white-space:nowrap;height:24px;text-overflow:ellipsis;display:block;width:100%;border:0!important;outline:none!important;box-shadow:none!important}.esq-tab-list-base-icon{position:relative;height:16px;width:16px;vertical-align:middle;bottom:0;left:0}.esq-tab-list-header-row{align-items:center;height:36px;background-color:#f5f5f5}.mat-row .mat-cell{border-bottom:1px solid rgba(0,0,0,.12)}.mat-row:last-child .mat-cell{border-bottom:1px solid rgba(0,0,0,.12)}.esq-tab-list-row{font-size:10pt;font-weight:400;height:24px;background-color:#f5f5f5;border-bottom:none}.esq-active-list-highlight{background-color:#add8e6}.esq-active-list-outlight{background-color:#9df0c7}.esq-mouse-list-highlight{background-color:#e8f5fa}.mat-column-name{width:auto}.mat-header-cell:not(.mat-column-name),.mat-cell:not(.mat-column-name){width:70px;min-width:70px;max-width:70px}\n"] }]
        }], ctorParameters: () => [], propDecorators: { matRows: [{
                type: ViewChildren,
                args: [MatRow, { read: ElementRef }]
            }], esqListElements: [{
                type: Input
            }], esqListHeader: [{
                type: Input
            }] } });

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 02/12/2026 mir0n  EsqNodeType in explicit file
* 02/13/2026 mir0n  EsqNodeType renamed with EsqObjectKind
* 02/17/2026 mir0n  added field types: flag, number, string with listvalues
*                   added fieldReadOnly with personal flag support
*                   String() coercion for id/userId comparison
*                   added nullable/nullmeaning handling
*                   added clearToNull, formatNumber, onNumberInput
*                   added tooltip support via field.tooltip
*                   added data-field attributes on all inputs
* 03/01/2026 mir0n  added provideNativeDateAdapter() provider
* 03/03/2026 mir0n  added TextFieldModule for cdkTextareaAutosize (text field type)
* 04/17/2026 mir0n  import consolidation
*/
class EsqTabFieldComponent {
    field; //EsqEntityField
    details = []; //EsqEntity/EsqAcessProfile
    callApi;
    readOnly = true;
    enableDetails = true;
    userId = "";
    constructor() {
    }
    ngOnInit() {
    }
    ngOnDestroy() {
    }
    ngAfterViewInit() {
    }
    fieldReadOnly(readwrite, personal) {
        var ret = true;
        if (String(this.details?.["id"]) === String(this.userId)) {
            // "personal" mode: only applicable fields
            ret = !("Y" === personal && readwrite == 3);
        }
        else {
            ret = this.readOnly || readwrite < 3;
        }
        return ret;
    }
    clearToNull(field) {
        //this.details[field.name] = '';
        this.details[field.name] = null;
    }
    formatNumber(value, format) {
        return EsqUtils.formatNumber(value, format);
    }
    parseNumber(formatted) {
        return EsqUtils.parseNumber(formatted);
    }
    onNumberInput(field, event) {
        const input = event.target;
        const parsed = this.parseNumber(input.value);
        if (parsed !== null) {
            this.details[field.name] = parsed;
        }
    }
    nodeTypeFromFormat(format) {
        var id = -1; //unknown
        if (format) {
            var ftype = format.split('=');
            if (ftype.length > 1 && ftype[0] == 'kind') {
                id = Number(ftype[1]);
            }
        }
        return EsqObjectKindFactory.instanceOf(id);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqTabFieldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: EsqTabFieldComponent, isStandalone: true, selector: "esq-tab-field", inputs: { field: "field", details: "details", callApi: "callApi", readOnly: "readOnly", enableDetails: "enableDetails", userId: "userId" }, providers: [provideNativeDateAdapter()], ngImport: i0, template: "<!--\r\n  Esquire frameworks (tm)\r\n\r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n    @if (field.type == 'tab-ikn-list') {\r\n        <esq-tab-ikn-list\r\n            [esqListElements]=\"details[field.name]\"\r\n            (esqListElementsChange)=\"details[field.name] = $event\"\r\n            [esqAddMenuElements]=\"($any(details)[(field.name ?? '') + 'All'] ?? [])\"\r\n            [esqListHeader]=\"field.label\"\r\n            [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n            [esqExplorerCallApi]=\"callApi\"\r\n            [esqEnableDetails]=\"enableDetails\"\r\n        />\r\n    } @else if (field.type === 'tab-iknf-table') {\r\n        <esq-tab-iknf-table\r\n            [esqListElements]=\"details[field.name]\"\r\n            [esqListHeader]=\"field.label\"\r\n        />\r\n    } @else if (field.type == 'image') {\r\n        <div class=\"esq-tab-image-container\">\r\n            <img class=\"esq-tab-image\" [src]=\"details[field.name]\" [alt]=\"details[field.name]\" />\r\n        </div>\r\n        <mat-divider></mat-divider>\r\n    } @else if (field.type == 'href') {\r\n        <div class=\"esq-simple-grid2\">\r\n            <b>{{field.label}}:</b>\r\n            <a href=\"{{details[field.name][0]}}\" target=\"_blank\" rel=\"noopener noreferrer\">\r\n                {{details[field.name][1]}}\r\n            </a>\r\n        </div>\r\n    } @else if (field.type == 'tablist') {\r\n        <esq-tab-list\r\n            [esqListElements]=\"details[field.name]\"\r\n            [esqListNodeType]=\"nodeTypeFromFormat(field.format)\"\r\n            [esqListHeader]=\"field.label\"\r\n            [esqExplorerCallApi]=\"callApi\"\r\n        />\r\n    } @else if (field.type == 'tabstring') {\r\n        <esq-tab-string\r\n                [(value)]=\"details[field.name]\"\r\n                [readOnly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                [maxLength]=\"field.minmax || 2000\"\r\n        />\r\n    } @else if (field.type == 'flag') {\r\n        <div class=\"esq-simple-grid-dropdown\">\r\n            @if (field.nullable === 'Y') {\r\n                <span>{{field.label}}:</span>\r\n                <select [(ngModel)]=\"details[field.name]\" [disabled]=\"fieldReadOnly(field.readwrite, field.personal)\" [title]=\"field.tooltip || ''\"\r\n                    [attr.data-field]=\"field.name\" [style.color]=\"details[field.name] ? 'black' : 'grey'\">\r\n                    @if (field.nullmeaning) {\r\n                        <option value=null style=\"color: grey\">{{field.nullmeaning}}</option>\r\n                    }\r\n                    <option value=\"Y\" style=\"color: black\">Yes</option>\r\n                    <option value=\"N\" style=\"color: black\">No</option>\r\n                </select>\r\n            } @else {\r\n                <b>{{field.label}}:</b>\r\n                <select [(ngModel)]=\"details[field.name]\" [disabled]=\"fieldReadOnly(field.readwrite, field.personal)\" [title]=\"field.tooltip || ''\" [attr.data-field]=\"field.name\">\r\n                    <option value=\"Y\">Yes</option>\r\n                    <option value=\"N\">No</option>\r\n                </select>\r\n            }\r\n        </div>\r\n    } @else if (field.type == 'date') {\r\n        <div class=\"esq-grid-input\">\r\n            @if (field.nullable === 'Y') {\r\n<!--\r\n                <span>{{field.label}}:</span>\r\n        <! --   !!! I do not like Angular picker here: it uses Angular button and this breaks grid structure :( -- >\r\n                <div class=\"esq-nullable-input\">\r\n                <input\r\n                        matInput\r\n                        [matDatepicker]=\"picker\"\r\n                        [value]=\"details[field.name]\"\r\n                />\r\n                <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n                <mat-datepicker #picker></mat-datepicker>\r\n-->\r\n                <!-- here a different problem: \"clear\" button within the standard date picker: you cannot remove/control it -->\r\n                <span>{{field.label}}:</span>\r\n                <div class=\"esq-nullable-input\">\r\n                    <input type=\"date\" [(ngModel)]=\"details[field.name]\"\r\n                           [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                           [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                           [attr.data-field]=\"field.name\"\r\n                           [title]=\"field.tooltip || ''\" />\r\n                    @if (details[field.name] && !fieldReadOnly(field.readwrite, field.personal)) {\r\n                        <button class=\"esq-date-clear\" type=\"button\" (click)=\"clearToNull(field)\" title=\"Clear\">&times;</button>\r\n                    }\r\n                </div>\r\n            } @else {\r\n                <b>{{field.label}}:</b>\r\n                <input type=\"date\" [(ngModel)]=\"details[field.name]\"\r\n                       [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                       [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                       [attr.data-field]=\"field.name\"\r\n                       [title]=\"field.tooltip || ''\" />\r\n            }\r\n        </div>\r\n    } @else if (field.type == 'number') {\r\n        <div class=\"esq-grid-input\">\r\n            @if (field.nullable === 'Y') {\r\n                <span>{{field.label}}:</span>\r\n                <input class=\"esq-number-input\" type=\"text\"\r\n                    [value]=\"formatNumber(details[field.name], field.format)\"\r\n                    (change)=\"onNumberInput(field, $event)\"\r\n                    [style.width.ch]=\"20\"\r\n                    [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                    [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                    [placeholder]=\"field.nullmeaning || ''\"\r\n                    [title]=\"field.tooltip || ''\"\r\n                    [attr.data-field]=\"field.name\"\r\n                    [attr.list]=\"field.nullmeaning ? 'dl-' + field.name : null\" />\r\n                @if (field.nullmeaning) {\r\n                    <datalist [id]=\"'dl-' + field.name\">\r\n                        <option [value]=\"\">{{field.nullmeaning}}</option>\r\n                    </datalist>\r\n                }\r\n            } @else {\r\n                <b>{{field.label}}:</b>\r\n                <input class=\"esq-number-input\" type=\"text\"\r\n                    [value]=\"formatNumber(details[field.name], field.format)\"\r\n                    (change)=\"onNumberInput(field, $event)\"\r\n                    [style.width.ch]=\"20\"\r\n                    [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                    [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                    [attr.data-field]=\"field.name\"\r\n                    [title]=\"field.tooltip || ''\" />\r\n            }\r\n        </div>\r\n    } @else if (field.type == 'string') {\r\n        @if (field.listvalues && field.listvalues.length > 0) {\r\n            <div class=\"esq-simple-grid-dropdown\">\r\n                @if (field.nullable === 'Y') {\r\n                    <span>{{field.label}}:</span>\r\n                    <select [(ngModel)]=\"details[field.name]\" [disabled]=\"fieldReadOnly(field.readwrite, field.personal)\" [title]=\"field.tooltip || ''\"\r\n                            [style.color]=\"details[field.name] ? 'black' : 'grey'\">\r\n                        @if (field.nullmeaning) {\r\n                            <option [ngValue]=\"null\" style=\"color: grey\">{{field.nullmeaning}}</option>\r\n                        }\r\n                        @for (option of field.listvalues; track option) {\r\n                            <option [value]=\"option.split('~')[0]\" style=\"color: black\">{{option.split('~')[1] || option.split('~')[0]}}</option>\r\n                        }\r\n                    </select>\r\n                } @else {\r\n                    <b>{{field.label}}:</b>\r\n                    <select [(ngModel)]=\"details[field.name]\" [disabled]=\"fieldReadOnly(field.readwrite, field.personal)\" [title]=\"field.tooltip || ''\" [attr.data-field]=\"field.name\">\r\n                        @for (option of field.listvalues; track option) {\r\n                            <option [value]=\"option.split('~')[0]\">{{option.split('~')[1] || option.split('~')[0]}}</option>\r\n                        }\r\n                    </select>\r\n                }\r\n            </div>\r\n        } @else {\r\n            <div class=\"esq-grid-input\">\r\n                @if (field.nullable === 'Y') {\r\n                    <span>{{field.label}}:</span>\r\n                    <div class=\"esq-nullable-input\">\r\n                        <input type=\"text\" [(ngModel)]=\"details[field.name]\"\r\n                               [maxlength]=\"field.minmax || 50\"\r\n                               [style.width.ch]=\"field.minmax || 50\"\r\n                               [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                               [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                               [placeholder]=\"field.nullmeaning || ''\"\r\n                               [attr.data-field]=\"field.name\"\r\n                               [title]=\"field.tooltip || ''\" />\r\n                        @if (field.nullmeaning && details[field.name] && !fieldReadOnly(field.readwrite, field.personal)) {\r\n                            <button class=\"esq-null-clear\" type=\"button\" (click)=\"clearToNull(field)\" title=\"{{field.nullmeaning}}\">&times;</button>\r\n                        }\r\n                    </div>\r\n                } @else {\r\n                    <b>{{field.label}}:</b>\r\n                    <input type=\"text\" [(ngModel)]=\"details[field.name]\"\r\n                           [maxlength]=\"field.minmax || 50\"\r\n                           [style.width.ch]=\"field.minmax || 50\"\r\n                           [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                           [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                           [attr.data-field]=\"field.name\"\r\n                           [title]=\"field.tooltip || ''\" />\r\n                }\r\n            </div>\r\n        }\r\n    } @else if (field.type == 'text') {\r\n            <div class=\"esq-grid-input esq-grid-input-text\">\r\n                @if (field.nullable === 'Y') {\r\n                    <span>{{field.label}}:</span>\r\n                } @else {\r\n                    <b>{{field.label}}:</b>\r\n                }\r\n                <textarea cdkTextareaAutosize cdkAutosizeMinRows=\"1\"\r\n                           [(ngModel)]=\"details[field.name]\"\r\n                           [maxlength]=\"field.minmax || 2000\"\r\n                           [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                           [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                           [placeholder]=\"field.nullmeaning || ''\"\r\n                           [attr.data-field]=\"field.name\"\r\n                           [title]=\"field.tooltip || ''\"></textarea>\r\n            </div>\r\n    } @else {\r\n        <div class=\"esq-simple-grid2\">\r\n            @if (field.nullable === 'Y') {<span>{{field.label}}:</span>} @else {<b>{{field.label}}:</b>}\r\n            {{details[field.name]}}\r\n        </div>\r\n    }\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"], dependencies: [{ kind: "ngmodule", type: MatButtonModule }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgSelectOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.ɵNgSelectMultipleOption, selector: "option", inputs: ["ngValue", "value"] }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.SelectControlValueAccessor, selector: "select:not([multiple])[formControlName],select:not([multiple])[formControl],select:not([multiple])[ngModel]", inputs: ["compareWith"] }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "ngmodule", type: MatTableModule }, { kind: "component", type: EsqTabIknListComponent, selector: "esq-tab-ikn-list", inputs: ["esqListElements", "esqAddMenuElements", "esqListHeader", "readonly", "esqEnableAdd", "esqEnableRemove", "esqEnableSort", "esqEnableDetails", "esqExplorerCallApi"], outputs: ["esqListElementsChange"] }, { kind: "component", type: EsqTabIknfTableComponent, selector: "esq-tab-iknf-table", inputs: ["esqListElements", "esqListHeader"] }, { kind: "component", type: EsqTabStringComponent, selector: "esq-tab-string", inputs: ["value", "readOnly", "maxLength"], outputs: ["valueChange"] }, { kind: "component", type: EsqTabListComponent, selector: "esq-tab-list", inputs: ["esqListElements", "esqListNodeType", "esqListHeader", "esqEnableAdd", "esqEnableRemove", "esqEnableSort", "esqExplorerCallApi"] }, { kind: "component", type: MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "ngmodule", type: TextFieldModule }, { kind: "directive", type: i2$1.CdkTextareaAutosize, selector: "textarea[cdkTextareaAutosize]", inputs: ["cdkAutosizeMinRows", "cdkAutosizeMaxRows", "cdkTextareaAutosize", "placeholder"], exportAs: ["cdkTextareaAutosize"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqTabFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'esq-tab-field', imports: [
                        MatButtonModule,
                        MatTooltipModule,
                        CommonModule,
                        FormsModule,
                        MatTableModule,
                        EsqTabIknListComponent,
                        EsqTabIknfTableComponent,
                        EsqTabStringComponent,
                        EsqTabListComponent,
                        MatDivider,
                        TextFieldModule,
                    ], providers: [provideNativeDateAdapter()], encapsulation: ViewEncapsulation.None, template: "<!--\r\n  Esquire frameworks (tm)\r\n\r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n    @if (field.type == 'tab-ikn-list') {\r\n        <esq-tab-ikn-list\r\n            [esqListElements]=\"details[field.name]\"\r\n            (esqListElementsChange)=\"details[field.name] = $event\"\r\n            [esqAddMenuElements]=\"($any(details)[(field.name ?? '') + 'All'] ?? [])\"\r\n            [esqListHeader]=\"field.label\"\r\n            [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n            [esqExplorerCallApi]=\"callApi\"\r\n            [esqEnableDetails]=\"enableDetails\"\r\n        />\r\n    } @else if (field.type === 'tab-iknf-table') {\r\n        <esq-tab-iknf-table\r\n            [esqListElements]=\"details[field.name]\"\r\n            [esqListHeader]=\"field.label\"\r\n        />\r\n    } @else if (field.type == 'image') {\r\n        <div class=\"esq-tab-image-container\">\r\n            <img class=\"esq-tab-image\" [src]=\"details[field.name]\" [alt]=\"details[field.name]\" />\r\n        </div>\r\n        <mat-divider></mat-divider>\r\n    } @else if (field.type == 'href') {\r\n        <div class=\"esq-simple-grid2\">\r\n            <b>{{field.label}}:</b>\r\n            <a href=\"{{details[field.name][0]}}\" target=\"_blank\" rel=\"noopener noreferrer\">\r\n                {{details[field.name][1]}}\r\n            </a>\r\n        </div>\r\n    } @else if (field.type == 'tablist') {\r\n        <esq-tab-list\r\n            [esqListElements]=\"details[field.name]\"\r\n            [esqListNodeType]=\"nodeTypeFromFormat(field.format)\"\r\n            [esqListHeader]=\"field.label\"\r\n            [esqExplorerCallApi]=\"callApi\"\r\n        />\r\n    } @else if (field.type == 'tabstring') {\r\n        <esq-tab-string\r\n                [(value)]=\"details[field.name]\"\r\n                [readOnly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                [maxLength]=\"field.minmax || 2000\"\r\n        />\r\n    } @else if (field.type == 'flag') {\r\n        <div class=\"esq-simple-grid-dropdown\">\r\n            @if (field.nullable === 'Y') {\r\n                <span>{{field.label}}:</span>\r\n                <select [(ngModel)]=\"details[field.name]\" [disabled]=\"fieldReadOnly(field.readwrite, field.personal)\" [title]=\"field.tooltip || ''\"\r\n                    [attr.data-field]=\"field.name\" [style.color]=\"details[field.name] ? 'black' : 'grey'\">\r\n                    @if (field.nullmeaning) {\r\n                        <option value=null style=\"color: grey\">{{field.nullmeaning}}</option>\r\n                    }\r\n                    <option value=\"Y\" style=\"color: black\">Yes</option>\r\n                    <option value=\"N\" style=\"color: black\">No</option>\r\n                </select>\r\n            } @else {\r\n                <b>{{field.label}}:</b>\r\n                <select [(ngModel)]=\"details[field.name]\" [disabled]=\"fieldReadOnly(field.readwrite, field.personal)\" [title]=\"field.tooltip || ''\" [attr.data-field]=\"field.name\">\r\n                    <option value=\"Y\">Yes</option>\r\n                    <option value=\"N\">No</option>\r\n                </select>\r\n            }\r\n        </div>\r\n    } @else if (field.type == 'date') {\r\n        <div class=\"esq-grid-input\">\r\n            @if (field.nullable === 'Y') {\r\n<!--\r\n                <span>{{field.label}}:</span>\r\n        <! --   !!! I do not like Angular picker here: it uses Angular button and this breaks grid structure :( -- >\r\n                <div class=\"esq-nullable-input\">\r\n                <input\r\n                        matInput\r\n                        [matDatepicker]=\"picker\"\r\n                        [value]=\"details[field.name]\"\r\n                />\r\n                <mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>\r\n                <mat-datepicker #picker></mat-datepicker>\r\n-->\r\n                <!-- here a different problem: \"clear\" button within the standard date picker: you cannot remove/control it -->\r\n                <span>{{field.label}}:</span>\r\n                <div class=\"esq-nullable-input\">\r\n                    <input type=\"date\" [(ngModel)]=\"details[field.name]\"\r\n                           [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                           [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                           [attr.data-field]=\"field.name\"\r\n                           [title]=\"field.tooltip || ''\" />\r\n                    @if (details[field.name] && !fieldReadOnly(field.readwrite, field.personal)) {\r\n                        <button class=\"esq-date-clear\" type=\"button\" (click)=\"clearToNull(field)\" title=\"Clear\">&times;</button>\r\n                    }\r\n                </div>\r\n            } @else {\r\n                <b>{{field.label}}:</b>\r\n                <input type=\"date\" [(ngModel)]=\"details[field.name]\"\r\n                       [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                       [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                       [attr.data-field]=\"field.name\"\r\n                       [title]=\"field.tooltip || ''\" />\r\n            }\r\n        </div>\r\n    } @else if (field.type == 'number') {\r\n        <div class=\"esq-grid-input\">\r\n            @if (field.nullable === 'Y') {\r\n                <span>{{field.label}}:</span>\r\n                <input class=\"esq-number-input\" type=\"text\"\r\n                    [value]=\"formatNumber(details[field.name], field.format)\"\r\n                    (change)=\"onNumberInput(field, $event)\"\r\n                    [style.width.ch]=\"20\"\r\n                    [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                    [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                    [placeholder]=\"field.nullmeaning || ''\"\r\n                    [title]=\"field.tooltip || ''\"\r\n                    [attr.data-field]=\"field.name\"\r\n                    [attr.list]=\"field.nullmeaning ? 'dl-' + field.name : null\" />\r\n                @if (field.nullmeaning) {\r\n                    <datalist [id]=\"'dl-' + field.name\">\r\n                        <option [value]=\"\">{{field.nullmeaning}}</option>\r\n                    </datalist>\r\n                }\r\n            } @else {\r\n                <b>{{field.label}}:</b>\r\n                <input class=\"esq-number-input\" type=\"text\"\r\n                    [value]=\"formatNumber(details[field.name], field.format)\"\r\n                    (change)=\"onNumberInput(field, $event)\"\r\n                    [style.width.ch]=\"20\"\r\n                    [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                    [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                    [attr.data-field]=\"field.name\"\r\n                    [title]=\"field.tooltip || ''\" />\r\n            }\r\n        </div>\r\n    } @else if (field.type == 'string') {\r\n        @if (field.listvalues && field.listvalues.length > 0) {\r\n            <div class=\"esq-simple-grid-dropdown\">\r\n                @if (field.nullable === 'Y') {\r\n                    <span>{{field.label}}:</span>\r\n                    <select [(ngModel)]=\"details[field.name]\" [disabled]=\"fieldReadOnly(field.readwrite, field.personal)\" [title]=\"field.tooltip || ''\"\r\n                            [style.color]=\"details[field.name] ? 'black' : 'grey'\">\r\n                        @if (field.nullmeaning) {\r\n                            <option [ngValue]=\"null\" style=\"color: grey\">{{field.nullmeaning}}</option>\r\n                        }\r\n                        @for (option of field.listvalues; track option) {\r\n                            <option [value]=\"option.split('~')[0]\" style=\"color: black\">{{option.split('~')[1] || option.split('~')[0]}}</option>\r\n                        }\r\n                    </select>\r\n                } @else {\r\n                    <b>{{field.label}}:</b>\r\n                    <select [(ngModel)]=\"details[field.name]\" [disabled]=\"fieldReadOnly(field.readwrite, field.personal)\" [title]=\"field.tooltip || ''\" [attr.data-field]=\"field.name\">\r\n                        @for (option of field.listvalues; track option) {\r\n                            <option [value]=\"option.split('~')[0]\">{{option.split('~')[1] || option.split('~')[0]}}</option>\r\n                        }\r\n                    </select>\r\n                }\r\n            </div>\r\n        } @else {\r\n            <div class=\"esq-grid-input\">\r\n                @if (field.nullable === 'Y') {\r\n                    <span>{{field.label}}:</span>\r\n                    <div class=\"esq-nullable-input\">\r\n                        <input type=\"text\" [(ngModel)]=\"details[field.name]\"\r\n                               [maxlength]=\"field.minmax || 50\"\r\n                               [style.width.ch]=\"field.minmax || 50\"\r\n                               [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                               [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                               [placeholder]=\"field.nullmeaning || ''\"\r\n                               [attr.data-field]=\"field.name\"\r\n                               [title]=\"field.tooltip || ''\" />\r\n                        @if (field.nullmeaning && details[field.name] && !fieldReadOnly(field.readwrite, field.personal)) {\r\n                            <button class=\"esq-null-clear\" type=\"button\" (click)=\"clearToNull(field)\" title=\"{{field.nullmeaning}}\">&times;</button>\r\n                        }\r\n                    </div>\r\n                } @else {\r\n                    <b>{{field.label}}:</b>\r\n                    <input type=\"text\" [(ngModel)]=\"details[field.name]\"\r\n                           [maxlength]=\"field.minmax || 50\"\r\n                           [style.width.ch]=\"field.minmax || 50\"\r\n                           [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                           [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                           [attr.data-field]=\"field.name\"\r\n                           [title]=\"field.tooltip || ''\" />\r\n                }\r\n            </div>\r\n        }\r\n    } @else if (field.type == 'text') {\r\n            <div class=\"esq-grid-input esq-grid-input-text\">\r\n                @if (field.nullable === 'Y') {\r\n                    <span>{{field.label}}:</span>\r\n                } @else {\r\n                    <b>{{field.label}}:</b>\r\n                }\r\n                <textarea cdkTextareaAutosize cdkAutosizeMinRows=\"1\"\r\n                           [(ngModel)]=\"details[field.name]\"\r\n                           [maxlength]=\"field.minmax || 2000\"\r\n                           [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                           [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                           [placeholder]=\"field.nullmeaning || ''\"\r\n                           [attr.data-field]=\"field.name\"\r\n                           [title]=\"field.tooltip || ''\"></textarea>\r\n            </div>\r\n    } @else {\r\n        <div class=\"esq-simple-grid2\">\r\n            @if (field.nullable === 'Y') {<span>{{field.label}}:</span>} @else {<b>{{field.label}}:</b>}\r\n            {{details[field.name]}}\r\n        </div>\r\n    }\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { field: [{
                type: Input
            }], details: [{
                type: Input
            }], callApi: [{
                type: Input
            }], readOnly: [{
                type: Input
            }], enableDetails: [{
                type: Input
            }], userId: [{
                type: Input
            }] } });

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 12/24/2025 mir0n added processing of tabstring field value type
*                  readOnly made public
*                  kind parameter is requried for esq-cmd, esq-enode
*                  listvalues_kind moved inside of generic format
* 02/01/2026 mir0n EsqTabLStringComponent renamed with EsqTabStringComponent
*                  added use EsqTabIknListComponent
* 02/04/2026 mir0n use ChangeDetectorRef to obtain dialog heading
*                  require id and kind to run, not a tree node
* 02/05/2026 mir0n use EsqTabFieldComponent
* 02/13/2026 mir0n  EsqNodeType renamed with EsqObjectKind
* 02/17/2026 mir0n  added userId field
* 02/18/2026 mir0n  added Save/Refresh buttons with change tracking
*                   wired onSave() to restApi.esquireCmdSave()
* 02/28/2026 mir0n  fields made protected to enable inheritance
*                   added subdictionary() for sync sub-entity kind lookup
*                   hasChanges() and onSave() extended for sub-entity fields
*                   saveData()/loadData() refactored: Observable-based, tab restore, catchError
*                   added ngAfterViewChecked() with pendingTabRestore
*                   tabContent() switched from index to tab.title
*                   removed ChangeDetectorRef dependency
* 03/06/2026 mir0n  saveData catchError: RFC 7807 errors[] — alert + focusField on server validation error
*                   focusField call wrapped in setTimeout to defer after snapshot re-render
* 03/16/2026 mir0n  saving flag: Save button disabled while save is in progress
* 03/20/2026 mir0n  tree refresh on affects3 save: needsTreeRefresh flag, treeRefresh param on saveData()
* 03/26/2026 mir0n  isCreating()/onCreate() hooks for EsqCreateEntityDialog subclass
*                   treeRefreshResult() virtual method; closeConfirmMessage() hook
* 03/26/2026 mir0n  confirmDlg() replaces alert()/confirm(); callApi added
* 03/27/2026 mir0n  EsqDialogResizeDirective added to imports
* 03/31/2026 mir0n  ESC key closes dialog (prompts if unsaved changes)
* 04/08/2026 mir0n  EsqEntityDetailsDialog extends EsqExplorerHostDummy
*                   handle EsqExplorerHost.setLoading()
*                   saving() sygnal cleanup
* 04/17/2026 mir0n  import consolidation
*/
class EsqEntityDetailsDialog extends EsqExplorerHostDummy {
    btnClose;
    btnSave;
    tabGroup;
    dialogRef;
    restApi;
    dictionaryApi;
    callApi;
    readOnly = false;
    userId = "";
    details = null;
    details$;
    dictionary$;
    dictionary = [];
    pendingTabRestore = null;
    saving = false;
    loading = signal(false, ...(ngDevMode ? [{ debugName: "loading" }] : []));
    originalDetails = null;
    needsTreeRefresh = false;
    givenEntityId = "";
    givenEntityKind = -1;
    headerIcon = "";
    headerName = "";
    constructor(dialogRef, data) {
        super();
        this.dialogRef = dialogRef;
        this.restApi = data.restApi;
        this.dictionaryApi = data.dictionaryApi;
        this.callApi = data.callApi;
        this.readOnly = data.readOnly;
        this.userId = data.userId;
        this.givenEntityId = data.id;
        this.givenEntityKind = data.kind;
        this.dialogRef.disableClose = true;
        this.dialogRef.addPanelClass('esq-dialog');
        this.dialogRef.updateSize('60vw', '60vh');
    }
    //closeDialog(): void {
    //  this.dialogRef.close();
    //}
    hasChanges() {
        var ret = (EsqUtils.getChangedFields(this.originalDetails, this.details) !== null);
        if (!ret) {
            for (var tab of this.dictionary) {
                for (var field of tab.fields) {
                    if (field.type === 'subentity' && !ret) {
                        ret = EsqUtils.getChangedFields(this.originalDetails?.[field.name], this.details?.[field.name]) !== null;
                        if (ret) {
                            break;
                        }
                    }
                }
            }
        }
        return ret;
    }
    async onClose() {
        if (this.hasChanges()) {
            var result = await this.callApi.confirmDlg(EsqObjectKindFactory.instanceOf(this.givenEntityKind), (this.headerName ?? '') + ' Unsaved Changes', 'You have made changes. Do you want to save them?', EsqExplorerCallApi.ConfirmFlag.YesNo, 0);
            if (result === 0) {
                this.btnSave?.focus();
                return;
            }
        }
        this.dialogRef.close(this.needsTreeRefresh ? this.treeRefreshResult() : undefined);
    }
    treeRefreshResult() {
        return 'treeRefresh';
    }
    async onSave() {
        var savedTab = this.tabGroup?.selectedIndex ?? 0;
        var changes = null;
        var error = EsqUtils.validateFields(this.details, this.dictionary);
        if (!error) {
            changes = EsqUtils.getChangedFields(this.originalDetails, this.details) ?? {};
            for (var tabIndex = 0; tabIndex < this.dictionary.length && !error; tabIndex++) {
                for (var field of this.dictionary[tabIndex].fields) {
                    if (field.type === 'subentity') {
                        var subDict = this.subdictionary(this.details?.[field.name]?.kind);
                        var subError = EsqUtils.validateFields(this.details?.[field.name], subDict);
                        if (subError) {
                            error = {
                                fieldName: subError.fieldName,
                                fieldLabel: subError.fieldLabel,
                                message: subError.message,
                                tabIndex: tabIndex
                            };
                            break;
                        }
                        var subChanges = EsqUtils.getChangedFields(this.originalDetails?.[field.name], this.details?.[field.name]);
                        if (subChanges) {
                            var subData = this.details[field.name];
                            changes[field.name] = { id: subData.id, kind: subData.kind, ...subChanges };
                        }
                    }
                }
            }
        }
        if (error) {
            await this.callApi.confirmDlg(EsqObjectKindFactory.instanceOf(this.givenEntityKind), (this.headerName ?? '') + ' Validation Error', error.message, EsqExplorerCallApi.ConfirmFlag.Ok);
            this.focusField(error);
        }
        else if (changes && Object.keys(changes).length > 0) {
            EsqUtils.log('Save changes:', changes);
            var treeRefresh = this.dictionary.some(tab => tab.fields.some(f => {
                if (f.affects3 === 'Y' && Object.prototype.hasOwnProperty.call(changes, f.name)) {
                    return true;
                }
                if (f.type === 'subentity' && Object.prototype.hasOwnProperty.call(changes, f.name)) {
                    var subDict = this.subdictionary(this.details?.[f.name]?.kind);
                    return subDict.some(subTab => subTab.fields.some(sf => sf.affects3 === 'Y' && Object.prototype.hasOwnProperty.call(changes[f.name], sf.name)));
                }
                return false;
            }));
            var body = { id: this.givenEntityId, kind: this.givenEntityKind, ...changes };
            this.saveData(body, savedTab, treeRefresh);
        }
    }
    subdictionary(kindId) {
        var ret = [];
        if (kindId) {
            ret = this.dictionaryApi.dictionaryFromCache(kindId);
        }
        return ret;
    }
    focusField(error) {
        if (this.tabGroup) {
            this.tabGroup.selectedIndex = error.tabIndex;
        }
        setTimeout(() => {
            var el = document.querySelector('[data-field="' + error.fieldName + '"]');
            if (el) {
                el.focus();
            }
        }, 100);
    }
    onRefresh() {
        var savedTab = this.tabGroup?.selectedIndex ?? 0;
        this.loadData(savedTab);
    }
    ngOnInit() {
        this.dictionary$ = this.dictionaryApi.dictionary(this.givenEntityKind).pipe(tap(dict => { this.dictionary = dict; }));
        this.callApi?.registerHost(this);
        this.loadData();
    }
    setLoading(loading) {
        this.loading.set(loading);
    }
    loadData(restoreTab) {
        this.details$ = this.restApi.esquireCmd(this.givenEntityKind, this.givenEntityId).pipe(tap(details => {
            this.details = details;
            this.originalDetails = EsqUtils.deepCopy(details);
            this.headerIcon = EsqObjectKindFactory.instanceOf(details.kind).icon;
            this.headerName = details.name || 'No defined';
            if (restoreTab) {
                this.pendingTabRestore = restoreTab;
            }
        }), catchError(err => {
            void this.callApi?.confirmDlg(EsqObjectKindFactory.instanceOf(this.givenEntityKind), (this.headerName ?? '') + ' Load Error', 'Load failed: ' + (err.detail || err.title || err), EsqExplorerCallApi.ConfirmFlag.Ok);
            return EMPTY;
        }));
    }
    saveData(body, restoreTab, treeRefresh) {
        var snapshot = this.details;
        this.saving = true;
        this.details$ = this.restApi.esquireCmdSave(this.givenEntityKind, this.givenEntityId, body).pipe(tap(details => {
            this.details = details;
            this.originalDetails = EsqUtils.deepCopy(details);
            if (treeRefresh) {
                this.needsTreeRefresh = true;
            }
            if (restoreTab) {
                this.pendingTabRestore = restoreTab;
            }
        }), catchError(err => {
            if (err.errors && err.errors.length > 0) {
                var apiErr = err.errors[0];
                var valError = {
                    fieldName: apiErr.fieldName,
                    fieldLabel: apiErr.fieldLabel,
                    message: apiErr.message,
                    tabIndex: parseInt(apiErr.tabIndex, 10) || 0
                };
                void this.callApi?.confirmDlg(EsqObjectKindFactory.instanceOf(this.givenEntityKind), (this.headerName ?? '') + ' Save Error', 'Save failed: ' + (err.detail || valError.message), EsqExplorerCallApi.ConfirmFlag.Ok).then(() => this.focusField(valError));
            }
            else {
                void this.callApi?.confirmDlg(EsqObjectKindFactory.instanceOf(this.givenEntityKind), (this.headerName ?? '') + ' disaSave Error', 'Save failed: ' + (err.detail || err.title || err), EsqExplorerCallApi.ConfirmFlag.Ok);
            }
            return of(snapshot);
        }), finalize(() => { this.saving = false; }));
    }
    ngOnDestroy() {
        this.callApi?.unregisterHost(this);
        this.details = null;
        this.details$ = undefined;
        this.dictionary$ = undefined;
    }
    ngAfterViewChecked() {
        if (this.pendingTabRestore !== null) {
            this.tabGroup.selectedIndex = this.pendingTabRestore;
            this.pendingTabRestore = null;
        }
    }
    ngAfterViewInit() {
        if (this.btnClose) {
            this.btnClose.focus();
        }
    }
    tabContent(title) {
        return title == "Description" ? "esq-other-tab-content" : "esq-first-tab-content";
    }
    isCreating() {
        return false;
    }
    onCreate() {
        // overridden in EsqCreateEntityDialog
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqEntityDetailsDialog, deps: [{ token: i1$1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: EsqEntityDetailsDialog, isStandalone: true, selector: "details-dialog", host: { listeners: { "keydown.escape": "onClose()" } }, viewQueries: [{ propertyName: "btnClose", first: true, predicate: ["btnClose"], descendants: true }, { propertyName: "btnSave", first: true, predicate: ["btnSave"], descendants: true }, { propertyName: "tabGroup", first: true, predicate: MatTabGroup, descendants: true }], usesInheritance: true, ngImport: i0, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"'entity-details:' + userId\"\r\n>\r\n  <div>\r\n    @if (loading()) {\r\n      <span class=\"esq-loading-div\"></span>\r\n    } @else {\r\n      <img src=\"{{headerIcon}}\" class=\"esq-base-icon\"/>\r\n    }\r\n  </div>\r\n  <div>{{headerName}}</div>\r\n  <button matIconButton (click)=\"onClose()\" class = \"esq-icon-button\" matTooltip = \"Close\">\r\n    <mat-icon>close</mat-icon>\r\n  </button>\r\n</mat-toolbar>\r\n\r\n<mat-dialog-content >\r\n  <mat-tab-group class=\"esq-mat-tab-group\">\r\n    @if (details$ | async; as details) {\r\n      @if (dictionary$ | async; as dictionary) {\r\n        @for (tab of dictionary; track tab.title; let i = $index;) {      \r\n          <mat-tab [label]=\"tab.title\" bodyClass=\"{{tabContent(tab.title)}}\">\r\n            @for (field of tab.fields; track field.name) {\r\n                @if (field.type == 'subentity') {\r\n                    @let sub = subdictionary(details[field.name]?.[\"kind\"]);\r\n                    @if (sub[0] && sub[0].fields) {\r\n                        @for (subfield of sub[0].fields; track subfield.name) {\r\n                            @if (subfield.readwrite > 0) {\r\n                                <esq-tab-field\r\n                                    [field]=subfield\r\n                                    [details]=details[field.name]\r\n                                    [readOnly]=readOnly\r\n                                    [enableDetails]=true\r\n                                    [userId]=userId\r\n                                />\r\n                            }\r\n                        }\r\n                    }\r\n                } @else if (field.readwrite > 0) {\r\n                    <esq-tab-field\r\n                        [field]=field\r\n                        [details]=details\r\n                        [readOnly]=readOnly\r\n                        [enableDetails]=true\r\n                        [callApi]=callApi\r\n                        [userId]=userId\r\n                    />\r\n                }\r\n            }\r\n          </mat-tab>\r\n        }\r\n      } @else {\r\n        <p>Loading dictioary...</p>\r\n      }\r\n    } @else {\r\n      <p>Loading data...</p>\r\n    }\r\n  </mat-tab-group>\r\n</mat-dialog-content>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  @if (readOnly) {\r\n    <button #btnClose mat-raised-button mat-dialog-close>Close</button>\r\n  } @else if (isCreating()) {\r\n    <button mat-raised-button (click)=\"onClose()\">Close</button>\r\n    <button #btnSave mat-raised-button (click)=\"onCreate()\" [disabled]=\"saving\">Create</button>\r\n  } @else {\r\n    <button mat-raised-button (click)=\"onClose()\">Close</button>\r\n    <button #btnSave mat-raised-button (click)=\"onSave()\" [disabled]=\"!hasChanges() || saving\">Save</button>\r\n    <button mat-raised-button (click)=\"onRefresh()\">Refresh</button>\r\n  }\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i4$1.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i4$1.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "directive", type: EsqDialogResizeDirective, selector: "[esqDialogResize]", inputs: ["esqDialogResize"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatToolbarModule }, { kind: "component", type: i5$1.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { kind: "ngmodule", type: MatTabsModule }, { kind: "component", type: i6.MatTab, selector: "mat-tab", inputs: ["disabled", "label", "aria-label", "aria-labelledby", "labelClass", "bodyClass", "id"], exportAs: ["matTab"] }, { kind: "component", type: i6.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "fitInkBarToContent", "mat-stretch-tabs", "mat-align-tabs", "dynamicHeight", "selectedIndex", "headerPosition", "animationDuration", "contentTabIndex", "disablePagination", "disableRipple", "preserveContent", "backgroundColor", "aria-label", "aria-labelledby"], outputs: ["selectedIndexChange", "focusChange", "animationDone", "selectedTabChange"], exportAs: ["matTabGroup"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: MatTableModule }, { kind: "component", type: EsqTabFieldComponent, selector: "esq-tab-field", inputs: ["field", "details", "callApi", "readOnly", "enableDetails", "userId"] }, { kind: "pipe", type: i7.AsyncPipe, name: "async" }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqEntityDetailsDialog, decorators: [{
            type: Component,
            args: [{ selector: 'details-dialog', imports: [
                        MatDialogModule,
                        MatButtonModule,
                        MatTooltipModule,
                        DragDropModule,
                        EsqDialogResizeDirective,
                        MatIcon,
                        MatToolbarModule,
                        MatTabsModule,
                        MatDividerModule,
                        CommonModule,
                        MatTableModule,
                        EsqTabFieldComponent
                    ], encapsulation: ViewEncapsulation.None, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"'entity-details:' + userId\"\r\n>\r\n  <div>\r\n    @if (loading()) {\r\n      <span class=\"esq-loading-div\"></span>\r\n    } @else {\r\n      <img src=\"{{headerIcon}}\" class=\"esq-base-icon\"/>\r\n    }\r\n  </div>\r\n  <div>{{headerName}}</div>\r\n  <button matIconButton (click)=\"onClose()\" class = \"esq-icon-button\" matTooltip = \"Close\">\r\n    <mat-icon>close</mat-icon>\r\n  </button>\r\n</mat-toolbar>\r\n\r\n<mat-dialog-content >\r\n  <mat-tab-group class=\"esq-mat-tab-group\">\r\n    @if (details$ | async; as details) {\r\n      @if (dictionary$ | async; as dictionary) {\r\n        @for (tab of dictionary; track tab.title; let i = $index;) {      \r\n          <mat-tab [label]=\"tab.title\" bodyClass=\"{{tabContent(tab.title)}}\">\r\n            @for (field of tab.fields; track field.name) {\r\n                @if (field.type == 'subentity') {\r\n                    @let sub = subdictionary(details[field.name]?.[\"kind\"]);\r\n                    @if (sub[0] && sub[0].fields) {\r\n                        @for (subfield of sub[0].fields; track subfield.name) {\r\n                            @if (subfield.readwrite > 0) {\r\n                                <esq-tab-field\r\n                                    [field]=subfield\r\n                                    [details]=details[field.name]\r\n                                    [readOnly]=readOnly\r\n                                    [enableDetails]=true\r\n                                    [userId]=userId\r\n                                />\r\n                            }\r\n                        }\r\n                    }\r\n                } @else if (field.readwrite > 0) {\r\n                    <esq-tab-field\r\n                        [field]=field\r\n                        [details]=details\r\n                        [readOnly]=readOnly\r\n                        [enableDetails]=true\r\n                        [callApi]=callApi\r\n                        [userId]=userId\r\n                    />\r\n                }\r\n            }\r\n          </mat-tab>\r\n        }\r\n      } @else {\r\n        <p>Loading dictioary...</p>\r\n      }\r\n    } @else {\r\n      <p>Loading data...</p>\r\n    }\r\n  </mat-tab-group>\r\n</mat-dialog-content>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  @if (readOnly) {\r\n    <button #btnClose mat-raised-button mat-dialog-close>Close</button>\r\n  } @else if (isCreating()) {\r\n    <button mat-raised-button (click)=\"onClose()\">Close</button>\r\n    <button #btnSave mat-raised-button (click)=\"onCreate()\" [disabled]=\"saving\">Create</button>\r\n  } @else {\r\n    <button mat-raised-button (click)=\"onClose()\">Close</button>\r\n    <button #btnSave mat-raised-button (click)=\"onSave()\" [disabled]=\"!hasChanges() || saving\">Save</button>\r\n    <button mat-raised-button (click)=\"onRefresh()\">Refresh</button>\r\n  }\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }], propDecorators: { btnClose: [{
                type: ViewChild,
                args: ['btnClose']
            }], btnSave: [{
                type: ViewChild,
                args: ['btnSave']
            }], tabGroup: [{
                type: ViewChild,
                args: [MatTabGroup]
            }], onClose: [{
                type: HostListener,
                args: ['keydown.escape']
            }] } });

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 12/24/2025 mir0n added processing of tabstring field value type
*                  readOnly made public
*                  kind parameter is requried for esq-cmd, esq-enode
*                  listvalues_kind moved inside of generic format
* 02/01/2026 mir0n EsqTabLStringComponent renamed with EsqTabStringComponent
*                  added use EsqTabIknListComponent
* 02/04/2024 miron renamed with EsqNodeDetailsDialog (was EsqNodeEntityDetailsDialog)
* 02/05/2026 mir0n use EsqTabFieldComponent
* 02/12/2026 mir0n  EsqNodeType in explicit file
* 02/13/2026 mir0n  EsqNodeType renamed with EsqObjectKind
* 02/17/2026 mir0n  added fieldReadOnly method with personal flag support
*                   added userId field
* 02/18/2026 mir0n  added Save/Refresh buttons with change tracking
*                   wired onSave() to restApi.esquireCmdSave()
* 02/28/2026 mir0n  refactored to extend EsqEntityDetailsDialog (duplicate logic removed)
*                   added inline sub-entity field rendering
* 03/20/2026 mir0n  entity kind normalized to even (handles link-variant kinds)
* 03/27/2026 mir0n  EsqDialogResizeDirective added to imports
* 04/07/2026 mir0n  givenEntityKind set from data.nodeKind (pre-normalized by doNodeCommand)
* 04/17/2026 mir0n  import consolidation
*/
class EsqNodeDetailsDialog extends EsqEntityDetailsDialog {
    node;
    constructor(dialogRef, data) {
        super(dialogRef, data);
        this.node = data.node;
        this.givenEntityId = this.node.entityId;
        this.givenEntityKind = data.nodeKind;
    }
    /// below node nuances
    nodeStatusIcon() {
        return EsqNodeStatusFactory.instanceOf(this.node.statusCode).icon;
    }
    nodeTypeName() {
        return this.node.kind.name + (this.node.linkId ? " (shortcut)" : "");
    }
    nodeTypeFromFormat(format) {
        var id = -1; //unknown
        if (format) {
            var ftype = format.split('=');
            if (ftype.length > 1 && ftype[0] == 'kind') {
                id = Number(ftype[1]);
            }
        }
        return EsqObjectKindFactory.instanceOf(id);
    }
    fieldReadOnly(readwrite, personal) {
        var ret = true;
        if (String(this.node.entityId) === String(this.userId)) {
            // "personal" mode: only applicable fields
            ret = !("Y" === personal && readwrite == 3);
        }
        else {
            ret = this.readOnly || readwrite < 3;
        }
        return ret;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqNodeDetailsDialog, deps: [{ token: i1$1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: EsqNodeDetailsDialog, isStandalone: true, selector: "details-dialog", usesInheritance: true, ngImport: i0, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"'node-details:' + userId\"\r\n>\r\n  <div>\r\n    @if (loading()) {\r\n      <span class=\"esq-loading-div\"></span>\r\n    } @else {\r\n      <img src=\"{{node.kind.icon}}\" class=\"esq-base-icon\"/>\r\n      <img src=\"{{nodeStatusIcon()}}\" class=\"esq-overlay-icon\" />\r\n    }\r\n  </div>\r\n  <div>\r\n    {{node.name}}\r\n  </div>\r\n  <button matIconButton (click)=\"onClose()\" class = \"esq-icon-button\" matTooltip = \"Close\">\r\n    <mat-icon>close</mat-icon>\r\n  </button>\r\n</mat-toolbar>\r\n\r\n<mat-dialog-content >\r\n  <mat-tab-group class=\"esq-mat-tab-group\">\r\n    @if (details$ | async; as details) {\r\n      @if (dictionary$ | async; as dictionary) {\r\n        @for (tab of dictionary; track tab.title; let i = $index;) {      \r\n          <mat-tab [label]=\"tab.title\" bodyClass=\"{{tabContent(tab.title)}}\">\r\n            @for (field of tab.fields; track field.name) {\r\n              @if (field.name == \"name\") {\r\n                  <div class=\"esq-grid-input\">\r\n                    <b>{{field.label}}:</b>\r\n                      <input type=\"text\" [(ngModel)]=\"details[field.name]\"\r\n                             [maxlength]=\"field.minmax || 50\"\r\n                             [style.width.ch]=\"field.minmax || 50\"\r\n                             [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                             [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                             [class.esq-node-prop]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                             [title]=\"field.tooltip || ''\"\r\n                             [attr.data-field]=\"field.name\"\r\n                      />\r\n                  </div>\r\n                  <mat-divider></mat-divider>\r\n                  <div class=\"esq-grid-input\">\r\n                     <mat-divider></mat-divider>\r\n                     <mat-divider></mat-divider>\r\n                    <b>Node Type:</b>\r\n                    <input class=\"esq-node-prop\" type=\"text\" [value]=\"nodeTypeName()\" readonly tabindex=\"-1\" />\r\n                    <b>Node ID:</b>\r\n                    <input class=\"esq-node-prop\" type=\"text\" [value]=\"node.id\" readonly tabindex=\"-1\" />\r\n                    <b>Parent Node:</b>\r\n                    <input class=\"esq-node-prop\" type=\"text\" [value]=\"node.parent ? node.parent.name : 'n/a'\" readonly tabindex=\"-1\" />\r\n                  </div>\r\n                  <mat-divider></mat-divider>\r\n              } @else {\r\n                  @if (field.type == 'subentity') {\r\n                     @let sub = subdictionary(details[field.name][\"kind\"]);\r\n                     @if (sub[0] && sub[0].fields) {\r\n                         @for (subfield of sub[0].fields; track subfield.name) {\r\n                           @if (subfield.readwrite > 0) {\r\n                             <esq-tab-field\r\n                                    [field]=subfield\r\n                                 [details]=details[field.name]\r\n                                 [readOnly]=readOnly\r\n                                 [enableDetails]=true\r\n                                 [userId]=userId\r\n                             />\r\n                           }\r\n                         }\r\n                     }\r\n                  } @else if (field.readwrite > 0) {\r\n                      <esq-tab-field\r\n                          [field]=field\r\n                          [details]=details\r\n                          [readOnly]=readOnly\r\n                          [enableDetails]=true\r\n                          [callApi]=callApi\r\n                          [userId]=userId\r\n                      />\r\n                  }\r\n              }\r\n            }\r\n          </mat-tab>\r\n        }\r\n      } @else {\r\n        <p>Loading dictioary...</p>\r\n      }\r\n    } @else {\r\n      <p>Loading data...</p>\r\n    }\r\n  </mat-tab-group>\r\n</mat-dialog-content>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  @if (readOnly) {\r\n    <button #btnClose mat-raised-button mat-dialog-close>Close</button>\r\n  } @else {\r\n    <button mat-raised-button (click)=\"onClose()\">Close</button>\r\n    <button #btnSave mat-raised-button (click)=\"onSave()\" [disabled]=\"!hasChanges()\">Save</button>\r\n    <button mat-raised-button (click)=\"onRefresh()\">Refresh</button>\r\n  }\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i4$1.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i4$1.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "directive", type: EsqDialogResizeDirective, selector: "[esqDialogResize]", inputs: ["esqDialogResize"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatToolbarModule }, { kind: "component", type: i5$1.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { kind: "ngmodule", type: MatTabsModule }, { kind: "component", type: i6.MatTab, selector: "mat-tab", inputs: ["disabled", "label", "aria-label", "aria-labelledby", "labelClass", "bodyClass", "id"], exportAs: ["matTab"] }, { kind: "component", type: i6.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "fitInkBarToContent", "mat-stretch-tabs", "mat-align-tabs", "dynamicHeight", "selectedIndex", "headerPosition", "animationDuration", "contentTabIndex", "disablePagination", "disableRipple", "preserveContent", "backgroundColor", "aria-label", "aria-labelledby"], outputs: ["selectedIndexChange", "focusChange", "animationDone", "selectedTabChange"], exportAs: ["matTabGroup"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "component", type: i7$1.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: MatTableModule }, { kind: "component", type: EsqTabFieldComponent, selector: "esq-tab-field", inputs: ["field", "details", "callApi", "readOnly", "enableDetails", "userId"] }, { kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.MaxLengthValidator, selector: "[maxlength][formControlName],[maxlength][formControl],[maxlength][ngModel]", inputs: ["maxlength"] }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "pipe", type: i7.AsyncPipe, name: "async" }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqNodeDetailsDialog, decorators: [{
            type: Component,
            args: [{ selector: 'details-dialog', imports: [
                        MatDialogModule,
                        MatButtonModule,
                        MatTooltipModule,
                        DragDropModule,
                        EsqDialogResizeDirective,
                        MatIcon,
                        MatToolbarModule,
                        MatTabsModule,
                        MatDividerModule,
                        CommonModule,
                        MatTableModule,
                        EsqTabFieldComponent,
                        FormsModule
                    ], encapsulation: ViewEncapsulation.None, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"'node-details:' + userId\"\r\n>\r\n  <div>\r\n    @if (loading()) {\r\n      <span class=\"esq-loading-div\"></span>\r\n    } @else {\r\n      <img src=\"{{node.kind.icon}}\" class=\"esq-base-icon\"/>\r\n      <img src=\"{{nodeStatusIcon()}}\" class=\"esq-overlay-icon\" />\r\n    }\r\n  </div>\r\n  <div>\r\n    {{node.name}}\r\n  </div>\r\n  <button matIconButton (click)=\"onClose()\" class = \"esq-icon-button\" matTooltip = \"Close\">\r\n    <mat-icon>close</mat-icon>\r\n  </button>\r\n</mat-toolbar>\r\n\r\n<mat-dialog-content >\r\n  <mat-tab-group class=\"esq-mat-tab-group\">\r\n    @if (details$ | async; as details) {\r\n      @if (dictionary$ | async; as dictionary) {\r\n        @for (tab of dictionary; track tab.title; let i = $index;) {      \r\n          <mat-tab [label]=\"tab.title\" bodyClass=\"{{tabContent(tab.title)}}\">\r\n            @for (field of tab.fields; track field.name) {\r\n              @if (field.name == \"name\") {\r\n                  <div class=\"esq-grid-input\">\r\n                    <b>{{field.label}}:</b>\r\n                      <input type=\"text\" [(ngModel)]=\"details[field.name]\"\r\n                             [maxlength]=\"field.minmax || 50\"\r\n                             [style.width.ch]=\"field.minmax || 50\"\r\n                             [readonly]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                             [attr.tabindex]=\"fieldReadOnly(field.readwrite, field.personal) ? -1 : null\"\r\n                             [class.esq-node-prop]=\"fieldReadOnly(field.readwrite, field.personal)\"\r\n                             [title]=\"field.tooltip || ''\"\r\n                             [attr.data-field]=\"field.name\"\r\n                      />\r\n                  </div>\r\n                  <mat-divider></mat-divider>\r\n                  <div class=\"esq-grid-input\">\r\n                     <mat-divider></mat-divider>\r\n                     <mat-divider></mat-divider>\r\n                    <b>Node Type:</b>\r\n                    <input class=\"esq-node-prop\" type=\"text\" [value]=\"nodeTypeName()\" readonly tabindex=\"-1\" />\r\n                    <b>Node ID:</b>\r\n                    <input class=\"esq-node-prop\" type=\"text\" [value]=\"node.id\" readonly tabindex=\"-1\" />\r\n                    <b>Parent Node:</b>\r\n                    <input class=\"esq-node-prop\" type=\"text\" [value]=\"node.parent ? node.parent.name : 'n/a'\" readonly tabindex=\"-1\" />\r\n                  </div>\r\n                  <mat-divider></mat-divider>\r\n              } @else {\r\n                  @if (field.type == 'subentity') {\r\n                     @let sub = subdictionary(details[field.name][\"kind\"]);\r\n                     @if (sub[0] && sub[0].fields) {\r\n                         @for (subfield of sub[0].fields; track subfield.name) {\r\n                           @if (subfield.readwrite > 0) {\r\n                             <esq-tab-field\r\n                                    [field]=subfield\r\n                                 [details]=details[field.name]\r\n                                 [readOnly]=readOnly\r\n                                 [enableDetails]=true\r\n                                 [userId]=userId\r\n                             />\r\n                           }\r\n                         }\r\n                     }\r\n                  } @else if (field.readwrite > 0) {\r\n                      <esq-tab-field\r\n                          [field]=field\r\n                          [details]=details\r\n                          [readOnly]=readOnly\r\n                          [enableDetails]=true\r\n                          [callApi]=callApi\r\n                          [userId]=userId\r\n                      />\r\n                  }\r\n              }\r\n            }\r\n          </mat-tab>\r\n        }\r\n      } @else {\r\n        <p>Loading dictioary...</p>\r\n      }\r\n    } @else {\r\n      <p>Loading data...</p>\r\n    }\r\n  </mat-tab-group>\r\n</mat-dialog-content>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  @if (readOnly) {\r\n    <button #btnClose mat-raised-button mat-dialog-close>Close</button>\r\n  } @else {\r\n    <button mat-raised-button (click)=\"onClose()\">Close</button>\r\n    <button #btnSave mat-raised-button (click)=\"onSave()\" [disabled]=\"!hasChanges()\">Save</button>\r\n    <button mat-raised-button (click)=\"onRefresh()\">Refresh</button>\r\n  }\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 03/26/2026 mir0n  initial: two-phase Create→Edit dialog extending EsqEntityDetailsDialog
*                   subentity validation in onCreate(); closeConfirmMessage() override
* 03/26/2026 mir0n  confirmDlg() replaces alert()/confirm(); callApi added
* 03/27/2026 mir0n  EsqDialogResizeDirective added to imports
* 03/28/2026 mir0n  inject dictionary defaults for main entity and subentities in ngOnInit()
* 04/17/2026 mir0n  import consolidation
*/
class EsqCreateEntityDialog extends EsqEntityDetailsDialog {
    _isCreating = true;
    parentId = "";
    onError;
    constructor(dialogRef, data) {
        super(dialogRef, data);
        this.parentId = data.parentId || "";
        this.onError = data.onError;
    }
    isCreating() {
        return this._isCreating;
    }
    treeRefreshResult() {
        return !this._isCreating ? ('treeRefreshSelect:' + this.givenEntityId) : 'treeRefresh';
    }
    ngOnInit() {
        var kindObj = EsqObjectKindFactory.instanceOf(this.givenEntityKind);
        this.details = { kind: this.givenEntityKind };
        this.details$ = of(this.details);
        this.headerIcon = kindObj.icon;
        this.headerName = "New " + kindObj.name;
        this.dictionary$ = this.dictionaryApi.dictionary(this.givenEntityKind).pipe(tap(dict => {
            this.dictionary = dict;
            for (var tab of dict) {
                for (var field of tab.fields) {
                    if (field.type === 'subentity' && !this.details[field.name]) {
                        var subKind = this.esqSubKind(field);
                        if (subKind > 0) {
                            this.details[field.name] = { kind: subKind };
                        }
                    }
                }
            }
            for (var dtab of dict) {
                for (var dfield of dtab.fields) {
                    if (dfield.type !== 'subentity' && dfield.nullable !== 'Y'
                        && dfield.default && !(dfield.name in this.details)) {
                        this.details[dfield.name] = dfield.default;
                    }
                }
            }
            void this.injectSubentityDefaults(dict);
        }));
    }
    esqSubKind(field) {
        var ret = 0;
        if (field.format) {
            ret = Number(field.format);
        }
        return ret;
    }
    async injectSubentityDefaults(dict) {
        var subs = [];
        for (var tab of dict) {
            for (var field of tab.fields) {
                if (field.type === 'subentity' && this.details[field.name]) {
                    subs.push({ name: field.name, kind: this.details[field.name].kind });
                }
            }
        }
        await Promise.all(subs.map(async (sub) => {
            var subDict = await firstValueFrom(this.dictionaryApi.dictionary(sub.kind));
            for (var stab of subDict) {
                for (var sfield of stab.fields) {
                    if (sfield.nullable !== 'Y' && sfield.default && !(sfield.name in this.details[sub.name])) {
                        this.details[sub.name][sfield.name] = sfield.default;
                    }
                }
            }
        }));
        this.originalDetails = EsqUtils.deepCopy(this.details);
        this.details$ = of(this.details);
    }
    async onCreate() {
        var error = EsqUtils.validateFields(this.details, this.dictionary);
        if (!error) {
            for (var tabIndex = 0; tabIndex < this.dictionary.length && !error; tabIndex++) {
                for (var field of this.dictionary[tabIndex].fields) {
                    if (field.type === 'subentity') {
                        var subDict = this.subdictionary(this.details?.[field.name]?.kind);
                        var subError = EsqUtils.validateFields(this.details?.[field.name], subDict);
                        if (subError) {
                            error = {
                                fieldName: subError.fieldName,
                                fieldLabel: subError.fieldLabel,
                                message: subError.message,
                                tabIndex: tabIndex
                            };
                            break;
                        }
                    }
                }
            }
        }
        if (error) {
            await this.callApi.confirmDlg(null, 'Validation Error', error.message, EsqExplorerCallApi.ConfirmFlag.Ok);
            this.focusField(error);
        }
        else {
            var body = { ...this.details, kind: this.givenEntityKind };
            var snapshot = this.details;
            this.saving = true;
            var encodedParentId = this.parentId ? encodeURIComponent(this.parentId) : "";
            this.details$ = this.restApi.esquireCmdNew(this.givenEntityKind, encodedParentId, body).pipe(tap(details => {
                this.saving = false;
                this.details = details;
                this.originalDetails = EsqUtils.deepCopy(details);
                this.givenEntityId = details.id;
                this._isCreating = false;
                this.needsTreeRefresh = true;
                this.headerName = details.name || "New entity";
            }), catchError(err => {
                this.saving = false;
                var errorMsg = "";
                if (err.errors && err.errors.length > 0) {
                    var apiErr = err.errors[0];
                    var valError = {
                        fieldName: apiErr.fieldName,
                        fieldLabel: apiErr.fieldLabel,
                        message: apiErr.message,
                        tabIndex: parseInt(apiErr.tabIndex, 10) || 0
                    };
                    errorMsg = 'Create failed: ' + (err.detail || valError.message);
                    void this.callApi?.confirmDlg(null, 'Create Error', errorMsg, EsqExplorerCallApi.ConfirmFlag.Ok).then(() => this.focusField(valError));
                }
                else {
                    errorMsg = 'Create failed: ' + (err.detail || err.title || err);
                    void this.callApi?.confirmDlg(null, 'Create Error', errorMsg, EsqExplorerCallApi.ConfirmFlag.Ok);
                }
                if (this.onError) {
                    this.onError(errorMsg, err);
                }
                return of(snapshot);
            }));
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqCreateEntityDialog, deps: [{ token: i1$1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: EsqCreateEntityDialog, isStandalone: true, selector: "create-entity-dialog", usesInheritance: true, ngImport: i0, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"'entity-details:' + userId\"\r\n>\r\n  <div>\r\n    @if (loading()) {\r\n      <span class=\"esq-loading-div\"></span>\r\n    } @else {\r\n      <img src=\"{{headerIcon}}\" class=\"esq-base-icon\"/>\r\n    }\r\n  </div>\r\n  <div>{{headerName}}</div>\r\n  <button matIconButton (click)=\"onClose()\" class = \"esq-icon-button\" matTooltip = \"Close\">\r\n    <mat-icon>close</mat-icon>\r\n  </button>\r\n</mat-toolbar>\r\n\r\n<mat-dialog-content >\r\n  <mat-tab-group class=\"esq-mat-tab-group\">\r\n    @if (details$ | async; as details) {\r\n      @if (dictionary$ | async; as dictionary) {\r\n        @for (tab of dictionary; track tab.title; let i = $index;) {      \r\n          <mat-tab [label]=\"tab.title\" bodyClass=\"{{tabContent(tab.title)}}\">\r\n            @for (field of tab.fields; track field.name) {\r\n                @if (field.type == 'subentity') {\r\n                    @let sub = subdictionary(details[field.name]?.[\"kind\"]);\r\n                    @if (sub[0] && sub[0].fields) {\r\n                        @for (subfield of sub[0].fields; track subfield.name) {\r\n                            @if (subfield.readwrite > 0) {\r\n                                <esq-tab-field\r\n                                    [field]=subfield\r\n                                    [details]=details[field.name]\r\n                                    [readOnly]=readOnly\r\n                                    [enableDetails]=true\r\n                                    [userId]=userId\r\n                                />\r\n                            }\r\n                        }\r\n                    }\r\n                } @else if (field.readwrite > 0) {\r\n                    <esq-tab-field\r\n                        [field]=field\r\n                        [details]=details\r\n                        [readOnly]=readOnly\r\n                        [enableDetails]=true\r\n                        [callApi]=callApi\r\n                        [userId]=userId\r\n                    />\r\n                }\r\n            }\r\n          </mat-tab>\r\n        }\r\n      } @else {\r\n        <p>Loading dictioary...</p>\r\n      }\r\n    } @else {\r\n      <p>Loading data...</p>\r\n    }\r\n  </mat-tab-group>\r\n</mat-dialog-content>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  @if (readOnly) {\r\n    <button #btnClose mat-raised-button mat-dialog-close>Close</button>\r\n  } @else if (isCreating()) {\r\n    <button mat-raised-button (click)=\"onClose()\">Close</button>\r\n    <button #btnSave mat-raised-button (click)=\"onCreate()\" [disabled]=\"saving\">Create</button>\r\n  } @else {\r\n    <button mat-raised-button (click)=\"onClose()\">Close</button>\r\n    <button #btnSave mat-raised-button (click)=\"onSave()\" [disabled]=\"!hasChanges() || saving\">Save</button>\r\n    <button mat-raised-button (click)=\"onRefresh()\">Refresh</button>\r\n  }\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i4$1.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i4$1.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "directive", type: EsqDialogResizeDirective, selector: "[esqDialogResize]", inputs: ["esqDialogResize"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatToolbarModule }, { kind: "component", type: i5$1.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { kind: "ngmodule", type: MatTabsModule }, { kind: "component", type: i6.MatTab, selector: "mat-tab", inputs: ["disabled", "label", "aria-label", "aria-labelledby", "labelClass", "bodyClass", "id"], exportAs: ["matTab"] }, { kind: "component", type: i6.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "fitInkBarToContent", "mat-stretch-tabs", "mat-align-tabs", "dynamicHeight", "selectedIndex", "headerPosition", "animationDuration", "contentTabIndex", "disablePagination", "disableRipple", "preserveContent", "backgroundColor", "aria-label", "aria-labelledby"], outputs: ["selectedIndexChange", "focusChange", "animationDone", "selectedTabChange"], exportAs: ["matTabGroup"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: MatTableModule }, { kind: "component", type: EsqTabFieldComponent, selector: "esq-tab-field", inputs: ["field", "details", "callApi", "readOnly", "enableDetails", "userId"] }, { kind: "pipe", type: i7.AsyncPipe, name: "async" }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqCreateEntityDialog, decorators: [{
            type: Component,
            args: [{ selector: 'create-entity-dialog', imports: [
                        MatDialogModule,
                        MatButtonModule,
                        MatTooltipModule,
                        DragDropModule,
                        EsqDialogResizeDirective,
                        MatIcon,
                        MatToolbarModule,
                        MatTabsModule,
                        MatDividerModule,
                        CommonModule,
                        MatTableModule,
                        EsqTabFieldComponent
                    ], encapsulation: ViewEncapsulation.None, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"'entity-details:' + userId\"\r\n>\r\n  <div>\r\n    @if (loading()) {\r\n      <span class=\"esq-loading-div\"></span>\r\n    } @else {\r\n      <img src=\"{{headerIcon}}\" class=\"esq-base-icon\"/>\r\n    }\r\n  </div>\r\n  <div>{{headerName}}</div>\r\n  <button matIconButton (click)=\"onClose()\" class = \"esq-icon-button\" matTooltip = \"Close\">\r\n    <mat-icon>close</mat-icon>\r\n  </button>\r\n</mat-toolbar>\r\n\r\n<mat-dialog-content >\r\n  <mat-tab-group class=\"esq-mat-tab-group\">\r\n    @if (details$ | async; as details) {\r\n      @if (dictionary$ | async; as dictionary) {\r\n        @for (tab of dictionary; track tab.title; let i = $index;) {      \r\n          <mat-tab [label]=\"tab.title\" bodyClass=\"{{tabContent(tab.title)}}\">\r\n            @for (field of tab.fields; track field.name) {\r\n                @if (field.type == 'subentity') {\r\n                    @let sub = subdictionary(details[field.name]?.[\"kind\"]);\r\n                    @if (sub[0] && sub[0].fields) {\r\n                        @for (subfield of sub[0].fields; track subfield.name) {\r\n                            @if (subfield.readwrite > 0) {\r\n                                <esq-tab-field\r\n                                    [field]=subfield\r\n                                    [details]=details[field.name]\r\n                                    [readOnly]=readOnly\r\n                                    [enableDetails]=true\r\n                                    [userId]=userId\r\n                                />\r\n                            }\r\n                        }\r\n                    }\r\n                } @else if (field.readwrite > 0) {\r\n                    <esq-tab-field\r\n                        [field]=field\r\n                        [details]=details\r\n                        [readOnly]=readOnly\r\n                        [enableDetails]=true\r\n                        [callApi]=callApi\r\n                        [userId]=userId\r\n                    />\r\n                }\r\n            }\r\n          </mat-tab>\r\n        }\r\n      } @else {\r\n        <p>Loading dictioary...</p>\r\n      }\r\n    } @else {\r\n      <p>Loading data...</p>\r\n    }\r\n  </mat-tab-group>\r\n</mat-dialog-content>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  @if (readOnly) {\r\n    <button #btnClose mat-raised-button mat-dialog-close>Close</button>\r\n  } @else if (isCreating()) {\r\n    <button mat-raised-button (click)=\"onClose()\">Close</button>\r\n    <button #btnSave mat-raised-button (click)=\"onCreate()\" [disabled]=\"saving\">Create</button>\r\n  } @else {\r\n    <button mat-raised-button (click)=\"onClose()\">Close</button>\r\n    <button #btnSave mat-raised-button (click)=\"onSave()\" [disabled]=\"!hasChanges() || saving\">Save</button>\r\n    <button mat-raised-button (click)=\"onRefresh()\">Refresh</button>\r\n  }\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 03/26/2026 mir0n  initial; focus param; ConfirmFlag type; no X button
* 03/27/2026 mir0n  EsqDialogResizeDirective added; userId field for dialog position persistence
* 03/31/2026 mir0n  ArrowLeft/Right key navigation between buttons
* 04/17/2026 mir0n  import consolidation
*/
class EsqConfirmDialog {
    buttons;
    dialogRef;
    kind;
    header;
    text;
    flag;
    focus;
    userId;
    constructor(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.kind = data.kind ?? null;
        this.header = data.header ?? '';
        this.text = data.text ?? '';
        this.flag = data.flag ?? EsqExplorerCallApi.ConfirmFlag.Ok;
        this.focus = data.focus ?? 0;
        this.userId = data.userId ?? '';
        this.dialogRef.disableClose = true;
        this.dialogRef.addPanelClass('esq-dialog');
    }
    ngAfterViewInit() {
        var btn = this.buttons.get(this.focus);
        if (btn) {
            btn.focus();
        }
    }
    onButtonKeydown(event, idx) {
        if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') {
            event.preventDefault();
            var count = this.buttons.length;
            var next = event.key === 'ArrowRight' ? (idx + 1) % count : (idx - 1 + count) % count;
            var btn = this.buttons.get(next);
            if (btn)
                btn.focus();
        }
    }
    onOkYes() {
        this.dialogRef.close(0);
    }
    onNoCancel() {
        this.dialogRef.close(1);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqConfirmDialog, deps: [{ token: i1$1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: EsqConfirmDialog, isStandalone: true, selector: "esq-confirm-dialog", viewQueries: [{ propertyName: "buttons", predicate: MatButton, descendants: true }], ngImport: i0, template: "<!--\r\n  Esquire frameworks (tm)\r\n\r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"'confirm:' + userId\"\r\n>\r\n  <div>\r\n    @if (kind) {\r\n      <img src=\"{{kind.icon}}\" class=\"esq-base-icon\"/>\r\n    }\r\n  </div>\r\n  <div>{{header}}</div>\r\n</mat-toolbar>\r\n\r\n<div class=\"esq-confirm-content\">\r\n    <b>{{text}}</b>\r\n</div>\r\n\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  @if (flag === 1) {\r\n    <button mat-raised-button (click)=\"onOkYes()\" (keydown)=\"onButtonKeydown($event, 0)\">Yes</button>\r\n    <button mat-raised-button (click)=\"onNoCancel()\" (keydown)=\"onButtonKeydown($event, 1)\">No</button>\r\n  } @else if (flag === 2) {\r\n    <button mat-raised-button (click)=\"onOkYes()\" (keydown)=\"onButtonKeydown($event, 0)\">OK</button>\r\n    <button mat-raised-button (click)=\"onNoCancel()\" (keydown)=\"onButtonKeydown($event, 1)\">Cancel</button>\r\n  } @else {\r\n    <button mat-raised-button (click)=\"onOkYes()\" (keydown)=\"onButtonKeydown($event, 0)\">OK</button>\r\n  }\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i4$1.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i4$1.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "ngmodule", type: MatToolbarModule }, { kind: "component", type: i5$1.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { kind: "directive", type: EsqDialogResizeDirective, selector: "[esqDialogResize]", inputs: ["esqDialogResize"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqConfirmDialog, decorators: [{
            type: Component,
            args: [{ selector: 'esq-confirm-dialog', imports: [
                        MatDialogModule,
                        MatButtonModule,
                        MatTooltipModule,
                        DragDropModule,
                        MatToolbarModule,
                        EsqDialogResizeDirective,
                    ], encapsulation: ViewEncapsulation.None, template: "<!--\r\n  Esquire frameworks (tm)\r\n\r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"'confirm:' + userId\"\r\n>\r\n  <div>\r\n    @if (kind) {\r\n      <img src=\"{{kind.icon}}\" class=\"esq-base-icon\"/>\r\n    }\r\n  </div>\r\n  <div>{{header}}</div>\r\n</mat-toolbar>\r\n\r\n<div class=\"esq-confirm-content\">\r\n    <b>{{text}}</b>\r\n</div>\r\n\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  @if (flag === 1) {\r\n    <button mat-raised-button (click)=\"onOkYes()\" (keydown)=\"onButtonKeydown($event, 0)\">Yes</button>\r\n    <button mat-raised-button (click)=\"onNoCancel()\" (keydown)=\"onButtonKeydown($event, 1)\">No</button>\r\n  } @else if (flag === 2) {\r\n    <button mat-raised-button (click)=\"onOkYes()\" (keydown)=\"onButtonKeydown($event, 0)\">OK</button>\r\n    <button mat-raised-button (click)=\"onNoCancel()\" (keydown)=\"onButtonKeydown($event, 1)\">Cancel</button>\r\n  } @else {\r\n    <button mat-raised-button (click)=\"onOkYes()\" (keydown)=\"onButtonKeydown($event, 0)\">OK</button>\r\n  }\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }], propDecorators: { buttons: [{
                type: ViewChildren,
                args: [MatButton]
            }] } });

/**
 * Registry for entity command handlers
 * Manages handler registration and command dispatching
 */
class EsqCommandHandlerRegistry {
    handlers = [];
    confirmNotImplemented;
    /**
     * Set callback for handling unregistered commands
     */
    setNotImplementedHandler(callback) {
        this.confirmNotImplemented = callback;
    }
    /**
     * Register a command handler
     * Handlers are checked in registration order
     */
    register(handler) {
        this.handlers.push(handler);
    }
    /**
     * Find the first handler that can process the command
     */
    findHandler(cmd) {
        return this.handlers.find(h => h.canHandle(cmd));
    }
    /**
     * Execute command with node context (from call())
     * Shows "Not implemented" dialog if no handler found
     */
    async executeWithNode(cmd, context) {
        var handler = this.findHandler(cmd);
        if (!handler) {
            if (this.confirmNotImplemented) {
                await this.confirmNotImplemented(cmd);
            }
            else {
                throw new Error(`No handler registered for command: ${cmd}`);
            }
            return;
        }
        return handler.executeWithNode(context);
    }
    /**
     * Execute command with entity context (from calle())
     * Shows "Not implemented" dialog if no handler found
     */
    async executeWithEntity(cmd, context) {
        var handler = this.findHandler(cmd);
        if (!handler) {
            if (this.confirmNotImplemented) {
                await this.confirmNotImplemented(cmd);
            }
            else {
                throw new Error(`No handler registered for command: ${cmd}`);
            }
            return;
        }
        return handler.executeWithEntity(context);
    }
}

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 12/24/2025 mir0n added processing of tabstring field value type
*                  readOnly made public
*                  kind parameter is requried for esq-cmd, esq-enode
*                  listvalues_kind moved inside of generic format
* 02/04/2026 mir0n use ChangeDetectorRef to obntain dialog heading
* 02/05/2026 mir0n use EsqTabFieldComponent
* 02/12/2026 mir0n  EsqNodeType in explicit file
* 02/13/2026 mir0n  EsqNodeType renamed with EsqObjectKind
* 02/17/2026 mir0n  added userId field
* 02/18/2026 mir0n  added Save/Refresh buttons with change tracking
*                   wired onSave() to restApi.esquireKeySave()
*                   fixed change tracking: use component property instead of async alias
* 02/28/2026 mir0n  saveData()/loadData() refactored: Observable-based, tab restore, catchError
*                   added ngAfterViewChecked() with pendingTabRestore
*                   removed ChangeDetectorRef dependency; removed tabContent()
* 03/06/2026 mir0n  saveData catchError: RFC 7807 errors[] — alert + focusField on server validation error
*                   focusField call wrapped in setTimeout to defer after snapshot re-render
*                   fixed double details$ async subscription (second pipe replaced with details property)
* 03/16/2026 mir0n  saving flag: Save button disabled while save is in progress
* 03/26/2026 mir0n  confirmDlg() replaces alert()/confirm(); callApi added
* 03/27/2026 mir0n  EsqDialogResizeDirective added to imports
* 03/31/2026 mir0n  ESC key closes dialog
* 04/08/2026 mir0n  EsqAccessProfileDialog extends EsqExplorerHostDummy
*                   handle EsqExplorerHost.setLoading()
* 04/17/2026 mir0n  import consolidation
*/
class EsqAccessProfileDialog extends EsqExplorerHostDummy {
    btnClose;
    btnSave;
    tabGroup;
    dialogRef;
    restApi;
    dictionaryApi;
    callApi;
    readOnly = false;
    userId = "";
    details = null;
    details$;
    dictionary$;
    dictionary = [];
    id = "";
    headerIcon = "";
    headerName = "";
    originalDetails = null;
    pendingTabRestore = null;
    saving = false;
    loading = signal(false, ...(ngDevMode ? [{ debugName: "loading" }] : []));
    constructor(dialogRef, data) {
        super();
        this.dialogRef = dialogRef;
        this.id = data.id;
        this.restApi = data.restApi;
        this.dictionaryApi = data.dictionaryApi;
        this.callApi = data.callApi;
        this.readOnly = data.readOnly;
        this.userId = data.userId;
        this.dialogRef.disableClose = true;
        this.dialogRef.addPanelClass('esq-dialog');
        this.dialogRef.updateSize('60vw', '60vh');
    }
    closeDialog() {
        this.dialogRef.close();
    }
    hasChanges() {
        return EsqUtils.getChangedFields(this.originalDetails, this.details) !== null;
    }
    async onClose() {
        if (this.hasChanges()) {
            var result = await this.callApi.confirmDlg(null, 'Unsaved Changes', 'You have unsaved changes. Do you want to save them?', EsqExplorerCallApi.ConfirmFlag.YesNo);
            if (result === 0) {
                this.btnSave?.focus();
                return;
            }
        }
        this.dialogRef.close();
    }
    async onSave() {
        var savedTab = this.tabGroup?.selectedIndex ?? 0;
        var error = EsqUtils.validateFields(this.details, this.dictionary);
        if (error) {
            await this.callApi.confirmDlg(null, 'Validation Error', error.message, EsqExplorerCallApi.ConfirmFlag.Ok);
            this.focusField(error);
        }
        else {
            var changes = EsqUtils.getChangedFields(this.originalDetails, this.details);
            if (changes) {
                EsqUtils.log('Save changes:', changes);
                var body = { id: this.id, ...changes };
                this.saveData(body, savedTab);
            }
        }
    }
    focusField(error) {
        if (this.tabGroup) {
            this.tabGroup.selectedIndex = error.tabIndex;
        }
        setTimeout(() => {
            var el = document.querySelector('[data-field="' + error.fieldName + '"]');
            if (el) {
                el.focus();
            }
        }, 100);
    }
    onRefresh() {
        var savedTab = this.tabGroup?.selectedIndex ?? 0;
        this.loadData(savedTab);
    }
    setLoading(on) {
        this.loading.set(on);
    }
    ngOnInit() {
        this.dictionary$ = this.dictionaryApi.dictionary(EsqObjectKindFactory.ACCESSPROFILE.id).pipe(tap(dict => { this.dictionary = dict; }));
        this.callApi?.registerHost(this);
        this.loadData();
    }
    loadData(restoreTab) {
        this.details$ = this.restApi.esquireKey(this.id).pipe(tap(details => {
            this.details = details;
            this.originalDetails = EsqUtils.deepCopy(details);
            this.headerIcon = EsqObjectKindFactory.instanceOf(details.kind).icon;
            this.headerName = details.name || 'No defined';
            if (restoreTab) {
                this.pendingTabRestore = restoreTab;
            }
        }), catchError(err => {
            void this.callApi?.confirmDlg(null, 'Load Error', 'Load failed: ' + (err.detail || err.title || err), EsqExplorerCallApi.ConfirmFlag.Ok);
            return EMPTY;
        }));
    }
    saveData(body, restoreTab) {
        var snapshot = this.details;
        this.saving = true;
        this.details$ = this.restApi.esquireKeySave(this.id, body).pipe(tap(details => {
            this.details = details;
            this.originalDetails = EsqUtils.deepCopy(details);
            if (restoreTab) {
                this.pendingTabRestore = restoreTab;
            }
        }), catchError(err => {
            if (err.errors && err.errors.length > 0) {
                var apiErr = err.errors[0];
                var valError = {
                    fieldName: apiErr.fieldName,
                    fieldLabel: apiErr.fieldLabel,
                    message: apiErr.message,
                    tabIndex: parseInt(apiErr.tabIndex, 10) || 0
                };
                void this.callApi?.confirmDlg(null, 'Save Error', 'Save failed: ' + (err.detail || valError.message), EsqExplorerCallApi.ConfirmFlag.Ok).then(() => this.focusField(valError));
            }
            else {
                void this.callApi?.confirmDlg(null, 'Save Error', 'Save failed: ' + (err.detail || err.title || err), EsqExplorerCallApi.ConfirmFlag.Ok);
            }
            return of(snapshot);
        }), finalize(() => { this.saving = false; }));
    }
    ngOnDestroy() {
        this.callApi?.unregisterHost(this);
        this.details = null;
        this.details$ = undefined;
        this.dictionary$ = undefined;
    }
    ngAfterViewChecked() {
        if (this.pendingTabRestore !== null) {
            this.tabGroup.selectedIndex = this.pendingTabRestore;
            this.pendingTabRestore = null;
        }
    }
    ngAfterViewInit() {
        if (this.btnClose) {
            this.btnClose.focus();
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqAccessProfileDialog, deps: [{ token: i1$1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: EsqAccessProfileDialog, isStandalone: true, selector: "details-dialog", host: { listeners: { "keydown.escape": "onClose()" } }, viewQueries: [{ propertyName: "btnClose", first: true, predicate: ["btnClose"], descendants: true }, { propertyName: "btnSave", first: true, predicate: ["btnSave"], descendants: true }, { propertyName: "tabGroup", first: true, predicate: MatTabGroup, descendants: true }], usesInheritance: true, ngImport: i0, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"'access-profile:' + userId\"\r\n>\r\n    <div>\r\n        @if (loading()) {\r\n            <span class=\"esq-loading-div\"></span>\r\n        } @else {\r\n            <img [src]=\"headerIcon\" class=\"esq-base-icon\"/>\r\n        }\r\n    </div>\r\n    <div>{{ headerName }}</div>\r\n  <button matIconButton (click)=\"onClose()\" class = \"esq-icon-button\" matTooltip = \"Close\">\r\n    <mat-icon>close</mat-icon>\r\n  </button>\r\n</mat-toolbar>\r\n\r\n<mat-dialog-content >\r\n  <mat-tab-group class=\"esq-mat-tab-group\">\r\n    @if (details$ | async; as details) {\r\n      @if (dictionary$ | async; as dictionary) {\r\n        @for (tab of dictionary; track tab.title; let i = $index;) {      \r\n          <mat-tab [label]=\"tab.title\" bodyClass=\"esq-first-tab-content\">\r\n            @for (field of tab.fields; track field.name) {\r\n              @if (field.readwrite > 0) {\r\n                <esq-tab-field\r\n                    [field]=field\r\n                    [details]=details\r\n                    [readOnly]=readOnly\r\n                    [enableDetails]=true\r\n                    [userId]=userId\r\n                />\r\n              }\r\n            }\r\n            </mat-tab>\r\n        }\r\n      } @else {\r\n        <p>Loading dictioary...</p>\r\n      }\r\n    } @else {\r\n      <p>Loading data...</p>\r\n    }\r\n  </mat-tab-group>\r\n</mat-dialog-content>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  @if (readOnly) {\r\n    <button #btnClose mat-raised-button mat-dialog-close>Close</button>\r\n  } @else {\r\n    <button mat-raised-button (click)=\"onClose()\">Close</button>\r\n    <button #btnSave mat-raised-button (click)=\"onSave()\" [disabled]=\"!hasChanges() || saving\">Save</button>\r\n    <button mat-raised-button (click)=\"onRefresh()\">Refresh</button>\r\n  }\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i4$1.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i4$1.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "directive", type: EsqDialogResizeDirective, selector: "[esqDialogResize]", inputs: ["esqDialogResize"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatToolbarModule }, { kind: "component", type: i5$1.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { kind: "ngmodule", type: MatTabsModule }, { kind: "component", type: i6.MatTab, selector: "mat-tab", inputs: ["disabled", "label", "aria-label", "aria-labelledby", "labelClass", "bodyClass", "id"], exportAs: ["matTab"] }, { kind: "component", type: i6.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "fitInkBarToContent", "mat-stretch-tabs", "mat-align-tabs", "dynamicHeight", "selectedIndex", "headerPosition", "animationDuration", "contentTabIndex", "disablePagination", "disableRipple", "preserveContent", "backgroundColor", "aria-label", "aria-labelledby"], outputs: ["selectedIndexChange", "focusChange", "animationDone", "selectedTabChange"], exportAs: ["matTabGroup"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: MatTableModule }, { kind: "component", type: EsqTabFieldComponent, selector: "esq-tab-field", inputs: ["field", "details", "callApi", "readOnly", "enableDetails", "userId"] }, { kind: "pipe", type: i7.AsyncPipe, name: "async" }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqAccessProfileDialog, decorators: [{
            type: Component,
            args: [{ selector: 'details-dialog', imports: [
                        MatDialogModule,
                        MatButtonModule,
                        MatTooltipModule,
                        DragDropModule,
                        EsqDialogResizeDirective,
                        MatIcon,
                        MatToolbarModule,
                        MatTabsModule,
                        MatDividerModule,
                        CommonModule,
                        MatTableModule,
                        EsqTabFieldComponent,
                    ], encapsulation: ViewEncapsulation.None, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"'access-profile:' + userId\"\r\n>\r\n    <div>\r\n        @if (loading()) {\r\n            <span class=\"esq-loading-div\"></span>\r\n        } @else {\r\n            <img [src]=\"headerIcon\" class=\"esq-base-icon\"/>\r\n        }\r\n    </div>\r\n    <div>{{ headerName }}</div>\r\n  <button matIconButton (click)=\"onClose()\" class = \"esq-icon-button\" matTooltip = \"Close\">\r\n    <mat-icon>close</mat-icon>\r\n  </button>\r\n</mat-toolbar>\r\n\r\n<mat-dialog-content >\r\n  <mat-tab-group class=\"esq-mat-tab-group\">\r\n    @if (details$ | async; as details) {\r\n      @if (dictionary$ | async; as dictionary) {\r\n        @for (tab of dictionary; track tab.title; let i = $index;) {      \r\n          <mat-tab [label]=\"tab.title\" bodyClass=\"esq-first-tab-content\">\r\n            @for (field of tab.fields; track field.name) {\r\n              @if (field.readwrite > 0) {\r\n                <esq-tab-field\r\n                    [field]=field\r\n                    [details]=details\r\n                    [readOnly]=readOnly\r\n                    [enableDetails]=true\r\n                    [userId]=userId\r\n                />\r\n              }\r\n            }\r\n            </mat-tab>\r\n        }\r\n      } @else {\r\n        <p>Loading dictioary...</p>\r\n      }\r\n    } @else {\r\n      <p>Loading data...</p>\r\n    }\r\n  </mat-tab-group>\r\n</mat-dialog-content>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  @if (readOnly) {\r\n    <button #btnClose mat-raised-button mat-dialog-close>Close</button>\r\n  } @else {\r\n    <button mat-raised-button (click)=\"onClose()\">Close</button>\r\n    <button #btnSave mat-raised-button (click)=\"onSave()\" [disabled]=\"!hasChanges() || saving\">Save</button>\r\n    <button mat-raised-button (click)=\"onRefresh()\">Refresh</button>\r\n  }\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }], propDecorators: { btnClose: [{
                type: ViewChild,
                args: ['btnClose']
            }], btnSave: [{
                type: ViewChild,
                args: ['btnSave']
            }], tabGroup: [{
                type: ViewChild,
                args: [MatTabGroup]
            }], onClose: [{
                type: HostListener,
                args: ['keydown.escape']
            }] } });

/**
 * Handler for CMD_KEY command
 * Opens access profile dialog
 */
class EsqKeyCommandHandler {
    canHandle(cmd) {
        return cmd === EsqExplorerCallApi.CMD_KEY;
    }
    async executeWithNode(context) {
        var readOnly = !context.accessProfile?.isCommandAllowed(context.cmd, context.node.entityId, context.nodeKind);
        setTimeout(() => {
            void this.runAccessProfileAsync(context.node.entityId, readOnly, context.dialog, context).catch(console.error);
        }, 0);
    }
    async executeWithEntity(context) {
        var readOnly = !context.accessProfile?.isCommandAllowed(context.cmd, context.entityId, context.entityKind // already normalized by doEntityCommand()
        );
        setTimeout(() => {
            void this.runAccessProfileAsync(context.entityId, readOnly, context.dialog, context).catch(console.error);
        }, 0);
    }
    async runAccessProfileAsync(id, readOnly, dialog, context) {
        var dialogRef = dialog.open(EsqAccessProfileDialog, {
            autoFocus: false,
            data: {
                id,
                restApi: context.restApi,
                dictionaryApi: context.dictionaryApi,
                callApi: context.callApi,
                readOnly,
                userId: context.userId
            }
        });
        return new Promise((resolve) => {
            dialogRef.afterClosed().subscribe(() => resolve());
        });
    }
}

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 02/04/2024 miron renamed with EsqNodeDialog (was EsqNodeDetailsDialog)
* 03/27/2026 mir0n  EsqDialogResizeDirective added; userId field for dialog position persistence
* 03/31/2026 mir0n  ESC key closes dialog
* 04/17/2026 mir0n  import consolidation
*/
class EsqNodeDialog {
    btnClose;
    dialogRef;
    node;
    readOnly = false;
    userId = '';
    constructor(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.node = data.node;
        this.readOnly = data.readOnly;
        this.userId = data.userId ?? '';
        this.dialogRef.disableClose = true;
        this.dialogRef.addPanelClass('esq-dialog');
        this.dialogRef.updateSize('60vw', '60vh');
    }
    closeDialog() {
        this.dialogRef.close();
    }
    ngOnInit() {
    }
    ngOnDestroy() {
    }
    ngAfterViewInit() {
        if (this.btnClose) {
            this.btnClose.focus();
        }
    }
    nodeStatusIcon() {
        return EsqNodeStatusFactory.instanceOf(this.node.statusCode).icon;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqNodeDialog, deps: [{ token: i1$1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.16", type: EsqNodeDialog, isStandalone: true, selector: "details-dialog", host: { listeners: { "keydown.escape": "closeDialog()" } }, viewQueries: [{ propertyName: "btnClose", first: true, predicate: ["btnClose"], descendants: true }], ngImport: i0, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"'node:' + userId\"\r\n>\r\n  <div>\r\n    <img src=\"{{node.kind.icon}}\" class=\"esq-base-icon\"/>\r\n    <img src=\"{{nodeStatusIcon()}}\" class=\"esq-overlay-icon\" />\r\n  </div>\r\n  <div>{{node.name}}</div>\r\n  <button matIconButton mat-dialog-close class = \"esq-icon-button\" matTooltip = \"Close\">\r\n     <mat-icon>close</mat-icon>\r\n  </button>\r\n</mat-toolbar>\r\n\r\n<mat-dialog-content >\r\n  <mat-tab-group class=\"esq-mat-tab-group\">\r\n    <mat-tab label=\"Details\">\r\n      <mat-divider></mat-divider>\r\n      <div class=\"esq-simple-grid2\">\r\n        <b>Name:</b>{{node.name}}\r\n        <b>Description:</b>{{node.desc}}\r\n        <mat-divider></mat-divider>\r\n        <mat-divider></mat-divider>\r\n        <b>Node Type:</b>{{node.kind.name}}\r\n        <b>Node ID:</b>{{node.id}}\r\n        <b>Parent Node:</b>{{node.parent ? node.parent.name : 'n/a'}}      \r\n      </div>  \r\n      <mat-divider></mat-divider>\r\n    </mat-tab>\r\n  </mat-tab-group>\r\n</mat-dialog-content>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  <button #btnClose mat-raised-button mat-dialog-close >Close</button>\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i4$1.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i4$1.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "directive", type: EsqDialogResizeDirective, selector: "[esqDialogResize]", inputs: ["esqDialogResize"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatToolbarModule }, { kind: "component", type: i5$1.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { kind: "ngmodule", type: MatTabsModule }, { kind: "component", type: i6.MatTab, selector: "mat-tab", inputs: ["disabled", "label", "aria-label", "aria-labelledby", "labelClass", "bodyClass", "id"], exportAs: ["matTab"] }, { kind: "component", type: i6.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "fitInkBarToContent", "mat-stretch-tabs", "mat-align-tabs", "dynamicHeight", "selectedIndex", "headerPosition", "animationDuration", "contentTabIndex", "disablePagination", "disableRipple", "preserveContent", "backgroundColor", "aria-label", "aria-labelledby"], outputs: ["selectedIndexChange", "focusChange", "animationDone", "selectedTabChange"], exportAs: ["matTabGroup"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "component", type: i7$1.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: MatTableModule }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqNodeDialog, decorators: [{
            type: Component,
            args: [{ selector: 'details-dialog', imports: [
                        MatDialogModule,
                        MatButtonModule,
                        MatTooltipModule,
                        DragDropModule,
                        EsqDialogResizeDirective,
                        MatIcon,
                        MatToolbarModule,
                        MatTabsModule,
                        MatDividerModule,
                        CommonModule,
                        MatTableModule
                    ], encapsulation: ViewEncapsulation.None, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"'node:' + userId\"\r\n>\r\n  <div>\r\n    <img src=\"{{node.kind.icon}}\" class=\"esq-base-icon\"/>\r\n    <img src=\"{{nodeStatusIcon()}}\" class=\"esq-overlay-icon\" />\r\n  </div>\r\n  <div>{{node.name}}</div>\r\n  <button matIconButton mat-dialog-close class = \"esq-icon-button\" matTooltip = \"Close\">\r\n     <mat-icon>close</mat-icon>\r\n  </button>\r\n</mat-toolbar>\r\n\r\n<mat-dialog-content >\r\n  <mat-tab-group class=\"esq-mat-tab-group\">\r\n    <mat-tab label=\"Details\">\r\n      <mat-divider></mat-divider>\r\n      <div class=\"esq-simple-grid2\">\r\n        <b>Name:</b>{{node.name}}\r\n        <b>Description:</b>{{node.desc}}\r\n        <mat-divider></mat-divider>\r\n        <mat-divider></mat-divider>\r\n        <b>Node Type:</b>{{node.kind.name}}\r\n        <b>Node ID:</b>{{node.id}}\r\n        <b>Parent Node:</b>{{node.parent ? node.parent.name : 'n/a'}}      \r\n      </div>  \r\n      <mat-divider></mat-divider>\r\n    </mat-tab>\r\n  </mat-tab-group>\r\n</mat-dialog-content>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  <button #btnClose mat-raised-button mat-dialog-close >Close</button>\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }], propDecorators: { btnClose: [{
                type: ViewChild,
                args: ['btnClose']
            }], closeDialog: [{
                type: HostListener,
                args: ['keydown.escape']
            }] } });

/**
 * Handler for default entity details commands
 * Handles all commands not explicitly handled by other handlers
 */
class EsqDefaultCommandHandler {
    canHandle(cmd) {
        // Handle CMD_DEFAULT and any unhandled commands (fallback)
        return (cmd === EsqExplorerCallApi.CMD_DEFAULT);
    }
    async executeWithNode(context) {
        var readOnly = !context.accessProfile?.isCommandAllowed(context.cmd, context.node.entityId, context.nodeKind);
        setTimeout(() => {
            void this.runDetailsAsync(context.cmd, context.node, context.nodeKind, readOnly, context.dialog, context.dictionaryApi, context.restApi, context.callApi, context.host, context.userId).catch(console.error);
        }, 0);
    }
    async executeWithEntity(context) {
        if (context.entityId.length > 0) {
            // Direct entity details
            var readOnly = !context.accessProfile?.isCommandAllowed(context.cmd, context.entityId, context.entityKind);
            setTimeout(() => {
                void this.runEntityDetailsAsync(context.entityId, context.entityKind, readOnly, context.dialog, context.dictionaryApi, context.restApi, context.callApi, context.userId).catch(console.error);
            }, 0);
        }
        else {
            // Fetch node first
            var _enode_ = await firstValueFrom(context.restApi.esquireEntityNode(context.entityKind, "", context.entityName)).catch(console.error);
            if (_enode_) {
                var enode = new EsqTreeNode(_enode_, undefined);
                var readOnly = !context.accessProfile?.isCommandAllowed(context.cmd, enode.entityId, context.entityKind);
                setTimeout(() => {
                    void this.runDetailsAsync(context.cmd, enode, context.entityKind, readOnly, context.dialog, context.dictionaryApi, context.restApi, context.callApi, context.host, context.userId).catch(console.error);
                }, 0);
            }
        }
    }
    async runEntityDetailsAsync(id, entityKind, readOnly, dialog, dictionaryApi, restApi, callApi, userId) {
        var dialogRef = dialog.open(EsqEntityDetailsDialog, {
            autoFocus: false,
            data: {
                id,
                kind: entityKind,
                restApi,
                dictionaryApi,
                callApi,
                readOnly,
                userId
            }
        });
        dialogRef.afterClosed().subscribe(result => {
            EsqUtils.log(`Dialog result: ${result}`);
        });
        return new Promise((resolve) => resolve());
    }
    async runDetailsAsync(cmd, node, nodeKind, readOnly, dialog, dictionaryApi, restApi, callApi, host, userId) {
        var dialogRef;
        if (node.kind.detailed) {
            dialogRef = dialog.open(EsqNodeDetailsDialog, {
                autoFocus: false,
                data: {
                    node,
                    nodeKind,
                    restApi,
                    callApi,
                    dictionaryApi,
                    readOnly,
                    userId
                }
            });
        }
        else {
            dialogRef = dialog.open(EsqNodeDialog, {
                autoFocus: false,
                data: {
                    node,
                    readOnly,
                    userId
                }
            });
        }
        dialogRef.afterClosed().subscribe(result => {
            EsqUtils.log(`Dialog result: ${result}`);
            if (result === 'treeRefresh' && host) {
                setTimeout(() => host.onTreeRefresh(), 250);
            }
        });
        return new Promise((resolve) => resolve());
    }
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 04/01/2026 mir0n  initial: delete command handler extracted from EsqExplorerCallApiMill
* 04/07/2026 mir0n  use context.nodeKind / context.entityKind
* 04/17/2026 mir0n  import consolidation
*/
/**
 * Handler for CMD_DELETE command
 * Confirms deletion and executes delete operation
 */
class EsqDeleteCommandHandler {
    canHandle(cmd) {
        return cmd === EsqExplorerCallApi.CMD_DELETE;
    }
    async executeWithNode(context) {
        setTimeout(() => {
            void this.doDelete(context.node, context.nodeKind, context.callApi, context.restApi, context.host).catch(console.error);
        }, 0);
    }
    async executeWithEntity(context) {
        // Fetch node first (entityKind already normalized by doEntityCommand)
        var node = await this.fetchNode(context.restApi, context.entityKind, context.entityId, context.entityName);
        if (!node) {
            return;
        }
        var nodeRef = node;
        setTimeout(() => {
            void this.doDelete(nodeRef, context.entityKind, context.callApi, context.restApi, context.host).catch(console.error);
        }, 0);
    }
    async fetchNode(restApi, entityKind, entityId, entityName) {
        var _enode_;
        if (entityId.length > 0) {
            _enode_ = await firstValueFrom(restApi.esquireEntityNode(entityKind, entityId, "")).catch(console.error);
        }
        else {
            _enode_ = await firstValueFrom(restApi.esquireEntityNode(entityKind, "", entityName)).catch(console.error);
        }
        return _enode_ ? new EsqTreeNode(_enode_, undefined) : undefined;
    }
    async doDelete(node, kind, callApi, restApi, host) {
        var result = await callApi.confirmDlg(node.kind, node.name + ' Delete', 'You about to delete ' + node.name + '. Are you sure to continue?', EsqExplorerCallApi.ConfirmFlag.YesNo);
        if (result === 0) {
            try {
                await firstValueFrom(restApi.esquireCmdDel(kind, node.entityId));
                if (host) {
                    var parentId = node.parent ? node.parent.id : "";
                    if (parentId) {
                        setTimeout(() => host.onTreeRefresh(parentId, true), 250);
                    }
                    else {
                        setTimeout(() => host.onTreeRefresh(), 250);
                    }
                }
            }
            catch (err) {
                var errMsg = EsqUtils.errorMessage(err);
                await callApi.confirmDlg(node.kind, node.name + ' Delete Error', 'Delete failed: ' + errMsg, EsqExplorerCallApi.ConfirmFlag.Ok);
            }
        }
    }
}

class EsqExplorerCallApiMill {
    dialog;
    dictionaryApi;
    restApi;
    host;
    lastUserId = "";
    commandRegistry = new EsqCommandHandlerRegistry();
    constructor(dialog, dictionaryApi, restApi) {
        this.dialog = dialog;
        this.dictionaryApi = dictionaryApi;
        this.restApi = restApi;
        this.host = new EsqExplorerHostMill();
        // Set handler for unregistered commands
        this.commandRegistry.setNotImplementedHandler(async (cmd) => {
            await this.confirmDlg(null, 'Command Not Implemented', `Command "${cmd}" is not implemented yet.`, EsqExplorerCallApi.ConfirmFlag.Ok);
        });
        // Register built-in command handlers
        // Specific handlers must be registered before default to take precedence
        this.commandRegistry.register(new EsqDefaultCommandHandler());
        this.commandRegistry.register(new EsqKeyCommandHandler());
        this.commandRegistry.register(new EsqDeleteCommandHandler());
    }
    instance() {
        return this.esqExplorerCallApi();
    }
    setUserId(userId) {
        this.lastUserId = userId;
    }
    async doEntityCommand(cmd, subCmd, entity_id, entity_name, entityKind, accessProfile, selectMode = SelectMode.None) {
        entityKind = EsqObjectKindFactory.normalize(entityKind);
        // Build command context
        var context = {
            cmd: !cmd ? EsqExplorerCallApi.CMD_DEFAULT : cmd,
            subCmd,
            entityId: String(entity_id),
            entityName: entity_name,
            entityKind,
            accessProfile,
            selectMode,
            dialog: this.dialog,
            restApi: this.restApi,
            dictionaryApi: this.dictionaryApi,
            callApi: this.esqExplorerCallApi(),
            host: this.host,
            userId: this.lastUserId
        };
        // Dispatch through registry
        return this.commandRegistry.executeWithEntity(context.cmd, context);
    }
    getParentEntityId(node) {
        var ret = "";
        if (node.entityId) {
            ret = node.entityId;
        }
        else if (node.parent) {
            ret = this.getParentEntityId(node.parent);
        }
        return ret;
    }
    async doCreate(node, typeId) {
        var kind = EsqObjectKindFactory.normalize(typeId ?? node.kind.id);
        var parentId = this.getParentEntityId(node);
        var dialogRef = this.dialog.open(EsqCreateEntityDialog, {
            autoFocus: false,
            data: {
                id: "",
                kind: kind,
                parentId: parentId,
                restApi: this.restApi,
                dictionaryApi: this.dictionaryApi,
                callApi: this.esqExplorerCallApi(),
                readOnly: false,
                userId: this.lastUserId,
                onError: (msg, err) => {
                    // EsqUtils.log('[2/4] EsqExplorerCallApiMill.onError: received error, calling host.setErrorMessage. Host exists: ' + (this.host ? 'YES' : 'NO'));
                    if (this.host) {
                        this.host.setErrorMessage(msg, err);
                    } // else {
                    // EsqUtils.log('[2/4] EsqExplorerCallApiMill.onError: host is NOT available!');
                    // }
                }
            }
        });
        dialogRef.afterClosed().subscribe(result => {
            EsqUtils.log(`Create dialog result: ${result}`);
            if (result && typeof result === 'string' && result.startsWith('treeRefreshSelect:') && this.host) {
                var entityId = result.substring('treeRefreshSelect:'.length);
                setTimeout(() => this.host.onTreeRefresh(entityId), 250);
            }
            else if (result === 'treeRefresh' && this.host) {
                setTimeout(() => this.host.onTreeRefresh(), 250);
            }
        });
        return new Promise((resolve) => resolve());
    }
    async doNodeCommand(cmd, subCmd, node, accessProfile, selectMode = SelectMode.None) {
        // Build node command context
        var context = {
            cmd: !cmd ? EsqExplorerCallApi.CMD_DEFAULT : cmd,
            subCmd,
            node,
            nodeKind: EsqObjectKindFactory.normalize(node.kind.id),
            accessProfile,
            selectMode,
            dialog: this.dialog,
            restApi: this.restApi,
            dictionaryApi: this.dictionaryApi,
            callApi: this.esqExplorerCallApi(),
            host: this.host,
            userId: this.lastUserId
        };
        // Dispatch all commands through registry
        return this.commandRegistry.executeWithNode(context.cmd, context);
    }
    async confirmDlg(kind, header, text, flag, focus = 0) {
        var dialogRef = this.dialog.open(EsqConfirmDialog, {
            autoFocus: false,
            data: { kind, header, text, flag, focus, userId: this.lastUserId }
        });
        dialogRef.updateSize('28vw');
        return new Promise((resolve) => {
            dialogRef.afterClosed().subscribe((result) => {
                resolve(result ?? 1);
            });
        });
    }
    getHost() {
        return this.host;
    }
    esqExplorerCallApi() {
        return {
            call: (cmd, subCmd, node, accessProfile, selectMode) => {
                return this.doNodeCommand(cmd, subCmd, node, accessProfile, selectMode);
            },
            calle: (cmd, subCmd, entity_id, entity_name, entityKind, accessProfile, selectMode) => {
                return this.doEntityCommand(cmd, subCmd, entity_id, entity_name, entityKind, accessProfile, selectMode);
            },
            create: (parent_node, typeId) => {
                return this.doCreate(parent_node, typeId);
            },
            registerHost: (host) => {
                this.host.addHost(host);
            },
            unregisterHost: (host) => {
                this.host.removeHost(host);
            },
            registerHandler: (handler) => {
                this.commandRegistry.register(handler);
            },
            confirmDlg: (kind, header, text, flag, focus) => {
                return this.confirmDlg(kind, header, text, flag, focus);
            }
        };
    }
    ;
}
class EsqExplorerHostMill {
    hosts = [];
    onTreeRefresh(entityId, asOwner) {
        this.hosts.forEach(host => {
            host.onTreeRefresh(entityId, asOwner);
        });
    }
    setErrorMessage(msg, err) {
        this.hosts.forEach(host => {
            host.setErrorMessage(msg, err);
        });
    }
    setLoading(on) {
        this.hosts.forEach(host => {
            host.setLoading(on);
        });
    }
    addHost(host) {
        if (!this.hosts.includes(host)) {
            this.hosts.push(host);
        }
    }
    removeHost(host) {
        var i = this.hosts.indexOf(host);
        if (i >= 0) {
            this.hosts.splice(i, 1);
        }
    }
}

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 02/01/2026 mir0n EsqTabLStringComponent renamed with EsqTabStringComponent
* 02/05/2026 mir0n use EsqTabFieldComponent
* 03/27/2026 mir0n  EsqDialogResizeDirective added; userId field for dialog position persistence
* 03/31/2026 mir0n  ESC key closes dialog
* 04/17/2026 mir0n  import consolidation
*/
//Note: tablist filed type is not supported!!!
class EsqSingleEntryDialog {
    btnClose;
    dialogRef;
    readOnly = false;
    details;
    dictionary;
    title;
    titleIcon;
    userId = '';
    //   readonly detailsDialog:MatDialog = inject(MatDialog);   
    constructor(dialogRef, data) {
        this.dialogRef = dialogRef;
        this.dictionary = data.dictionary;
        this.readOnly = data.readOnly;
        this.details = data.details;
        this.title = data.title || "Properties";
        this.titleIcon = data.titleIcon || "./main.ico";
        this.userId = data.userId ?? '';
        this.dialogRef.disableClose = true;
        this.dialogRef.addPanelClass('esq-dialog');
        this.dialogRef.updateSize('60vw', '60vh');
    }
    closeDialog() {
        this.dialogRef.close();
    }
    ngOnInit() {
    }
    ngOnDestroy() {
    }
    ngAfterViewInit() {
        if (this.btnClose) {
            this.btnClose.focus();
        }
    }
    tabContent(index) {
        return index == 0 ? "esq-first-tab-content" : "esq-other-tab-content";
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqSingleEntryDialog, deps: [{ token: i1$1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: EsqSingleEntryDialog, isStandalone: true, selector: "details-dialog", host: { listeners: { "keydown.escape": "closeDialog()" } }, viewQueries: [{ propertyName: "btnClose", first: true, predicate: ["btnClose"], descendants: true }], ngImport: i0, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"'single-entry:' + userId\"\r\n>\r\n  <div>\r\n    <img src=\"{{titleIcon}}\" class=\"esq-base-icon\"/>\r\n  </div>\r\n  <div>{{title}}</div>\r\n  <button matIconButton mat-dialog-close class = \"esq-icon-button\" matTooltip = \"Close\">\r\n    <mat-icon>close</mat-icon>\r\n  </button>\r\n</mat-toolbar>\r\n\r\n\r\n<mat-dialog-content >\r\n  <mat-tab-group class=\"esq-mat-tab-group\">\r\n    @if (details) {\r\n      @if (dictionary) {\r\n        @for (tab of dictionary; track tab.title; let i = $index;) {\r\n          <mat-tab [label]=\"tab.title\" bodyClass=\"{{tabContent(i)}}\">\r\n            @for (field of tab.fields; track field.name) {\r\n              @if (field.readwrite > 0) {\r\n                  <esq-tab-field\r\n                      [field]=field\r\n                      [details]=details\r\n                      [readOnly]=readOnly\r\n                      [enableDetails]=true\r\n                  />\r\n              }\r\n            }\r\n          </mat-tab>\r\n        }\r\n      }\r\n    }\r\n  </mat-tab-group>\r\n</mat-dialog-content>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  <button #btnClose mat-raised-button mat-dialog-close >Close</button>\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"], dependencies: [{ kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1$1.MatDialogClose, selector: "[mat-dialog-close], [matDialogClose]", inputs: ["aria-label", "type", "mat-dialog-close", "matDialogClose"], exportAs: ["matDialogClose"] }, { kind: "directive", type: i1$1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "directive", type: i1$1.MatDialogContent, selector: "[mat-dialog-content], mat-dialog-content, [matDialogContent]" }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i2.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "component", type: i2.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i3.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i4$1.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i4$1.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "directive", type: EsqDialogResizeDirective, selector: "[esqDialogResize]", inputs: ["esqDialogResize"] }, { kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatToolbarModule }, { kind: "component", type: i5$1.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { kind: "ngmodule", type: MatTabsModule }, { kind: "component", type: i6.MatTab, selector: "mat-tab", inputs: ["disabled", "label", "aria-label", "aria-labelledby", "labelClass", "bodyClass", "id"], exportAs: ["matTab"] }, { kind: "component", type: i6.MatTabGroup, selector: "mat-tab-group", inputs: ["color", "fitInkBarToContent", "mat-stretch-tabs", "mat-align-tabs", "dynamicHeight", "selectedIndex", "headerPosition", "animationDuration", "contentTabIndex", "disablePagination", "disableRipple", "preserveContent", "backgroundColor", "aria-label", "aria-labelledby"], outputs: ["selectedIndexChange", "focusChange", "animationDone", "selectedTabChange"], exportAs: ["matTabGroup"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "ngmodule", type: CommonModule }, { kind: "ngmodule", type: MatTableModule }, { kind: "component", type: EsqTabFieldComponent, selector: "esq-tab-field", inputs: ["field", "details", "callApi", "readOnly", "enableDetails", "userId"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqSingleEntryDialog, decorators: [{
            type: Component,
            args: [{ selector: 'details-dialog', imports: [
                        MatDialogModule,
                        MatButtonModule,
                        MatTooltipModule,
                        DragDropModule,
                        EsqDialogResizeDirective,
                        MatIcon,
                        MatToolbarModule,
                        MatTabsModule,
                        MatDividerModule,
                        CommonModule,
                        MatTableModule,
                        EsqTabFieldComponent
                    ], encapsulation: ViewEncapsulation.None, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"'single-entry:' + userId\"\r\n>\r\n  <div>\r\n    <img src=\"{{titleIcon}}\" class=\"esq-base-icon\"/>\r\n  </div>\r\n  <div>{{title}}</div>\r\n  <button matIconButton mat-dialog-close class = \"esq-icon-button\" matTooltip = \"Close\">\r\n    <mat-icon>close</mat-icon>\r\n  </button>\r\n</mat-toolbar>\r\n\r\n\r\n<mat-dialog-content >\r\n  <mat-tab-group class=\"esq-mat-tab-group\">\r\n    @if (details) {\r\n      @if (dictionary) {\r\n        @for (tab of dictionary; track tab.title; let i = $index;) {\r\n          <mat-tab [label]=\"tab.title\" bodyClass=\"{{tabContent(i)}}\">\r\n            @for (field of tab.fields; track field.name) {\r\n              @if (field.readwrite > 0) {\r\n                  <esq-tab-field\r\n                      [field]=field\r\n                      [details]=details\r\n                      [readOnly]=readOnly\r\n                      [enableDetails]=true\r\n                  />\r\n              }\r\n            }\r\n          </mat-tab>\r\n        }\r\n      }\r\n    }\r\n  </mat-tab-group>\r\n</mat-dialog-content>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  <button #btnClose mat-raised-button mat-dialog-close >Close</button>\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n"] }]
        }], ctorParameters: () => [{ type: i1$1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }], propDecorators: { btnClose: [{
                type: ViewChild,
                args: ['btnClose']
            }], closeDialog: [{
                type: HostListener,
                args: ['keydown.escape']
            }] } });

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 04/17/2026 mir0n  export EsqTabFieldComponent, EsqSingleEntryDialog
*/
//export const eeee = 'eeee';

/**
 * Generated bundle index. Do not edit.
 */

export { EsqCommandHandlerRegistry, EsqConfirmDialog, EsqDialogResizeDirective, EsqDictionary, EsqEntityDetailsDialog, EsqExplorerCallApiMill, EsqNodeDetailsDialog, EsqResizeDirective, EsqSingleEntryDialog, EsqTabFieldComponent, EsqTabListComponent, EsqTabStringComponent };
//# sourceMappingURL=mir0n-pro-esquire.ui-components.mjs.map
