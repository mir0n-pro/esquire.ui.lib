import { timer, EMPTY, ignoreElements, concat, firstValueFrom } from 'rxjs';
import * as i0 from '@angular/core';
import { signal, Pipe } from '@angular/core';

class EsqExplorerHostDummy {
    onTreeRefresh(entityId, asOwner) { }
    setErrorMessage(msg, err) { }
    setLoading(on) { }
}
var EsqExplorerCallApi;
(function (EsqExplorerCallApi) {
    EsqExplorerCallApi.CMD_DEFAULT = "details";
    EsqExplorerCallApi.CMD_NEW = "new";
    EsqExplorerCallApi.CMD_MOVE = "move";
    EsqExplorerCallApi.CMD_DELETE = "delete";
    EsqExplorerCallApi.CMD_KEY = "key";
    let ConfirmFlag;
    (function (ConfirmFlag) {
        ConfirmFlag[ConfirmFlag["Ok"] = 0] = "Ok";
        ConfirmFlag[ConfirmFlag["YesNo"] = 1] = "YesNo";
        ConfirmFlag[ConfirmFlag["OkCancel"] = 2] = "OkCancel";
    })(ConfirmFlag = EsqExplorerCallApi.ConfirmFlag || (EsqExplorerCallApi.ConfirmFlag = {}));
})(EsqExplorerCallApi || (EsqExplorerCallApi = {}));

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 02/17/2026 mir0n added formatNumber and parseNumber static methods
*                  added validateFields for Save validation
*                  added deepCopy, getChangedFields methods
* 03/01/2026 mir0n  getChangedFields: null treated as changed value (typeof null === 'object' fix)
* 03/03/2026 mir0n  getChangedFields: array changes detected via JSON.stringify comparison
* 03/10/2026 mir0n  DEBUG_SKIP_VALIDATION and DEBUG_SKIP_PERMISSION debug flags
*                   validateFields() returns null immediately when DEBUG_SKIP_VALIDATION is true
* 04/02/2926 mir0n  added errorMessage()
* 04/08/2026 mir0n  removed logDelay()
*                   removed delay()
*                   added asynchDelay()/observeDelay()
*                   added observeWithDelay()
* 04/17/2026 mir0n  moved from components to api
*/
class EsqUtils {
    static DEBUG = false;
    static DELAY = false;
    static DEBUG_SKIP_VALIDATION = false;
    static DEBUG_SKIP_PERMISSION = false;
    constructor() { }
    static log(...par) {
        if (this.DEBUG) {
            console.log(...par);
        }
    }
    static observeDelay(ms) {
        return (this.DELAY ? timer(ms) : EMPTY).pipe(ignoreElements());
    }
    static observeWithDelay(obs, ms) {
        return (this.DELAY ? concat(this.observeDelay(ms), obs) : obs);
    }
    static async asyncDelay(ms) {
        if (this.DELAY) {
            return new Promise(resolve => setTimeout(resolve, ms));
        }
    }
    /**
     * Format a number using pattern string.
     * # = optional digit, 0 = required digit, = use thousand separators
     * Examples: #,##0.## (default), #,##0.00, 0, 0.00, #,##0.####
     */
    static formatNumber(value, format) {
        if (value == null || value === '')
            return '';
        const num = Number(value);
        if (isNaN(num))
            return String(value);
        const fmt = format || '#,##0.##';
        const useGrouping = fmt.includes(',');
        const dotIndex = fmt.indexOf('.');
        let minDecimals = 0;
        let maxDecimals = 0;
        if (dotIndex >= 0) {
            const decimalPart = fmt.substring(dotIndex + 1);
            maxDecimals = decimalPart.length;
            minDecimals = (decimalPart.match(/0/g) || []).length;
        }
        return num.toLocaleString('en-US', {
            useGrouping: useGrouping,
            minimumFractionDigits: minDecimals,
            maximumFractionDigits: maxDecimals
        });
    }
    static parseNumber(formatted) {
        if (!formatted)
            return null;
        const cleaned = formatted.replace(/,/g, '');
        const num = Number(cleaned);
        return isNaN(num) ? null : num;
    }
    static validateFields(details, dictionary) {
        if (this.DEBUG_SKIP_VALIDATION) {
            return null;
        }
        var ret = null;
        for (var tabIndex = 0; tabIndex < dictionary.length && !ret; tabIndex++) {
            var tab = dictionary[tabIndex];
            for (var fi = 0; fi < tab.fields.length && !ret; fi++) {
                var field = tab.fields[fi];
                if (field.readwrite < 3) {
                    continue;
                }
                var value = details[field.name];
                // required: non-nullable fields must have a value
                if (field.nullable !== 'Y') {
                    if (value == null || value === '') {
                        ret = { fieldName: field.name, fieldLabel: field.label, message: field.label + ' is required', tabIndex: tabIndex };
                    }
                }
                // string pattern validation
                if (!ret && field.validation && (field.type === 'string' || field.type === 'String')) {
                    if (value != null && value !== '') {
                        var regex = new RegExp(field.validation);
                        if (!regex.test(value)) {
                            ret = { fieldName: field.name, fieldLabel: field.label, message: field.label + ' has invalid format', tabIndex: tabIndex };
                        }
                    }
                }
                // number min/max validation
                if (!ret && field.type === 'number' && field.minmax && field.minmax.includes(',')) {
                    if (value != null && value !== '') {
                        var parts = field.minmax.split(',');
                        var min = Number(parts[0]);
                        var max = Number(parts[1]);
                        var num = Number(value);
                        if (!isNaN(num) && (num < min || num > max)) {
                            ret = { fieldName: field.name, fieldLabel: field.label, message: field.label + ' must be between ' + min + ' and ' + max, tabIndex: tabIndex };
                        }
                    }
                }
            }
        }
        return ret;
    }
    static deepCopy(obj) {
        return JSON.parse(JSON.stringify(obj));
    }
    static errorMessage(err) {
        var ret = 'Unknown error';
        if (err) {
            if (typeof err === 'string') {
                ret = err;
            }
            else {
                ret = err.detail || err.title || err.message || String(err);
            }
        }
        return ret;
    }
    static getChangedFields(original, current) {
        if (!original || !current)
            return null;
        var changes = {};
        var hasChanges = false;
        for (var key in current) {
            if (current.hasOwnProperty(key)) {
                var origVal = original[key];
                var currVal = current[key];
                if (Array.isArray(currVal) || Array.isArray(origVal)) {
                    if (JSON.stringify(origVal) !== JSON.stringify(currVal)) {
                        changes[key] = currVal;
                        hasChanges = true;
                    }
                }
                else if ((currVal === null || typeof currVal !== 'object') && origVal !== currVal) {
                    changes[key] = currVal;
                    hasChanges = true;
                }
            }
        }
        return hasChanges ? changes : null;
    }
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 02/13/2026 mir0n EsqNodeType renamed with EsqObjectKind
*/
class EsqColumnHeaderDef {
    columnDef;
    header;
    constructor(jsn) {
        if (jsn) {
            if (jsn.columnDef)
                this.columnDef = jsn.columnDef;
            if (jsn.header)
                this.header = jsn.header;
        }
    }
}
class EsqObjectKind {
    id = -1;
    name = "unknown";
    title = "";
    plural = "";
    desc = "";
    org = false;
    usr = false;
    acct = false;
    icon = "";
    detailed = false;
    childrenDetailed = false;
    treeFlags = "";
    listHeaders = [];
    childKinds = [];
    commands = [];
    constructor(jsn) {
        if (jsn) {
            this.id = jsn.id;
            if (jsn.name)
                this.name = jsn.name;
            if (jsn.title)
                this.title = jsn.title;
            if (jsn.plural)
                this.plural = jsn.plural;
            if (jsn.desc)
                this.desc = jsn.desc;
            if (jsn.org)
                this.org = jsn.org;
            if (jsn.usr)
                this.usr = jsn.usr;
            if (jsn.acct)
                this.acct = jsn.acct;
            if (jsn.icon)
                this.icon = jsn.icon;
            if (jsn.detailed)
                this.detailed = jsn.detailed;
            if (jsn.childrenDetailed)
                this.childrenDetailed = jsn.childrenDetailed;
            if (jsn.treeFlags)
                this.treeFlags = jsn.treeFlags;
            if (jsn.listHeaders)
                this.listHeaders = jsn.listHeaders.map((h) => new EsqColumnHeaderDef(h));
            if (jsn.childKinds)
                this.childKinds = jsn.childKinds;
            if (jsn.commands)
                this.commands = jsn.commands;
        }
    }
    isCommandAllowed(cmd) {
        if (!this.commands || this.commands.length == 0) {
            return false;
        }
        return this.commands.includes(cmd);
    }
    isNewAllowed() {
        return this.childKinds.length > 0;
    }
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 02/01/2026 mir0n  added childTypes array
*                   added commands array
*                   added isCommandAllowed()
*                   added isNewAllowed()
*                   added ACCESSPROFILE virtual note type
* 02/12/2026 mir0n  EsqNodeType in explicit file
*                   init() loading from server and keeps ability to be defined locally
* 02/13/2026 mir0n EsqNodeType renamed with EsqObjectKind
* 02/28/2026 mir0n  added static kinds: PERSON_PRIMARY (992), ADDRESS_POSTAL (988), ADDRESS_BIZ (990)
* 04/07/2026 mir0n  added static normalize(kind): number
* 04/08/2026 mir0n  init() corrected
* 04/13/2026 mir0n  init() registers locally-defined kinds absent from server response
* 04/15/2026 mir0n  pass kind title from server response
* 05/07/2026 mir0n  normalize(): Clear the lowest bit : rounds odd kinds down to their canonical even.
*/
class EsqObjectKindFactory {
    static kinds = [];
    static UNKNOWN = new EsqObjectKind({
        id: -1,
        name: "unknown"
    });
    static MORE = new EsqObjectKind({
        id: 999,
        name: "more",
        title: "..."
    });
    static ACCESSPROFILE = new EsqObjectKind({
        id: 998,
        name: "accessprofile",
        title: "Access Profile"
    });
    static PERSON_PRIMARY = new EsqObjectKind({
        id: 992,
        name: "person_primary",
        title: "Details"
    });
    static ADDRESS_POSTAL = new EsqObjectKind({
        id: 988,
        name: "address_postal",
        title: "Address"
    });
    static ADDRESS_BIZ = new EsqObjectKind({
        id: 990,
        name: "address_postal",
        title: "Address"
    });
    constructor() {
    }
    static update(kind, kinds) {
        var given = null;
        for (const k of kinds) {
            if (k.id == kind.id) {
                given = k;
                break;
            }
        }
        if (given) {
            if (given.icon && given.icon.length > 0) {
                kind.icon = given.icon;
            }
            if (given.listHeaders && given.listHeaders.length > 0) {
                kind.listHeaders = given.listHeaders;
            }
        }
    }
    static async init(api, kinds) {
        if (this.kinds.length == 0) {
            //if (kinds && kinds.length > 0) {
            //    this.kinds = kinds.map(k => k);
            //}
            if (api) {
                const data = await firstValueFrom(api.esquireKinds());
                const src = data ?? [];
                src.forEach(k => {
                    var kind = new EsqObjectKind(k);
                    if (kinds) {
                        this.update(kind, kinds);
                    }
                    this.kinds.push(kind);
                });
                if (kinds) {
                    for (var k of kinds) {
                        if (!this.kinds.find(existing => existing.id === k.id)) {
                            this.kinds.push(new EsqObjectKind({ id: k.id, name: k.name, title: k.title, icon: k.icon, listHeaders: k.listHeaders }));
                        }
                    }
                }
            }
        }
    }
    static normalize(kind) {
        // Clear the lowest bit -- rounds odd kinds down to their canonical even.
        return kind & -2;
    }
    static instanceOf(kind) {
        var ret = EsqObjectKindFactory.UNKNOWN;
        if (kind == 999) {
            ret = EsqObjectKindFactory.MORE;
        }
        else {
            if (this.kinds.length > 0) {
                const res = this.kinds.filter((x) => x.id == kind);
                if (res && res.length > 0) {
                    ret = res[0];
                }
            }
        }
        return ret;
    }
    ;
    static getAllowedChildTypes(parent) {
        if (!parent) {
            return [];
        }
        const allowedTypeIds = parent.kind.childKinds || [];
        return allowedTypeIds
            .map(id => this.instanceOf(id))
            .filter(type => type.id !== EsqObjectKindFactory.UNKNOWN.id);
    }
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 02/17/2026 mir0n  isolated from generated rest api
*                   isCommandAllowed() with entity_id param, personal mode, kind rounding
* 03/10/2026 mir0n  DEBUG_SKIP_PERMISSION: isCommandAllowed() returns true when flag is set
*                   import EsqUtils for debug flag access
* 04/07/2026 mir0n  isCommandAllowed(): use EsqObjectKindFactory.normalize()
* 04/10/2026 mir0n  static readonly FLAG_INDEX replaced with customizable flagIndexes
*                   added static addFlagIndex()
* 04/17/2026 mir0n  import path fix: EsqUtils
*/
class EsqRole {
    id;
    name;
    adminFlg;
    constructor(jsn) {
        this.id = jsn.id || 0;
        this.name = jsn.name || '';
        this.adminFlg = jsn.adminFlg || 'N';
    }
}
class EsqPermission {
    id;
    kind;
    name;
    type;
    flags;
    constructor(jsn) {
        this.id = jsn.id || '';
        this.kind = jsn.kind || 0;
        this.name = jsn.name || '';
        this.type = jsn.type || '';
        this.flags = jsn.flags || [];
    }
}
//export class EsqAccessProfilePermissions {
//  admin:EsqPermission[];
//  tools:EsqPermission[];
//  constructor(jsn : any) {
//      this.admin = (jsn.admin || []).map((x: any) => new EsqPermission(x));
//      this.tools = (jsn.tools || []).map((x: any) => new EsqPermission(x));
//  }
//}
class EsqAccessProfile {
    id;
    kind;
    name;
    loginId;
    email;
    pwdChangeForced;
    tfaMethod;
    roles;
    admin;
    tools;
    //permissions: EsqAccessProfilePermissions;
    constructor(jsn) {
        this.id = jsn.id || '';
        this.kind = jsn.kind || 0;
        this.name = jsn.name || '';
        this.loginId = jsn.loginId || '';
        this.email = jsn.email || '';
        this.pwdChangeForced = jsn.pwdChangeForced || 'N';
        this.tfaMethod = jsn.tfaMethod || 'N';
        this.roles = (jsn.roles || []).map((x) => new EsqRole(x));
        this.admin = (jsn.admin || []).map((x) => new EsqPermission(x));
        this.tools = (jsn.tools || []).map((x) => new EsqPermission(x));
    }
    static flagIndexes = [
        { [EsqExplorerCallApi.CMD_NEW]: 0 },
        { [EsqExplorerCallApi.CMD_DEFAULT]: 1 },
        { [EsqExplorerCallApi.CMD_MOVE]: 1 },
        { [EsqExplorerCallApi.CMD_DELETE]: 2 },
        { [EsqExplorerCallApi.CMD_KEY]: 3 },
    ];
    isCommandAllowed(cmd, entity_id, kind) {
        if (EsqUtils.DEBUG_SKIP_PERMISSION) {
            return true;
        }
        var ret = String(this.id) === String(entity_id); // xxx: "personal" mode
        if (!ret) {
            var knd = EsqObjectKindFactory.normalize(kind);
            var effectiveCmd = cmd || EsqExplorerCallApi.CMD_DEFAULT;
            var perm = this.admin.find(p => p.kind === knd);
            if (perm) {
                const entry = EsqAccessProfile.flagIndexes.find(item => item[effectiveCmd] !== undefined);
                const index = entry ? entry[effectiveCmd] : undefined;
                if (perm && index !== undefined && index < perm.flags.length) {
                    ret = perm.flags[index] === 'Y';
                }
            }
        }
        return ret;
    }
    static addFlagIndex(flag, index) {
        const existing = EsqAccessProfile.flagIndexes.find(obj => obj.hasOwnProperty(flag));
        if (!existing) {
            EsqAccessProfile.flagIndexes.push({ [flag]: index });
        }
        else {
            existing[flag] = index; // Update existing instead
        }
    }
}

/*
*  Esquire frameworks (tm)
*  Esquire Explorer
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 02/17/2026 mir0n nullable changed from boolean to string
*                  added personal, minmax fields to dictionary
* 03/03/2026 mir0n  title and detail field types changed from 'string' to 'text'
* 03/06/2026 mir0n  errors[] shape updated to match backend EsqValidationError payload
*                   added "Validation Errors" tab with errors field (tabstring, nullable)
*/
const problemDetailDictionary = [
    { title: "Generic",
        fields: [
            {
                name: "status", sort: 0, label: "status", type: "string", tooltip: "HTTP status code",
                nullable: 'N', layer: 0, readwrite: 1, format: "",
                listvalues: [], nullmeaning: '', validation: '', personal: '', minmax: ''
            },
            {
                name: "title", sort: 1, label: "title", type: "text", tooltip: "Short, human-readable summary",
                nullable: 'N', layer: 0, readwrite: 1, format: "",
                listvalues: [], nullmeaning: '', validation: '', personal: '', minmax: '100'
            },
            {
                name: "type", sort: 2, label: "type", type: "string", tooltip: "URI identifying the error type",
                nullable: 'N', layer: 0, readwrite: 1, format: "",
                listvalues: [], nullmeaning: '', validation: '', personal: '', minmax: ''
            },
            {
                name: "traceId", sort: 3, label: "traceId", type: "string", tooltip: "A cross-system trace ID",
                nullable: 'N', layer: 0, readwrite: 1, format: "",
                listvalues: [], nullmeaning: '', validation: '', personal: '', minmax: ''
            },
        ] },
    { title: "Details",
        fields: [
            {
                name: "detail", sort: 0, label: "detail", type: "text", tooltip: "Detailed, actionable explanation",
                nullable: 'N', layer: 1, readwrite: 1, format: "",
                listvalues: [], nullmeaning: '', validation: '', personal: '', minmax: '200'
            },
            {
                name: "instance", sort: 1, label: "instance", type: "string", tooltip: "URI identifying the specific occurrence",
                nullable: 'N', layer: 1, readwrite: 1, format: "",
                listvalues: [], nullmeaning: '', validation: '', personal: '', minmax: ''
            },
            {
                name: "timestamp", sort: 2, label: "timestamp", type: "string", tooltip: "Error timestamp in UTC timezone",
                nullable: 'N', layer: 1, readwrite: 1, format: "",
                listvalues: [], nullmeaning: '', validation: '', personal: '', minmax: ''
            },
            {
                name: "requestId", sort: 3, label: "requestId", type: "string", tooltip: "End-client request ID",
                nullable: 'N', layer: 1, readwrite: 1, format: "",
                listvalues: [], nullmeaning: '', validation: '', personal: '', minmax: ''
            },
            {
                name: "correlationId", sort: 4, label: "correlationId", type: "string", tooltip: "Server internal correlation ID",
                nullable: 'N', layer: 1, readwrite: 1, format: "",
                listvalues: [], nullmeaning: '', validation: '', personal: '', minmax: ''
            },
            {
                name: "processingTime", sort: 5, label: "processingTime", type: "string", tooltip: "Only for Gateway errors: Total time the system spent on the request before the error occurred",
                nullable: 'N', layer: 1, readwrite: 1, format: "",
                listvalues: [], nullmeaning: '', validation: '', personal: '', minmax: ''
            },
        ] },
    { title: "Stack Trace",
        fields: [
            {
                name: "stackTrace", sort: 0, label: "Stack Trace", type: "tabstring", tooltip: "Root cause stack trace.",
                nullable: 'N', layer: 2, readwrite: 1, format: "",
                listvalues: [], nullmeaning: '', validation: '', personal: '', minmax: ''
            },
        ] },
    { title: "Errors",
        fields: [
            {
                name: "errors", sort: 0, label: "Errors", type: "tabstring", tooltip: "Validation errors in raw format.",
                nullable: 'y', layer: 3, readwrite: 1, format: "",
                listvalues: [], nullmeaning: '', validation: '', personal: '', minmax: ''
            },
        ] }
];

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 12/24/2025 mir0n listvalues_kind moved inside of generic format
* 02/13/2026 mir0n EsqNodeType renamed with EsqObjectKind
* 02/17/2026 mir0n added personal, minmax fields
*                  nullable changed from boolean to string
* 03/20/2026 mir0n  affects3 optional field added
* 03/28/2026 mir0n  default optional field added; mapped from jsn['default']
* 04/07/2026 mir0n  constructor param renamed entity_kind → entityKind
*/
class EsqEntityField {
    name; // +
    sort; // x
    label; // +
    type; // +/- (string, number, flag, listvalues, date, datetime, href, tablist, tabstring, image)
    tooltip; // x
    listvalues; // x in concrete order
    nullable; // x
    nullmeaning; // x
    validation; // x
    layer; // +
    readwrite; //(bitmap: 0:hidden,1:view, 3:full)
    format; // +
    personal;
    minmax; // +
    affects3;
    default;
    constructor(jsn) {
        this.name = jsn.name;
        this.sort = jsn.sort;
        this.label = jsn.label;
        this.type = jsn.type;
        this.tooltip = jsn.tooltip;
        this.listvalues = jsn.listvalues;
        this.nullable = jsn.nullable;
        this.nullmeaning = jsn.nullmeaning;
        this.validation = jsn.validation;
        this.layer = jsn.layer;
        this.readwrite = jsn.readwrite;
        this.format = jsn.format;
        this.personal = jsn.personal;
        this.minmax = jsn.minmax;
        this.affects3 = jsn.affects3;
        this.default = jsn['default']; //xxx: "default" is a reserved word
    }
}
;
//note: flag : string: Y/N values + null meaning
//      href   string[2], 0 : url, 1 : text 
//      image
class EsqEntityDictionary {
    kind; //entity kind, same as EsqObjectKind.id  
    layers; // sorted by [tab][order]
    constructor(entityKind, jsn) {
        this.kind = entityKind;
        this.layers = [];
        if (jsn) {
            jsn.forEach((x) => {
                this.layers[this.layers.length] = new EsqEntityLayer(x);
            });
        }
    }
}
class EsqEntityLayer {
    title;
    fields; // sorted by [tab][order]
    constructor(jsn) {
        this.title = jsn.title;
        this.fields = [];
        if (jsn.fields) {
            jsn.fields.forEach((x) => {
                this.fields[this.fields.length] = new EsqEntityField(x);
            });
        }
    }
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
*/
class EsqNodeStatus {
    id;
    name;
    icon;
    constructor(id, name, icon) {
        this.id = id;
        this.name = name;
        this.icon = icon;
    }
}
class EsqNodeStatusFactory {
    static dictionary = [];
    static UNKNOWN = new EsqNodeStatus(0, "Unknown", "");
    constructor(dictionary) {
    }
    static init(dictionary) {
        this.dictionary = dictionary;
    }
    static instanceOf(statusId) {
        var ret = EsqNodeStatusFactory.UNKNOWN;
        if (this.dictionary.length > 0) {
            const res = this.dictionary.filter((x) => x.id == statusId);
            if (res && res.length > 0) {
                ret = res[0];
            }
        }
        return ret;
    }
    ;
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 02/13/2026 mir0n removed treeFlags
* 02/13/2026 mir0n kind renamed to kindId (protected)
*                  EsqNodeType renamed with EsqObjectKind
*/
class EsqTreeNodeDto {
    id = "";
    parentId = "";
    linkId = "";
    name = "";
    kindId = 0;
    entityId = "";
    statusCode = 0;
    moreRemaining = false;
    level = 0;
    path = [];
    desc = "";
    all;
    constructor(jsn) {
        if (jsn) {
            if (jsn.id)
                this.id = jsn.id;
            if (jsn.parentId)
                this.parentId = jsn.parentId;
            if (jsn.linkId)
                this.linkId = jsn.linkId;
            if (jsn.name)
                this.name = jsn.name;
            if (jsn.kind)
                this.kindId = jsn.kind;
            if (jsn.entityId)
                this.entityId = jsn.entityId;
            if (jsn.statusCode)
                this.statusCode = jsn.statusCode;
            if (jsn.moreRemaining)
                this.moreRemaining = jsn.moreRemaining;
            if (jsn.level)
                this.level = jsn.level;
            if (jsn.path)
                this.path = jsn.path;
            if (jsn.desc)
                this.desc = jsn.desc;
            this.all = jsn;
        }
    }
    value(columnRef) {
        var ret = "";
        try {
            const a = this.all[columnRef];
            if (a && (typeof a == 'string' || a instanceof String)) {
                ret = a;
            }
        }
        catch (error) {
            console.error(error);
            ret = "";
        }
        return ret;
    }
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 02/12/2026 mir0n  EsqNodeType in explicit file
* 02/13/2026 mir0n removed treeFlags
* 02/13/2026 mir0n EsqNodeType renamed with EsqObjectKind
*/
class EsqTreeNode extends EsqTreeNodeDto {
    loading = signal(false, ...(ngDevMode ? [{ debugName: "loading" }] : []));
    expandable = signal(false, ...(ngDevMode ? [{ debugName: "expandable" }] : []));
    selected = signal(false, ...(ngDevMode ? [{ debugName: "selected" }] : []));
    hasMore = signal(false, ...(ngDevMode ? [{ debugName: "hasMore" }] : []));
    hasChild = signal(false, ...(ngDevMode ? [{ debugName: "hasChild" }] : []));
    expanded = signal(false, ...(ngDevMode ? [{ debugName: "expanded" }] : []));
    kind;
    parent;
    //public data?: | string | Array<string>;
    loadingMutex = new Mutex();
    constructor(jsn, parent) {
        super(jsn);
        this.kind = EsqObjectKindFactory.instanceOf(this.kindId);
        this.hasMore.set(this.moreRemaining);
        this.expandable.set(this.kind.treeFlags.includes('B'));
        this.hasChild.set(this.kind.treeFlags.includes('T'));
        if (parent) {
            this.parent = parent;
        }
    }
    async setLoading(flag) {
        if (flag) { //enter tcritical section
            await this.loadingMutex.lock();
            this.loading.set(true);
        }
        else { //exit critical section
            this.loading.set(false);
            this.loadingMutex.unlock();
        }
    }
}
class Mutex {
    locked;
    constructor() {
        this.locked = false;
    }
    async lock() {
        while (this.locked) {
            await new Promise(resolve => setTimeout(resolve, 50));
        }
        this.locked = true;
    }
    unlock() {
        this.locked = false;
    }
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
*/
class AsEsqTreeNodePipe {
    transform(value, ...args) {
        return value;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: AsEsqTreeNodePipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe });
    static ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "20.3.16", ngImport: i0, type: AsEsqTreeNodePipe, isStandalone: true, name: "asEsqTreeNode" });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: AsEsqTreeNodePipe, decorators: [{
            type: Pipe,
            args: [{
                    name: 'asEsqTreeNode',
                    standalone: true
                }]
        }] });

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 02/12/2026 mir0n  EsqNodeType in explicit file
* 02/13/2026 mir0n EsqNodeType renamed with EsqObjectKind
* 02/17/2026 mir0n CMD_ constants moved to EsqExplorerCallApi
* 04/13/2026 mir0n  EsqSubMenuItem interface; subItems on EsqCommandMenuItem for generic submenu support
*/
class EsqCommandMenuItem {
    label;
    icon;
    cmd;
    subItems; // present = submenu trigger; absent = direct click
    constructor(label, icon, cmd, subItems) {
        this.label = label;
        this.icon = icon;
        this.cmd = cmd;
        this.subItems = subItems;
    }
}
class EsqContextMenuBuilder {
    static buildNewMenuItems(parent) {
        const allowedTypes = EsqObjectKindFactory.getAllowedChildTypes(parent);
        return allowedTypes.map(childType => ({
            label: `New ${childType.name}`,
            icon: childType.icon,
            kind: childType
        }));
    }
}

var SelectMode;
(function (SelectMode) {
    SelectMode[SelectMode["None"] = 0] = "None";
    SelectMode[SelectMode["Refresh"] = 1] = "Refresh";
    SelectMode[SelectMode["SelectTree"] = 2] = "SelectTree";
    SelectMode[SelectMode["SelectList"] = 3] = "SelectList";
})(SelectMode || (SelectMode = {}));

/**
 * Generated bundle index. Do not edit.
 */

export { AsEsqTreeNodePipe, EsqAccessProfile, EsqColumnHeaderDef, EsqCommandMenuItem, EsqContextMenuBuilder, EsqEntityDictionary, EsqEntityField, EsqEntityLayer, EsqExplorerCallApi, EsqExplorerHostDummy, EsqNodeStatus, EsqNodeStatusFactory, EsqObjectKind, EsqObjectKindFactory, EsqPermission, EsqRole, EsqTreeNode, EsqTreeNodeDto, EsqUtils, SelectMode, problemDetailDictionary };
//# sourceMappingURL=mir0n-pro-esquire.ui-api.mjs.map
