const version = '1.0.2';

/**
 * Generated bundle index. Do not edit.
 */

export { version };
//# sourceMappingURL=mir0n-pro-esquire.ui.mjs.map
