import * as _angular_core from '@angular/core';
import { OnInit, OnDestroy, AfterViewInit, ElementRef, QueryList } from '@angular/core';
import { MatTree } from '@angular/material/tree';
import { MatSidenav } from '@angular/material/sidenav';
import { EsqTreeNode, EsqRestApi, EsqExplorerHostDummy, EsqExplorerCallApi, EsqCommandMenuItem, EsqSubMenuItem, EsqAccessProfile, EsqColumnHeaderDef, EsqNewMenuItem, SelectMode } from '@mir0n-pro/esquire.ui/api';
import { DataSource, CollectionViewer } from '@angular/cdk/collections';
import { Observable } from 'rxjs';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';

declare class EsqTreeViewDatasource implements DataSource<EsqTreeNode> {
    private SIZE_REQUESTED;
    private dataShown;
    private dataInternal;
    private dataTree;
    private api;
    constructor(api: EsqRestApi);
    get data(): EsqTreeNode[];
    toggleSelection(node: EsqTreeNode): void;
    select(node: EsqTreeNode): void;
    loadInitialData(): Promise<void>;
    connect(collectionViewer: CollectionViewer): Observable<EsqTreeNode[]>;
    disconnect(collectionViewer: CollectionViewer): void;
    loadMoreChildren(parent: EsqTreeNode): Promise<void>;
    private loadMore;
    private countNodesUnder;
    private lastChild;
    countNodesUnderInternal(node: EsqTreeNode, all: boolean): number;
    private countNodesUnderTree;
    private countNodesUnderPublic;
    private removeNodesUnderTree;
    toggleNode(node: EsqTreeNode): Promise<void>;
    private cleanCollapsed;
    isVisible(node: EsqTreeNode): boolean;
    loadChildren(node: EsqTreeNode): Promise<void>;
    private loadMoreInternal;
    getById(id: string): EsqTreeNode | undefined;
    findInSublings(id: string, parent: EsqTreeNode): Promise<EsqTreeNode | undefined>;
    clear(): void;
    getPath(id: string): Promise<string[]>;
    hasMoreChildren(parent: EsqTreeNode): boolean;
    getChildren(parent_id: string): EsqTreeNode[];
    getAll(): EsqTreeNode[];
}

declare class EsqListViewDatasource implements DataSource<EsqTreeNode> {
    private static DEFAULT_HEADER;
    private header;
    private treeDatasource;
    private dataChange;
    constructor(treeDatasource: EsqTreeViewDatasource);
    connect(collectionViewer: CollectionViewer): Observable<EsqTreeNode[]>;
    disconnect(collectionViewer: CollectionViewer): void;
    get data(): EsqTreeNode[];
    loadChildren(node: EsqTreeNode): Promise<void>;
    clear(): void;
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 04/12/2026 mir0n  initial: account-picker tree datasource interface
* 04/14/2026 mir0n  findById split into findByNodeId / findByEntityId
* 04/17/2026 mir0n  import consolidation
*/

/**
 * Interface for the entity-picker tree datasource.
 * Implemented by EsqSelectEntityDatasource; returned by EsqFlatTreeDatasource.createFlatTreeSelector().
 */
interface EsqFlatTreeSelector {
    selectDs: {
        connect: () => Observable<EsqTreeNode[]>;
        disconnect: () => void;
    };
    levelAccessor: (node: EsqTreeNode) => number;
    ensureLoaded(): Promise<void>;
    toggleNode(node: EsqTreeNode): Promise<void>;
    isExpandable(node: EsqTreeNode): boolean;
    findByNodeId(id: string): EsqTreeNode | null;
    findByEntityId(id: string): EsqTreeNode | null;
    expandToNode(entityId: string): Promise<EsqTreeNode | null>;
    reset(): void;
}
interface EsqFlatTreeSelectorFactory {
    createFlatTreeSelector(kinds: Set<number>, isLeaf?: (node: EsqTreeNode) => boolean): EsqFlatTreeSelector;
}

declare class EsqFlatTreeDatasource implements EsqFlatTreeSelectorFactory {
    private api;
    tree: EsqTreeViewDatasource;
    list: EsqListViewDatasource;
    private selectorsMap;
    constructor(api: EsqRestApi);
    loadInitialData(): Promise<void>;
    get data4tree(): EsqTreeNode[];
    get data4list(): EsqTreeNode[];
    loadChildren(node: EsqTreeNode): Promise<void>;
    toggleOnTree(node: EsqTreeNode): Promise<void>;
    isVisibleOnTree(node: EsqTreeNode): boolean;
    toggleTreeSelection(node: EsqTreeNode): void;
    selectOnTree(node: EsqTreeNode): void;
    clear(): void;
    createFlatTreeSelector(kinds: Set<number>, isLeaf?: (node: EsqTreeNode) => boolean): EsqFlatTreeSelector;
    getById(id: string): EsqTreeNode | undefined;
    loadNodesPath(path: string[]): Promise<EsqTreeNode | undefined>;
    gotoListNode(id: string): Promise<EsqTreeNode | undefined>;
    gotoTreeNode(id: string): Promise<EsqTreeNode | undefined>;
    hasMoreChildren(parent: EsqTreeNode): boolean;
    getOrgNodes(): EsqTreeNode[];
    loadMoreChildren(parent: EsqTreeNode): Promise<void>;
}

declare class EsqExplorerComponent extends EsqExplorerHostDummy implements OnInit, OnDestroy, AfterViewInit {
    private dialog;
    esqRestApi: EsqRestApi | null;
    esqExplorerCallApi: EsqExplorerCallApi | null;
    esqCommandMenuItems: EsqCommandMenuItem[];
    activeSubItems: EsqSubMenuItem[];
    activeCmd: string;
    esqAccessProfile: EsqAccessProfile | null;
    esqDatasource?: EsqFlatTreeDatasource;
    esqSubItemDisabled?: (cmd: string, subCmd: string, node: EsqTreeNode | null) => boolean;
    treeLevelAccessor: (dataNode: EsqTreeNode) => number;
    datasource: EsqFlatTreeDatasource;
    listColumns: EsqColumnHeaderDef[];
    listColumnsDisplayed: string[];
    listNodeFocused: EsqTreeNode | null;
    listNodeOwner: EsqTreeNode | null;
    listNodeExecuted: EsqTreeNode | null;
    listNodeHoveredIndex: number;
    listNodeOwnerPath: _angular_core.WritableSignal<string>;
    errorMessage: _angular_core.WritableSignal<string>;
    errorReport: any;
    listNodeHistoryStack: EsqTreeNode[];
    listNodeHistoryIndex: number;
    treeNodePostFocus: EsqTreeNode | null;
    treeNodeActive: EsqTreeNode | null;
    treeNodeEntered: EsqTreeNode | null;
    treeNodeLastFocus: EsqTreeNode | null;
    _tree: MatTree<EsqTreeNode>;
    sidenav: MatSidenav;
    private contextMenuTrigger;
    menuItemOpen: ElementRef;
    menuItemDetails: ElementRef;
    contextMenuPosition: {
        x: number;
        y: number;
    };
    contextMenuNode: EsqTreeNode | null;
    contextMenuInList: boolean;
    contextMenuParent: EsqTreeNode | null;
    contextNewMenuItems: EsqNewMenuItem[];
    toolbarNewMenuItems: EsqNewMenuItem[];
    treeItself: MatTree<EsqTreeNode>;
    matRows: QueryList<ElementRef>;
    initialDataLoading: _angular_core.WritableSignal<boolean>;
    dataLoading: _angular_core.WritableSignal<boolean>;
    treeOnFocus: boolean;
    constructor(dialog: MatDialog);
    ngAfterViewInit(): Promise<void>;
    onTreeRefresh(entityId?: string, asOwner?: boolean): void;
    setLoading(on: boolean): void;
    onBtnRefreshClickAndSelect(entityId: string): Promise<void>;
    onBtnRefreshClickAndSelectOwner(entityId: string): Promise<void>;
    ngOnInit(): Promise<void>;
    toggleSideNav(): void;
    /**
     * Get datasource for external command handler registration
     */
    getDatasource(): EsqFlatTreeDatasource;
    ngOnDestroy(): void;
    hasIcon(node: EsqTreeNode): boolean;
    nodeIcon(node: EsqTreeNode): string;
    nodeStatusIcon(node: EsqTreeNode): string;
    updatePath(): void;
    rightButtonsCount(): number;
    private findDefaultMenuItem;
    private openContextMenu;
    onListContextMenu(event: MouseEvent, node: EsqTreeNode): void;
    onTreeContextMenu(event: MouseEvent, node: EsqTreeNode): void;
    onEmptyListContextMenu(event: MouseEvent): void;
    onEmptyTreeContextMenu(event: MouseEvent): void;
    updateToolbarNewMenuItems(): void;
    private getSelectedNode;
    canCmdClick(cmd: string, menu: boolean): boolean;
    canCreateKind(kindId: number): boolean;
    onCmdClick(cmd: string, menu: boolean): Promise<void>;
    canCmdNewClick(menu: boolean): boolean;
    onCmdNewClick(typeId: number, menu: boolean): Promise<void>;
    canSubCmdClick(item: EsqCommandMenuItem, menu: boolean): boolean;
    prepareSubmenu(item: EsqCommandMenuItem, menu: boolean): void;
    protected isSubItemDisabled(cmd: string, subCmd: string, node: EsqTreeNode | null): boolean;
    onSubCmdClick(subCmd: string, menu: boolean): Promise<void>;
    canMenuOpenClick(): boolean;
    onMenuOpenClick(): Promise<void>;
    canCmdDetailsClick(menu: boolean): boolean;
    onCmdDetailsClick(menu: boolean): Promise<void>;
    canCmdGotoClick(menu: boolean): boolean;
    onCmdGotoClick(menu: boolean): Promise<void>;
    canCmdBackClick(): boolean;
    onCmdBackClick(): Promise<void>;
    canCmdForwardClick(): boolean;
    onCmdForwardClick(): Promise<void>;
    canCmdUpClick(): boolean;
    onCmdUpClick(): Promise<void>;
    onBtnRefreshClick(): Promise<void>;
    canBtnMoreClick(): boolean;
    onBtnMoreClick(): Promise<void>;
    doExplorerCommand(cmd: string, subCmd: string | null, node: EsqTreeNode | undefined | null, selectMode?: SelectMode): Promise<void>;
    doExplorerCreate(node: EsqTreeNode | null, typeId?: number): Promise<void>;
    onListFocus(node: EsqTreeNode): void;
    onListFocusOut(node: EsqTreeNode): void;
    onListClick(node: any): void;
    onListDoubleClick(node: any): void;
    private isKeyPlain;
    private isOnlyCtrl;
    private isOnlyAlt;
    onListKeydown(event: KeyboardEvent, node: EsqTreeNode, index: number): Promise<void>;
    onListArrowdown(node: EsqTreeNode, index: number): void;
    onListArrowup(node: EsqTreeNode, index: number): void;
    onTreeClick(node: any): void;
    onTreeDoubleClick(node: any): void;
    onTreeNodeEnter(node: EsqTreeNode): void;
    onTreeNodeLeave(): void;
    onTreeNodeExpansion($event: boolean, node: EsqTreeNode): Promise<void>;
    onTreeFocus(node: EsqTreeNode): void;
    onTreeFocusOut(node: EsqTreeNode): void;
    onTreeKeydown(event: KeyboardEvent, node: EsqTreeNode): Promise<void>;
    onTreeLeft(node: EsqTreeNode): void;
    onTreeRight(node: EsqTreeNode): void;
    doSelectListNode(node: EsqTreeNode, focused: boolean): void;
    doDefaultListNode(): Promise<void>;
    doActivateListExecuted(): void;
    doActivateListNode(node: EsqTreeNode, listFocused: boolean): Promise<void>;
    setFocusTreeNode(node: EsqTreeNode): void;
    toggleTreeSelect(node: EsqTreeNode): void;
    toggleTreeActivate(node: EsqTreeNode | undefined | null, listFocused: boolean): void;
    toggleTreeExpandSelect(node: EsqTreeNode): void;
    doTreeExpandSelect(node: EsqTreeNode): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EsqExplorerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<EsqExplorerComponent, "esqExplorer", never, { "esqRestApi": { "alias": "esqRestApi"; "required": false; }; "esqExplorerCallApi": { "alias": "esqExplorerCallApi"; "required": false; }; "esqCommandMenuItems": { "alias": "esqCommandMenuItems"; "required": false; }; "esqAccessProfile": { "alias": "esqAccessProfile"; "required": false; }; "esqDatasource": { "alias": "esqDatasource"; "required": false; }; "esqSubItemDisabled": { "alias": "esqSubItemDisabled"; "required": false; }; }, {}, never, never, true, never>;
}

declare class EsqSelectEntityDialog extends EsqExplorerHostDummy implements AfterViewInit, OnInit, OnDestroy {
    protected dialogRef: MatDialogRef<EsqSelectEntityDialog>;
    protected userId: string;
    protected dialogTitle: string;
    protected resizeKey: string;
    protected headerIcon: string;
    protected selectedNode: EsqTreeNode | null;
    protected hoveredNode: EsqTreeNode | null;
    loading: _angular_core.WritableSignal<boolean>;
    protected treeDs: EsqFlatTreeSelector;
    protected preSelectedId: string;
    protected callApi?: EsqExplorerCallApi;
    constructor(dialogRef: MatDialogRef<EsqSelectEntityDialog>, data: any);
    ngOnInit(): void;
    ngOnDestroy(): void;
    setLoading(on: boolean): void;
    ngAfterViewInit(): void;
    private toggleSelectNode;
    protected onToggleClick(node: EsqTreeNode, event: MouseEvent): void;
    protected onToggleDblClick(node: EsqTreeNode, event: MouseEvent): Promise<void>;
    protected onNodeClick(node: EsqTreeNode): void;
    protected onNodeDblClick(node: EsqTreeNode): Promise<void>;
    protected onNodeKeydown(event: KeyboardEvent, node: EsqTreeNode): Promise<void>;
    protected isSelectable(node: EsqTreeNode): boolean;
    protected canSelect(): boolean;
    protected onSelect(): Promise<void>;
    protected onCancel(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EsqSelectEntityDialog, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<EsqSelectEntityDialog, "esq-select-entity-dialog", never, {}, {}, never, never, true, never>;
}

export { EsqExplorerComponent, EsqFlatTreeDatasource, EsqSelectEntityDialog };
export type { EsqFlatTreeSelector, EsqFlatTreeSelectorFactory };
