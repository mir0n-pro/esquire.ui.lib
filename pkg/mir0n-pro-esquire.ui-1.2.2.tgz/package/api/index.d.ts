import { Observable } from 'rxjs';
import * as _angular_core from '@angular/core';
import { PipeTransform } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

declare class EsqRole {
    id: number;
    name: string;
    adminFlg: string;
    constructor(jsn: any);
}
declare class EsqPermission {
    id: string;
    kind: number;
    name: string;
    type: string;
    flags: string[];
    constructor(jsn: any);
}
declare class EsqAccessProfile {
    id: string;
    kind: number;
    name: string;
    loginId: string;
    email: string;
    pwdChangeForced: string;
    tfaMethod: string;
    roles: EsqRole[];
    admin: EsqPermission[];
    tools: EsqPermission[];
    constructor(jsn: any);
    private static flagIndexes;
    isCommandAllowed(cmd: string, entity_id: string, kind: number): boolean;
    static addFlagIndex(flag: string, index: number): void;
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 12/24/2025 mir0n listvalues_kind moved inside of generic format
* 02/13/2026 mir0n EsqNodeType renamed with EsqObjectKind
* 02/17/2026 mir0n added personal, minmax fields
*                  nullable changed from boolean to string
* 03/20/2026 mir0n  affects3 optional field added
* 03/28/2026 mir0n  default optional field added; mapped from jsn['default']
* 04/07/2026 mir0n  constructor param renamed entity_kind → entityKind
*/
declare class EsqEntityField {
    name: string;
    sort: number;
    label: string;
    type: string;
    tooltip: string;
    listvalues: string[];
    nullable: string;
    nullmeaning: string;
    validation: string;
    layer: number;
    readwrite: number;
    format: string;
    personal: string;
    minmax: string;
    affects3?: string;
    default?: string;
    constructor(jsn: any);
}
declare class EsqEntityDictionary {
    kind: number;
    layers: EsqEntityLayer[];
    constructor(entityKind: number, jsn: any);
}
declare class EsqEntityLayer {
    title: string;
    fields: EsqEntityField[];
    constructor(jsn: any);
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 02/28/2026 mir0n  added dictionaryFromCache() to interface
* 04/07/2026 mir0n  removed stale commented-out interface line
*/

interface EsqDictionaryApi {
    dictionary(entityKind: number): Observable<EsqEntityLayer[]>;
    /** Sync: return cached layers if present; otherwise null/empty */
    dictionaryFromCache(entityKind: number): EsqEntityLayer[];
}

interface ProblemDetail {
    type: string;
    traceId: string;
    title: string;
    status: number;
    detail: string;
    instance?: string;
    errors?: Array<{
        fieldName: string;
        fieldLabel: string;
        message: string;
        tabIndex: string;
    }>;
    timestamp?: string;
    requestId?: string;
    correlationId?: string;
    processingTime?: string;
    stackTrace?: string;
}
declare const problemDetailDictionary: EsqEntityLayer[];

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 02/13/2026 mir0n removed treeFlags
* 02/13/2026 mir0n kind renamed to kindId (protected)
*                  EsqNodeType renamed with EsqObjectKind
*/
declare class EsqTreeNodeDto {
    id: string;
    parentId: string;
    linkId: string;
    name: string;
    protected kindId: number;
    entityId: string;
    statusCode: number;
    moreRemaining: boolean;
    level: number;
    path: string[];
    desc: string;
    all: any;
    constructor(jsn?: any);
    value(columnRef: string): string;
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 02/13/2026 mir0n EsqNodeType renamed with EsqObjectKind
*/
declare class EsqColumnHeaderDef {
    columnDef?: string;
    header?: string;
    constructor(jsn?: any);
}
declare class EsqObjectKind {
    id: number;
    name: string;
    title: string;
    plural: string;
    desc: string;
    org: boolean;
    usr: boolean;
    acct: boolean;
    icon: string;
    detailed: boolean;
    childrenDetailed: boolean;
    treeFlags: string;
    listHeaders: EsqColumnHeaderDef[];
    childKinds: number[];
    commands: string[];
    constructor(jsn?: any);
    isCommandAllowed(cmd: string): boolean;
    isNewAllowed(): boolean;
}

declare class EsqTreeNode extends EsqTreeNodeDto {
    loading: _angular_core.WritableSignal<boolean>;
    expandable: _angular_core.WritableSignal<boolean>;
    selected: _angular_core.WritableSignal<boolean>;
    hasMore: _angular_core.WritableSignal<boolean>;
    hasChild: _angular_core.WritableSignal<boolean>;
    expanded: _angular_core.WritableSignal<boolean>;
    kind: EsqObjectKind;
    parent?: EsqTreeNode;
    private loadingMutex;
    constructor(jsn?: any, parent?: EsqTreeNode);
    setLoading(flag: boolean): Promise<void>;
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 12/24/2025 mir0n kind parameter is requried for esq-cmd, esq-enode
* 02/01/2026 miron added esquireKey()
* 02/12/2026 miron added esquireKinds()
* 02/18/2026 mir0n  added esquireCmdSave(), esquireKeySave()
* 03/26/2026 mir0n  added esquireCmdNew to interface
* 03/28/2026 mir0n  added esquireCmdDel to interface
* 03/31/2026 mir0n  esquireCmdMove added to interface
* 04/09/2026 mir0n  esquireCmdAcct added to interface
* 04/10/2026 mir0n  removed esquireCmdAcct
*/

interface EsqRestApi {
    esquire: (id?: string, skip?: number, take?: number, options?: any) => Observable<any>;
    esquirePath: (id: string, options?: any) => Observable<any>;
    esquireCmd: (kind: number, id: string, cmd?: string, options?: any) => Observable<any>;
    esquireEntityNode: (kind: number, id?: string, name?: string, options?: any) => Observable<any>;
    esquireDictionary: (kind: number, options?: any) => Observable<any>;
    esquireKey: (id?: string, options?: any) => Observable<any>;
    esquireKinds: () => Observable<any>;
    esquireCmdSave: (kind: number, id: string, body: any, cmd?: string, options?: any) => Observable<any>;
    esquireKeySave: (id: string, body: any, options?: any) => Observable<any>;
    esquireCmdNew: (kind: number, parentId: string, body: any, cmd?: string, options?: any) => Observable<any>;
    esquireCmdDel: (kind: number, id: string, cmd?: string, options?: any) => Observable<any>;
    esquireCmdMove: (kind: number, id: string, distId: string, options?: any) => Observable<any>;
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 04/01/2026 mir0n  initial: command handler interface and context type for calle() refactoring
* 04/07/2026 mir0n  EsqNodeCommandContext: added nodeKind (normalized entity kind for REST calls)
* 04/10/2026 mir0n  added EsqCommandSubmitter interface
*/

interface EsqCommandSubmitter {
    submit(kind: number, id: string, body: any): Observable<any>;
}

declare enum SelectMode {
    None = 0,// no refresh, no select
    Refresh = 1,// refresh tree, no select
    SelectTree = 2,// refresh + select entity in tree
    SelectList = 3
}
/**
 * Context object passed to entity command handlers (calle() path)
 */
interface EsqEntityCommandContext {
    cmd: string;
    subCmd: string | null;
    entityId: string;
    entityName: string;
    entityKind: number;
    accessProfile: EsqAccessProfile | null;
    selectMode: SelectMode;
    dialog: MatDialog;
    restApi: EsqRestApi;
    dictionaryApi: EsqDictionaryApi;
    callApi: EsqExplorerCallApi;
    host?: EsqExplorerHost;
    userId: string;
}
/**
 * Context object passed to node command handlers (call() path)
 */
interface EsqNodeCommandContext {
    cmd: string;
    subCmd: string | null;
    node: EsqTreeNode;
    nodeKind: number;
    accessProfile: EsqAccessProfile | null;
    selectMode: SelectMode;
    dialog: MatDialog;
    restApi: EsqRestApi;
    dictionaryApi: EsqDictionaryApi;
    callApi: EsqExplorerCallApi;
    host?: EsqExplorerHost;
    userId: string;
}
/**
 * Interface for entity command handlers
 * Handlers process both call() and calle() commands dispatched through EsqExplorerCallApiMill
 */
interface EsqEntityCommandHandler {
    /**
     * Check if this handler can process the given command
     */
    canHandle(cmd: string): boolean;
    /**
     * Execute the command with node-based context (from call())
     */
    executeWithNode(context: EsqNodeCommandContext): Promise<void>;
    /**
     * Execute the command with entity-based context (from calle())
     */
    executeWithEntity(context: EsqEntityCommandContext): Promise<void>;
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 02/01/2026 mir0n  added create()
* 02/17/2026 mir0n  added CMD_ command constants
*                   use EsqAccessProfile from esquire.ui/api
* 03/20/2026 mir0n  EsqExplorerHost interface; registerHost added to EsqExplorerCallApi
* 03/26/2026 mir0n  onTreeRefreshSelect(), setErrorMessage() added to EsqExplorerHost
* 03/26/2026 mir0n  confirmDlg() added to interface; ConfirmFlag enum; focus param
* 03/28/2026 mir0n  EsqExplorerHost: onTreeRefresh(entityId?, asOwner?) consolidates onTreeRefresh + onTreeRefreshSelect
* 04/02/2026 mir0n  call(): added subCmd, selectMode
*                   calle(): added subCmd, selectMode
*                   added registerHandler()
* 04/07/2026 mir0n  calle() param renamed to entityKind
* 04/08/2028 mir0n  added EsqExplorerHost.setLoading()
*                   added EsqExplorerCallApi.unregisterHost()
*                   added EsqExplorerHostDummy
* 04/10/2026 mir0n  removed CMD_ACCT
*/

interface EsqExplorerHost {
    onTreeRefresh(entityId?: string, asOwner?: boolean): void;
    setErrorMessage(msg: string, err?: any): void;
    setLoading(on: boolean): void;
}
declare class EsqExplorerHostDummy implements EsqExplorerHost {
    onTreeRefresh(entityId?: string, asOwner?: boolean): void;
    setErrorMessage(msg: string, err?: any): void;
    setLoading(on: boolean): void;
}
interface EsqExplorerCallApi {
    call: (cmd: string, subCmd: string | null, node: EsqTreeNode, accessProfile: EsqAccessProfile | null, selectMode?: SelectMode) => Promise<void>;
    calle: (cmd: string, subCmd: string | null, entity_id: string, entity_name: string, entityKind: number, accessProfile: EsqAccessProfile | null, selectMode?: SelectMode) => Promise<void>;
    create: (parent_node: EsqTreeNode, typeId?: number) => Promise<void>;
    registerHost: (host: EsqExplorerHost) => void;
    unregisterHost: (host: EsqExplorerHost) => void;
    registerHandler(handler: EsqEntityCommandHandler): void;
    confirmDlg: (kind: EsqObjectKind | null, header: string, text: string, flag: EsqExplorerCallApi.ConfirmFlag, focus?: number) => Promise<number>;
}
declare namespace EsqExplorerCallApi {
    const CMD_DEFAULT: string;
    const CMD_NEW: string;
    const CMD_MOVE: string;
    const CMD_DELETE: string;
    const CMD_KEY: string;
    enum ConfirmFlag {
        Ok = 0,// alert-style: single OK button, no X
        YesNo = 1,// Yes / No buttons
        OkCancel = 2
    }
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
*/
declare class EsqNodeStatus {
    id: number;
    name: string;
    icon: string;
    constructor(id: number, name: string, icon: string);
}
declare class EsqNodeStatusFactory {
    private static dictionary;
    static UNKNOWN: EsqNodeStatus;
    private constructor();
    static init(dictionary: EsqNodeStatus[]): void;
    static instanceOf(statusId: number): EsqNodeStatus;
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 02/01/2026 mir0n  added childTypes array
*                   added commands array
*                   added isCommandAllowed()
*                   added isNewAllowed()
*                   added ACCESSPROFILE virtual note type
* 02/12/2026 mir0n  EsqNodeType in explicit file
*                   init() loading from server and keeps ability to be defined locally
* 02/13/2026 mir0n EsqNodeType renamed with EsqObjectKind
* 02/28/2026 mir0n  added static kinds: PERSON_PRIMARY (992), ADDRESS_POSTAL (988), ADDRESS_BIZ (990)
* 04/07/2026 mir0n  added static normalize(kind): number
* 04/08/2026 mir0n  init() corrected
* 04/13/2026 mir0n  init() registers locally-defined kinds absent from server response
* 04/15/2026 mir0n  pass kind title from server response
*/

declare class EsqObjectKindFactory {
    private static kinds;
    static UNKNOWN: EsqObjectKind;
    static MORE: EsqObjectKind;
    static ACCESSPROFILE: EsqObjectKind;
    static PERSON_PRIMARY: EsqObjectKind;
    static ADDRESS_POSTAL: EsqObjectKind;
    static ADDRESS_BIZ: EsqObjectKind;
    private constructor();
    private static update;
    static init(api: EsqRestApi | null | undefined, kinds: readonly EsqObjectKind[] | null | undefined): Promise<void>;
    static normalize(kind: number): number;
    static instanceOf(kind: number): EsqObjectKind;
    static getAllowedChildTypes(parent: EsqTreeNode | null | undefined): EsqObjectKind[];
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
*/

declare class AsEsqTreeNodePipe implements PipeTransform {
    transform(value: unknown, ...args: unknown[]): EsqTreeNode;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AsEsqTreeNodePipe, never>;
    static ɵpipe: _angular_core.ɵɵPipeDeclaration<AsEsqTreeNodePipe, "asEsqTreeNode", true>;
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 02/12/2026 mir0n  EsqNodeType in explicit file
* 02/13/2026 mir0n EsqNodeType renamed with EsqObjectKind
* 02/17/2026 mir0n CMD_ constants moved to EsqExplorerCallApi
* 04/13/2026 mir0n  EsqSubMenuItem interface; subItems on EsqCommandMenuItem for generic submenu support
*/

interface EsqNewMenuItem {
    label: string;
    icon: string;
    kind: EsqObjectKind;
}
interface EsqSubMenuItem {
    label: string;
    icon: string;
    subCmd: string;
    disabled?: boolean;
}
declare class EsqCommandMenuItem {
    label: string;
    icon: string;
    cmd: string;
    subItems?: EsqSubMenuItem[];
    constructor(label: string, icon: string, cmd: string, subItems?: EsqSubMenuItem[]);
}
declare class EsqContextMenuBuilder {
    static buildNewMenuItems(parent: EsqTreeNode | null | undefined): EsqNewMenuItem[];
}

interface EsqValidationError {
    fieldName: string;
    fieldLabel: string;
    message: string;
    tabIndex: number;
}

declare class EsqUtils {
    static DEBUG: boolean;
    static DELAY: boolean;
    static DEBUG_SKIP_VALIDATION: boolean;
    static DEBUG_SKIP_PERMISSION: boolean;
    private constructor();
    static log(...par: any): void;
    static observeDelay(ms: number): Observable<never>;
    static observeWithDelay<T>(obs: Observable<T>, ms: number): Observable<T>;
    static asyncDelay(ms: number): Promise<void>;
    /**
     * Format a number using pattern string.
     * # = optional digit, 0 = required digit, = use thousand separators
     * Examples: #,##0.## (default), #,##0.00, 0, 0.00, #,##0.####
     */
    static formatNumber(value: any, format?: string): string;
    static parseNumber(formatted: string): number | null;
    static validateFields(details: any, dictionary: EsqEntityLayer[]): EsqValidationError | null;
    static deepCopy(obj: any): any;
    static errorMessage(err: any): string;
    static getChangedFields(original: any, current: any): Record<string, any> | null;
}

export { AsEsqTreeNodePipe, EsqAccessProfile, EsqColumnHeaderDef, EsqCommandMenuItem, EsqContextMenuBuilder, EsqEntityDictionary, EsqEntityField, EsqEntityLayer, EsqExplorerCallApi, EsqExplorerHostDummy, EsqNodeStatus, EsqNodeStatusFactory, EsqObjectKind, EsqObjectKindFactory, EsqPermission, EsqRole, EsqTreeNode, EsqTreeNodeDto, EsqUtils, SelectMode, problemDetailDictionary };
export type { EsqCommandSubmitter, EsqDictionaryApi, EsqEntityCommandContext, EsqEntityCommandHandler, EsqExplorerHost, EsqNewMenuItem, EsqNodeCommandContext, EsqRestApi, EsqSubMenuItem, EsqValidationError, ProblemDetail };
