declare const version = "1.0.2";

export { version };
