import * as i0 from '@angular/core';
import { signal, HostListener, Inject, ViewEncapsulation, Component, afterEveryRender, ElementRef, ViewChildren, ViewChild, Input } from '@angular/core';
import { MatTree, MatTreeNode, MatTreeNodeDef, MatTreeNodePadding } from '@angular/material/tree';
import * as i7 from '@angular/material/table';
import { MatTableModule, MatRow } from '@angular/material/table';
import * as i2 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i6 from '@angular/material/icon';
import { MatIconModule, MatIcon } from '@angular/material/icon';
import * as i3 from '@angular/material/toolbar';
import { MatToolbarModule } from '@angular/material/toolbar';
import * as i6$1 from '@angular/material/tooltip';
import { MatTooltipModule } from '@angular/material/tooltip';
import * as i4 from '@angular/material/button';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import * as i5$1 from '@angular/material/sidenav';
import { MatSidenavModule } from '@angular/material/sidenav';
import { EsqUtils, EsqTreeNode, EsqExplorerHostDummy, EsqObjectKindFactory, EsqExplorerCallApi, SelectMode, EsqNodeStatusFactory, EsqContextMenuBuilder, AsEsqTreeNodePipe } from '@mir0n-pro/esquire.ui/api';
import { EsqDialogResizeDirective, EsqResizeDirective } from '@mir0n-pro/esquire.ui/components';
import { BehaviorSubject, firstValueFrom } from 'rxjs';
import * as i8 from '@angular/material/menu';
import { MatMenuModule, MatMenuTrigger } from '@angular/material/menu';
import * as i9 from '@angular/material/divider';
import { MatDividerModule } from '@angular/material/divider';
import * as i1 from '@angular/material/dialog';
import { MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import * as i5 from '@angular/cdk/drag-drop';
import { DragDropModule } from '@angular/cdk/drag-drop';

class EsqTreeViewDatasource {
    SIZE_REQUESTED = 10;
    dataShown = new BehaviorSubject([]);
    dataInternal = [];
    dataTree = [];
    api;
    constructor(api) {
        this.api = api;
    }
    get data() {
        return this.dataShown.value;
    }
    toggleSelection(node) {
        if (node.selected()) {
            node.selected.set(false);
        }
        else {
            this.dataInternal.forEach(x => x.selected.update(y => y = false));
            node.selected.set(true);
        }
    }
    select(node) {
        if (!node.selected()) {
            this.dataInternal.forEach(x => x.selected.update(y => y = false));
            node.selected.set(true);
        }
    }
    async loadInitialData() {
        EsqUtils.log('loadInitialData[');
        let rootNodes = await firstValueFrom(this.api.esquire());
        let treeNodes = rootNodes.map((x) => new EsqTreeNode(x)); //xxx we do not have any parent for root
        this.dataInternal = [...treeNodes];
        this.dataTree = [...treeNodes];
        this.dataShown.next(this.dataInternal);
        EsqUtils.log(']loadInitialData');
    }
    connect(collectionViewer) {
        return this.dataShown.asObservable();
    }
    disconnect(collectionViewer) {
        this.dataShown.complete();
    }
    async loadMoreChildren(parent) {
        let node = this.lastChild(this.dataInternal, parent);
        if (node && node.hasMore()) {
            await this.loadMore(node);
        }
    }
    async loadMore(node) {
        await node.setLoading(true);
        try {
            EsqUtils.log('loadMore[');
            let siblings;
            try {
                // staing on a child node, we load more brothers/systers
                if (node.parent) {
                    let index = this.countNodesUnderInternal(node.parent, false);
                    let jsn = await firstValueFrom(this.api.esquire(node.parentId, index, this.SIZE_REQUESTED));
                    if (jsn && Array.isArray(jsn) && jsn.length > 0) {
                        siblings = jsn.map((x) => new EsqTreeNode(x, node.parent));
                    }
                    if (siblings && siblings.length > 0) {
                        let grandchildren = this.countNodesUnderInternal(node, true);
                        //EsqUtils.log("loaded:", siblings.length, "after:", this.data.indexOf(node), "+", grandchildren);
                        this.dataInternal.splice(this.dataInternal.indexOf(node) + 1 + grandchildren, 0, ...siblings);
                        let cnt = this.countNodesUnderInternal(node.parent, true);
                        //EsqUtils.log("updated internal:", siblings.length, "->" + cnt);
                        let cntTree = this.countNodesUnderTree(node.parent, true);
                        if (cntTree == cnt) {
                            EsqUtils.log(1, "Achtung!!! more sublings, somehow, already on the tree...");
                        }
                        else {
                            let grandchildren = this.countNodesUnderTree(node, true);
                            siblings = siblings.filter((x) => x.expandable());
                            if (siblings.length > 0) {
                                this.dataTree.splice(this.dataTree.indexOf(node) + 1 + grandchildren, 0, ...siblings);
                            }
                        }
                        //EsqUtils.log("updated shown:", siblings.length, "->" + this.countNodesUnderShown(node.parent,false));
                        this.dataShown.next(this.dataTree);
                    }
                    else {
                        //EsqUtils.log("not loaded:", siblings);
                    }
                }
            }
            catch (error) {
                console.error(error);
            }
            this.cleanCollapsed();
            node.hasMore.update(x => false);
        }
        finally {
            EsqUtils.log(']loadMore');
            node.setLoading(false);
        }
    }
    countNodesUnder(data, node, all) {
        let count = 0;
        let indexData = data.indexOf(node);
        for (let i = indexData + 1; i < data.length; i++) {
            if (data[i].level > node.level) {
                if (all) {
                    count++;
                }
                else if (data[i].level == node.level + 1) {
                    count++;
                }
            }
            else {
                //end of node 
                break;
            }
        }
        return count;
    }
    lastChild(data, node) {
        let lastNode = undefined;
        let indexData = data.indexOf(node);
        for (let i = indexData + 1; i < data.length; i++) {
            if (data[i].level > node.level) {
                if (data[i].level == node.level + 1) {
                    lastNode = data[i];
                }
            }
            else {
                //end of node 
                break;
            }
        }
        return lastNode;
    }
    countNodesUnderInternal(node, all) {
        return this.countNodesUnder(this.dataInternal, node, all);
    }
    countNodesUnderTree(node, all) {
        return this.countNodesUnder(this.dataTree, node, all);
    }
    countNodesUnderPublic(node, all) {
        return this.countNodesUnder(this.data, node, all);
    }
    removeNodesUnderTree(node) {
        let count = this.countNodesUnderTree(node, true);
        let indexTree = this.dataTree.indexOf(node);
        if (count > 0) {
            //EsqUtils.log('remove children',count);
            let removed = this.dataTree.splice(indexTree + 1, count);
            removed.forEach((x) => { x.expanded.set(false); x.selected.set(false); });
            //      this.dataChange.next(this.data);
        }
    }
    async toggleNode(node) {
        const expand = !node.expanded();
        let hasMore = true;
        if (!node.expandable()) {
            return;
        }
        let indexTree = this.dataTree.indexOf(node);
        let indexData = this.dataInternal.indexOf(node);
        if (indexTree < 0 || indexData < 0) {
            return;
        }
        await node.setLoading(true);
        try {
            EsqUtils.log('toggleNode[');
            node.expanded.update((x) => !x);
            const childrenData = this.dataInternal.filter(x => x.parentId == node.id);
            const childrenTree = this.dataTree.filter(x => x.parentId == node.id);
            EsqUtils.log('childrenShown.childrenTree:', childrenData.length, 'childrenData.length:', childrenData.length);
            if (expand) {
                if (childrenTree.length == 0) {
                    if (childrenData.length == 0) {
                        let jsn = await firstValueFrom(this.api.esquire(node.id, 0, this.SIZE_REQUESTED));
                        let children = jsn.map((x) => new EsqTreeNode(x, node));
                        if (children && children.length > 0) {
                            this.dataInternal.splice(indexData + 1, 0, ...children);
                            children = children.filter((x) => x.expandable());
                            if (this.countNodesUnderTree(node, false) > 0) {
                                EsqUtils.log(indexTree, 'Achtung!!! somehow children added there:', this.countNodesUnderTree(node, false));
                                this.dataShown.next(this.dataTree);
                            }
                            else {
                                //removeNodesUnder
                                if (children.length > 0) {
                                    this.dataTree.splice(indexTree + 1, 0, ...children);
                                }
                                this.dataShown.next(this.dataTree);
                            }
                        }
                    }
                    else {
                        let children = childrenData.filter((x) => x.expandable());
                        if (children.length > 0) {
                            this.dataTree.splice(indexTree + 1, 0, ...children);
                        }
                        this.dataShown.next(this.dataTree);
                    }
                }
                else {
                    this.dataShown.next(this.dataTree);
                }
            }
            else {
                if (childrenTree.length > 0) {
                    // Otherwise, if the node is being collapsed, 
                    // work out how many nodes are children
                    this.removeNodesUnderTree(node);
                    this.dataShown.next(this.dataTree);
                }
            }
            //something wierd going on: uncontrollable adding nodes to non-expanend nodes
            this.cleanCollapsed();
        }
        finally {
            EsqUtils.log(']toggleNode');
            node.setLoading(false);
        }
    }
    cleanCollapsed() {
        var doItAgan = true;
        while (doItAgan) {
            doItAgan = false;
            for (let i = 0; i < this.dataTree.length; i++) {
                let nd = this.dataTree[i];
                if (!nd.expanded()) {
                    let cnt = this.countNodesUnderTree(nd, false);
                    if (cnt > 0) {
                        EsqUtils.log(i, 'Achtung!!! node is collapsed but shows kids', cnt);
                        this.removeNodesUnderTree(nd);
                        this.dataShown.next(this.dataTree);
                        cnt = this.countNodesUnderTree(nd, false);
                        EsqUtils.log(i, 'after removal: ', cnt);
                        doItAgan = true;
                    }
                }
            }
        }
    }
    isVisible(node) {
        const i = this.dataInternal.indexOf(node);
        const i2 = this.data.indexOf(node);
        const i3 = this.dataShown.value.indexOf(node);
        const index = this.dataTree.indexOf(node);
        return index >= 0;
    }
    ///xxx only for leaf database : out of lock;
    async loadChildren(node) {
        EsqUtils.log('loadChildren[');
        //extend on internal only
        const index = this.dataInternal.indexOf(node);
        if (index >= 0 && node.expandable()) {
            let cnt = this.countNodesUnderInternal(node, false);
            if (cnt == 0) {
                let jsn = await firstValueFrom(this.api.esquire(node.id, 0, this.SIZE_REQUESTED));
                let children = jsn.map((x) => new EsqTreeNode(x, node));
                if (children && children.length > 0) {
                    this.dataInternal.splice(index + 1, 0, ...children);
                }
            }
        }
        EsqUtils.log(']loadChildren');
    }
    async loadMoreInternal(node) {
        EsqUtils.log('loadMoreInternal[');
        //    await node.setLoading(true);
        try {
            let siblings;
            try {
                // staing on a child node, we load more brothers/systers
                if (node.parent) {
                    let index = this.countNodesUnderInternal(node.parent, false);
                    let jsn = await firstValueFrom(this.api.esquire(node.parentId, index, this.SIZE_REQUESTED));
                    if (jsn && Array.isArray(jsn) && jsn.length > 0) {
                        siblings = jsn.map((x) => new EsqTreeNode(x, node.parent));
                    }
                    if (siblings && siblings.length > 0) {
                        let grandchildren = this.countNodesUnderInternal(node, true);
                        this.dataInternal.splice(this.dataInternal.indexOf(node) + 1 + grandchildren, 0, ...siblings);
                        let cnt = this.countNodesUnderInternal(node.parent, true);
                    }
                }
            }
            catch (error) {
                console.error(error);
            }
            node.hasMore.update(x => false);
        }
        finally {
            EsqUtils.log(']loadMoreInternal');
            //      node.setLoading(false);
        }
    }
    getById(id) {
        let ret = undefined;
        const found = this.dataInternal.filter(x => x.id == id);
        if (found && found.length > 0) {
            ret = found[0];
        }
        return ret;
    }
    async findInSublings(id, parent) {
        EsqUtils.log('findInSublings[');
        var ret = undefined;
        var cnt = this.countNodesUnderInternal(parent, false);
        if (cnt == 0) {
            await this.loadChildren(parent);
        }
        ret = this.getById(id);
        if (!ret) {
            var lastKid = this.lastChild(this.dataInternal, parent);
            if (lastKid) {
                while (!ret && lastKid.hasMore()) {
                    await this.loadMoreInternal(lastKid);
                    ret = this.getById(id);
                    lastKid = this.lastChild(this.dataInternal, parent);
                }
            }
        }
        EsqUtils.log(']findInSublings', ret);
        return ret;
    }
    clear() {
        this.dataInternal = [];
        this.dataTree = [];
        this.dataShown.next(this.dataInternal);
    }
    async getPath(id) {
        var jsn = await firstValueFrom(this.api.esquirePath(id));
        var ret = [];
        if (jsn && Array.isArray(jsn) && jsn.length > 0) {
            ret = jsn;
        }
        return ret;
    }
    hasMoreChildren(parent) {
        var lastKid = this.lastChild(this.dataInternal, parent);
        return (lastKid ? lastKid.hasMore() : false);
    }
    getChildren(parent_id) {
        return this.dataInternal.filter(x => x.parentId == parent_id);
    }
    getAll() {
        return [...this.dataInternal];
    }
}

class EsqListViewDatasource {
    static DEFAULT_HEADER = [{ columnDef: "name", header: "Name" }];
    header;
    treeDatasource;
    dataChange = new BehaviorSubject([]);
    constructor(treeDatasource) {
        this.treeDatasource = treeDatasource;
        this.header = EsqListViewDatasource.DEFAULT_HEADER;
    }
    connect(collectionViewer) {
        //return this.dataChange;
        return this.dataChange.asObservable();
    }
    disconnect(collectionViewer) {
        this.dataChange.complete();
    }
    get data() {
        return this.dataChange.value;
    }
    async loadChildren(node) {
        await node.setLoading(true);
        try {
            EsqUtils.log('list.loadChildren[');
            if (node.kind.listHeaders.length > 0) {
                this.header = node.kind.listHeaders;
            }
            else {
                this.header = EsqListViewDatasource.DEFAULT_HEADER;
            }
            let cnt = this.treeDatasource.countNodesUnderInternal(node, false);
            if (cnt == 0) {
                await this.treeDatasource.loadChildren(node);
                cnt = this.treeDatasource.countNodesUnderInternal(node, false);
                EsqUtils.log('loadChildren:loaded:', cnt);
            }
            this.dataChange.next([]);
            let children = this.treeDatasource.getChildren(node.id);
            this.dataChange.next(children);
            EsqUtils.log('loadChildren:posted:', children);
        }
        finally {
            EsqUtils.log(']list.loadChildren');
            node.setLoading(false);
        }
    }
    clear() {
        this.dataChange.next([]);
    }
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 04/12/2026 mir0n  initial: generic tree-selector datasource; wraps EsqTreeViewDatasource;
* 04/14/2026 mir0n  findByNodeId / findByEntityId split; findByEntityId expression corrected
* 04/17/2026 mir0n  import consolidation
*/
/**
 * Generic datasource for a filtered tree-picker dialog.
 * Created by EsqFlatTreeDatasource.createFlatTreeSelector(kinds).
 * Wraps the shared EsqTreeViewDatasource; non-expandable nodes fetched via REST into extraNodes[].
 * Expandable nodes (with 'B' treeFlag) delegate to treeDs.toggleNode().
 */
class EsqSelectEntityDatasource {
    treeDs;
    restApi;
    kinds;
    isLeaf;
    loaded = false;
    extraNodes = [];
    treeSubj = new BehaviorSubject([]);
    selectDs = {
        connect: () => this.treeSubj.asObservable(),
        disconnect: () => { }
    };
    levelAccessor = (node) => node.level;
    constructor(treeDs, restApi, kinds, isLeaf = () => false) {
        this.treeDs = treeDs;
        this.restApi = restApi;
        this.kinds = kinds;
        this.isLeaf = isLeaf;
    }
    async ensureLoaded() {
        if (!this.loaded) {
            if (this.treeDs.getAll().length === 0) {
                await this.treeDs.loadInitialData();
            }
            this.treeDs.getAll()
                .filter(n => this.isInKinds(n) && !n.expandable() && n.expanded())
                .forEach(n => n.expanded.set(false));
            this.extraNodes = [];
            this.loaded = true;
        }
        this.publishVisible();
    }
    reset() {
        this.loaded = false;
        this.extraNodes = [];
    }
    async toggleNode(node) {
        if (!this.isExpandable(node))
            return;
        if (!node.expanded()) {
            var hasChildren = this.allNodes().some(n => n.parentId === node.id);
            if (!hasChildren) {
                if (node.expandable()) {
                    await this.treeDs.toggleNode(node);
                }
                else {
                    await node.setLoading(true);
                    try {
                        var raw = await firstValueFrom(this.restApi.esquire(node.id, 0, 200));
                        var children = raw.map((x) => new EsqTreeNode(x, node)).filter(n => this.isInKinds(n));
                        this.extraNodes.push(...children);
                    }
                    finally {
                        await node.setLoading(false);
                    }
                    node.expanded.set(true);
                }
            }
            else {
                if (node.expandable()) {
                    await this.treeDs.toggleNode(node);
                }
                else {
                    node.expanded.set(true);
                }
            }
        }
        else {
            this.collapseSubtree(node);
            if (node.expandable()) {
                await this.treeDs.toggleNode(node);
            }
            else {
                node.expanded.set(false);
            }
        }
        this.publishVisible();
    }
    isExpandable(node) {
        return !this.isLeaf(node);
    }
    findByNodeId(id) {
        var ret = this.allNodes().find(n => id === n.id) ?? null;
        return ret;
    }
    findByEntityId(id) {
        var ret = this.allNodes().find(n => id === n.entityId ? n.entityId : '') ?? null;
        return ret;
    }
    async expandToNode(entityId) {
        var path = await this.treeDs.getPath(entityId);
        if (!path || path.length === 0)
            return null;
        for (var pathId of path) {
            var ancestor = this.allNodes().find(n => n.id === pathId);
            if (ancestor && this.isExpandable(ancestor) && !ancestor.expanded()) {
                await this.toggleNode(ancestor);
            }
        }
        return this.findByNodeId(entityId);
    }
    allNodes() {
        return [
            ...this.treeDs.getAll().filter(n => this.isInKinds(n)),
            ...this.extraNodes,
        ];
    }
    isInKinds(node) {
        return this.kinds.has(node.kind.id);
    }
    collapseSubtree(node) {
        this.allNodes().forEach(n => {
            if (this.isDescendantOf(n, node))
                n.expanded.set(false);
        });
    }
    isDescendantOf(n, ancestor) {
        var cur = n.parent;
        while (cur) {
            if (cur === ancestor)
                return true;
            cur = cur.parent;
        }
        return false;
    }
    isVisible(node) {
        var cur = node.parent;
        while (cur) {
            if (!cur.expanded())
                return false;
            cur = cur.parent;
        }
        return true;
    }
    publishVisible() {
        this.treeSubj.next(this.allNodes().filter(n => this.isVisible(n)));
    }
}

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 03/20/2026 mir0n  gotoTreeNode(): navigate to tree node by id; expands ancestors
* 03/31/2026 mir0n  getOrgNodes(): filter loaded nodes to org kind
* 04/08/2026 mir0n  remove logDelay()
* 04/12/2026 mir0n  implements EsqFlatTreeSelectorFactory; createFlatTreeSelector(kinds, isLeaf?); selectorsMap cache; reset clears selectors
* 04/17/2026 mir0n  import consolidation
*/
class EsqFlatTreeDatasource {
    api;
    tree;
    list;
    selectorsMap = new Map();
    constructor(api) {
        this.api = api;
        this.tree = new EsqTreeViewDatasource(api);
        this.list = new EsqListViewDatasource(this.tree);
    }
    async loadInitialData() {
        return this.tree.loadInitialData();
    }
    get data4tree() {
        return this.tree.data;
    }
    get data4list() {
        return this.list.data;
    }
    async loadChildren(node) {
        return this.list.loadChildren(node);
    }
    async toggleOnTree(node) {
        return this.tree.toggleNode(node);
    }
    isVisibleOnTree(node) {
        return this.tree.isVisible(node);
    }
    toggleTreeSelection(node) {
        this.tree.toggleSelection(node);
    }
    selectOnTree(node) {
        this.tree.select(node);
    }
    clear() {
        this.list.clear();
        this.tree.clear();
        this.selectorsMap.forEach(s => s.reset());
    }
    createFlatTreeSelector(kinds, isLeaf) {
        var key = [...kinds].sort((a, b) => a - b).join(',');
        var cached = this.selectorsMap.get(key);
        if (cached)
            return cached;
        var bigApi = { ...this.api, esquire: (id, skip, _take, opts) => this.api.esquire(id, skip, 200, opts) };
        var selector = new EsqSelectEntityDatasource(this.tree, bigApi, kinds, isLeaf);
        this.selectorsMap.set(key, selector);
        return selector;
    }
    getById(id) {
        return this.tree.getById(id);
    }
    async loadNodesPath(path) {
        EsqUtils.log('loadNodesPath[', path);
        var lev = 0;
        var ret = undefined;
        if (path && path.length > 0) {
            const root = this.tree.getById(path[0]);
            ret = root;
            if (root) {
                for (let i = 1; ret && i < path.length; i++) {
                    let n = await this.tree.findInSublings(path[i], ret);
                    if (n instanceof EsqTreeNode) {
                        ret = n;
                    }
                }
            }
        }
        EsqUtils.log(']loadNodesPath', ret);
        return ret;
    }
    async gotoListNode(id) {
        EsqUtils.log('gotoListNode[');
        const path = await this.tree.getPath(id);
        var treeNode = undefined;
        var listNode = undefined;
        if (path && path.length > 0) {
            path[path.length] = id;
            let res = await this.loadNodesPath(path);
            if (res instanceof EsqTreeNode) {
                listNode = res;
                treeNode = listNode.parent;
            }
        }
        if (treeNode) {
            var treeNodes = [];
            for (let i = 0; i < path.length - 1; i++) {
                treeNodes[i] = this.tree.getById(path[i]);
            }
            for (let i = 0; i < treeNodes.length; i++) {
                if (treeNodes[i].expandable() && !treeNodes[i].expanded()) {
                    await this.tree.toggleNode(treeNodes[i]);
                }
            }
            await this.list.loadChildren(treeNode);
        }
        EsqUtils.log(']gotoListNode');
        return listNode;
    }
    async gotoTreeNode(id) {
        EsqUtils.log('gotoTreeNode[');
        const path = await this.tree.getPath(id);
        var treeNode = undefined;
        if (path && path.length > 0) {
            path[path.length] = id;
            let res = await this.loadNodesPath(path);
            if (res instanceof EsqTreeNode) {
                treeNode = res;
                for (let i = 0; i < path.length - 1; i++) {
                    let ancestor = this.tree.getById(path[i]);
                    if (ancestor && ancestor.expandable() && !ancestor.expanded()) {
                        await this.tree.toggleNode(ancestor);
                    }
                }
            }
        }
        EsqUtils.log(']gotoTreeNode');
        return treeNode;
    }
    hasMoreChildren(parent) {
        return this.tree.hasMoreChildren(parent);
    }
    getOrgNodes() {
        return this.tree.getAll().filter((n) => n.kind.org);
    }
    async loadMoreChildren(parent) {
        var collapse = parent.expandable() && !parent.expanded();
        if (collapse) {
            await this.tree.toggleNode(parent);
        }
        await this.tree.loadMoreChildren(parent);
        await this.list.loadChildren(parent);
        if (collapse) {
            await this.tree.toggleNode(parent);
        }
    }
}

/**
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
* History :
* 04/12/2026 mir0n  initial: generic entity picker dialog;
* 04/14/2026 mir0n  onSelect() normalizes kind via EsqObjectKindFactory.normalize(); preSelectedId protected; canSelect() cleanup
* 04/17/2026 mir0n  import consolidation
*/
class EsqSelectEntityDialog extends EsqExplorerHostDummy {
    dialogRef;
    userId;
    dialogTitle;
    resizeKey;
    headerIcon;
    selectedNode = null;
    hoveredNode = null;
    loading = signal(false, ...(ngDevMode ? [{ debugName: "loading" }] : []));
    treeDs;
    preSelectedId = '';
    //private postFocusNodeId: string | null = null;
    callApi;
    constructor(dialogRef, data) {
        super();
        this.dialogRef = dialogRef;
        this.userId = data.userId || '';
        this.preSelectedId = data.entityId ? String(data.entityId) : '';
        this.treeDs = data.treeDs;
        this.dialogTitle = data.title || 'Select';
        this.resizeKey = data.resizeKey || ('select-entity:' + this.userId);
        this.headerIcon = data.headerIcon || '';
        this.callApi = data.callApi;
    }
    ngOnInit() {
        this.callApi?.registerHost(this);
    }
    ngOnDestroy() {
        this.callApi?.unregisterHost(this);
    }
    setLoading(on) {
        this.loading.set(on);
    }
    ngAfterViewInit() {
        this.loading.set(true);
        this.treeDs.ensureLoaded()
            .then(() => {
            if (!this.preSelectedId)
                return Promise.resolve();
            return this.treeDs.expandToNode(this.preSelectedId)
                .then(node => {
                if (node) {
                    this.selectedNode = node;
                    // this.postFocusNodeId = node.id;
                    // trick: give the DOM time to render the node: max 0.5sec
                    //for (var i = 0; i < 50; i++) {
                    var el = document.getElementById('select-entity-node-' + node.id);
                    if (el) {
                        setTimeout(() => {
                            el.focus();
                        }, 10);
                        //        break;
                    }
                    //}
                }
            });
        })
            .finally(() => this.loading.set(false));
    }
    async toggleSelectNode(node) {
        await this.treeDs.toggleNode(node);
    }
    onToggleClick(node, event) {
        event.stopPropagation();
        void this.toggleSelectNode(node);
    }
    async onToggleDblClick(node, event) {
        event.stopPropagation();
        await this.toggleSelectNode(node);
    }
    onNodeClick(node) {
        this.selectedNode = node;
    }
    async onNodeDblClick(node) {
        this.selectedNode = node;
        if (this.canSelect()) {
            this.onSelect();
        }
        else if (this.treeDs.isExpandable(node)) {
            await this.toggleSelectNode(node);
        }
    }
    async onNodeKeydown(event, node) {
        switch (event.key) {
            case 'Enter':
                event.preventDefault();
                this.selectedNode = node;
                if (this.canSelect())
                    this.onSelect();
                break;
            case ' ':
                event.preventDefault();
                this.selectedNode = node;
                break;
            case 'ArrowLeft':
                event.preventDefault();
                if (node.expanded()) {
                    await this.toggleSelectNode(node);
                }
                break;
            case 'ArrowRight':
                event.preventDefault();
                if (this.treeDs.isExpandable(node) && !node.expanded()) {
                    await this.toggleSelectNode(node);
                }
                break;
        }
    }
    isSelectable(node) {
        return true;
    }
    canSelect() {
        var ret = false;
        if (this.selectedNode) {
            ret = this.isSelectable(this.selectedNode);
        }
        return ret;
    }
    async onSelect() {
        if (!this.canSelect() || !this.selectedNode)
            return;
        this.dialogRef.close({
            entityId: String(this.selectedNode.entityId),
            entityKind: EsqObjectKindFactory.normalize(this.selectedNode.kind.id),
            entityName: this.selectedNode.name,
        });
    }
    onCancel() {
        this.dialogRef.close(null);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqSelectEntityDialog, deps: [{ token: i1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: EsqSelectEntityDialog, isStandalone: true, selector: "esq-select-entity-dialog", host: { listeners: { "keydown.escape": "onCancel()" } }, usesInheritance: true, ngImport: i0, template: "<!--\r\n  Esquire frameworks (tm)\r\n\r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"resizeKey\"\r\n>\r\n  <div>\r\n    @if (loading()) {\r\n      <span class=\"esq-loading-div\"></span>\r\n    } @else if (headerIcon) {\r\n      <img [src]=\"headerIcon\" class=\"esq-base-icon\"/>\r\n    } @else {\r\n      <span style=\"width:24px;display:inline-block;\"></span>\r\n    }\r\n  </div>\r\n  <div>{{dialogTitle}}</div>\r\n  <button class=\"esq-select-entity-close-btn\" (click)=\"onCancel()\">&#x2715;</button>\r\n</mat-toolbar>\r\n\r\n<div class=\"esq-select-entity-tree-panel\">\r\n  <mat-tree [dataSource]=\"treeDs.selectDs\" [levelAccessor]=\"treeDs.levelAccessor\">\r\n    <mat-tree-node *matTreeNodeDef=\"let node\" matTreeNodePadding matTreeNodePaddingIndent=\"16\"\r\n        id=\"select-entity-node-{{node.id}}\"\r\n        class=\"esq-select-entity-tree-node\"\r\n        tabindex=\"0\"\r\n        [ngClass]=\"{\r\n            'esq-select-entity-active-node': selectedNode === node,\r\n            'esq-select-entity-mouse-node': hoveredNode === node && selectedNode !== node\r\n        }\"\r\n        (click)=\"onNodeClick(node)\"\r\n        (dblclick)=\"onNodeDblClick(node)\"\r\n        (keydown)=\"onNodeKeydown($event, node)\"\r\n        (mouseenter)=\"hoveredNode = node\"\r\n        (mouseleave)=\"hoveredNode = null\"\r\n        (focus)=\"hoveredNode = node\"\r\n        (blur)=\"hoveredNode = null\">\r\n      @if (treeDs.isExpandable(node)) {\r\n        <mat-icon class=\"esq-select-entity-toggle-icon\"\r\n          (click)=\"onToggleClick(node, $event)\"\r\n          (dblclick)=\"onToggleDblClick(node, $event)\">{{node.expanded() ? 'expand_more' : 'chevron_right'}}</mat-icon>\r\n      } @else {\r\n        <span style=\"width:24px;display:inline-block;flex-shrink:0;\"></span>\r\n      }\r\n      <img [src]=\"node.kind.icon\" class=\"esq-base-icon\"/>\r\n      <span class=\"esq-select-entity-overlay-text\">{{node.name}}</span>\r\n    </mat-tree-node>\r\n  </mat-tree>\r\n</div>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  <button mat-raised-button [disabled]=\"!canSelect()\" (click)=\"onSelect()\">Select</button>\r\n  <button mat-raised-button (click)=\"onCancel()\">Cancel</button>\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-activation-note{margin:4px 16px 0;padding:10px 12px;border:1px solid #c9190b;border-left:4px solid #c9190b;border-radius:3px;background:#faeae8;color:#7d1007;font-size:10pt;font-weight:500;line-height:1.35}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n", "esq-select-entity-dialog,esq-select-acct-dialog,esq-move-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-select-entity-tree-panel{background:#fff;border:1px solid #bbb;box-shadow:inset 1px 1px 3px #00000026;margin:4px 10px;overflow-y:auto;flex:1 1 auto;min-height:0}.esq-select-entity-tree-node{display:flex;align-items:center;font-size:12px;min-height:18px;cursor:pointer}.esq-select-entity-close-btn{display:flex;align-items:center;justify-content:center;width:24px;height:24px;font-size:14px;line-height:1;background:none;border:none;cursor:pointer;padding:0;color:inherit}.esq-select-entity-close-btn:hover{background:#00000014}.esq-select-entity-toggle-icon{width:24px;height:24px;font-size:18px;flex-shrink:0;cursor:pointer;-webkit-user-select:none;user-select:none}.esq-select-entity-active-node{background-color:#add8e6!important}.esq-select-entity-mouse-node{background-color:#e8f5fa}.esq-select-entity-overlay-text{font-size:9pt;font-weight:400;margin-left:2px}esq-select-entity-dialog mat-dialog-actions button:first-child,esq-select-acct-dialog mat-dialog-actions button:first-child,esq-move-dialog mat-dialog-actions button:first-child{border:1px solid #888}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatToolbarModule }, { kind: "component", type: i3.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i5.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i5.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "component", type: MatTree, selector: "mat-tree", exportAs: ["matTree"] }, { kind: "directive", type: MatTreeNode, selector: "mat-tree-node", inputs: ["tabIndex", "disabled"], outputs: ["activation", "expandedChange"], exportAs: ["matTreeNode"] }, { kind: "directive", type: MatTreeNodeDef, selector: "[matTreeNodeDef]", inputs: ["matTreeNodeDefWhen", "matTreeNode"] }, { kind: "directive", type: MatTreeNodePadding, selector: "[matTreeNodePadding]", inputs: ["matTreeNodePadding", "matTreeNodePaddingIndent"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i6.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: EsqDialogResizeDirective, selector: "[esqDialogResize]", inputs: ["esqDialogResize"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqSelectEntityDialog, decorators: [{
            type: Component,
            args: [{ selector: 'esq-select-entity-dialog', standalone: true, imports: [
                        CommonModule,
                        MatToolbarModule,
                        MatButtonModule,
                        MatDialogModule,
                        DragDropModule,
                        MatTree,
                        MatTreeNode,
                        MatTreeNodeDef,
                        MatTreeNodePadding,
                        MatIconModule,
                        EsqDialogResizeDirective,
                    ], encapsulation: ViewEncapsulation.None, template: "<!--\r\n  Esquire frameworks (tm)\r\n\r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"resizeKey\"\r\n>\r\n  <div>\r\n    @if (loading()) {\r\n      <span class=\"esq-loading-div\"></span>\r\n    } @else if (headerIcon) {\r\n      <img [src]=\"headerIcon\" class=\"esq-base-icon\"/>\r\n    } @else {\r\n      <span style=\"width:24px;display:inline-block;\"></span>\r\n    }\r\n  </div>\r\n  <div>{{dialogTitle}}</div>\r\n  <button class=\"esq-select-entity-close-btn\" (click)=\"onCancel()\">&#x2715;</button>\r\n</mat-toolbar>\r\n\r\n<div class=\"esq-select-entity-tree-panel\">\r\n  <mat-tree [dataSource]=\"treeDs.selectDs\" [levelAccessor]=\"treeDs.levelAccessor\">\r\n    <mat-tree-node *matTreeNodeDef=\"let node\" matTreeNodePadding matTreeNodePaddingIndent=\"16\"\r\n        id=\"select-entity-node-{{node.id}}\"\r\n        class=\"esq-select-entity-tree-node\"\r\n        tabindex=\"0\"\r\n        [ngClass]=\"{\r\n            'esq-select-entity-active-node': selectedNode === node,\r\n            'esq-select-entity-mouse-node': hoveredNode === node && selectedNode !== node\r\n        }\"\r\n        (click)=\"onNodeClick(node)\"\r\n        (dblclick)=\"onNodeDblClick(node)\"\r\n        (keydown)=\"onNodeKeydown($event, node)\"\r\n        (mouseenter)=\"hoveredNode = node\"\r\n        (mouseleave)=\"hoveredNode = null\"\r\n        (focus)=\"hoveredNode = node\"\r\n        (blur)=\"hoveredNode = null\">\r\n      @if (treeDs.isExpandable(node)) {\r\n        <mat-icon class=\"esq-select-entity-toggle-icon\"\r\n          (click)=\"onToggleClick(node, $event)\"\r\n          (dblclick)=\"onToggleDblClick(node, $event)\">{{node.expanded() ? 'expand_more' : 'chevron_right'}}</mat-icon>\r\n      } @else {\r\n        <span style=\"width:24px;display:inline-block;flex-shrink:0;\"></span>\r\n      }\r\n      <img [src]=\"node.kind.icon\" class=\"esq-base-icon\"/>\r\n      <span class=\"esq-select-entity-overlay-text\">{{node.name}}</span>\r\n    </mat-tree-node>\r\n  </mat-tree>\r\n</div>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  <button mat-raised-button [disabled]=\"!canSelect()\" (click)=\"onSelect()\">Select</button>\r\n  <button mat-raised-button (click)=\"onCancel()\">Cancel</button>\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-activation-note{margin:4px 16px 0;padding:10px 12px;border:1px solid #c9190b;border-left:4px solid #c9190b;border-radius:3px;background:#faeae8;color:#7d1007;font-size:10pt;font-weight:500;line-height:1.35}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n", "esq-select-entity-dialog,esq-select-acct-dialog,esq-move-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-select-entity-tree-panel{background:#fff;border:1px solid #bbb;box-shadow:inset 1px 1px 3px #00000026;margin:4px 10px;overflow-y:auto;flex:1 1 auto;min-height:0}.esq-select-entity-tree-node{display:flex;align-items:center;font-size:12px;min-height:18px;cursor:pointer}.esq-select-entity-close-btn{display:flex;align-items:center;justify-content:center;width:24px;height:24px;font-size:14px;line-height:1;background:none;border:none;cursor:pointer;padding:0;color:inherit}.esq-select-entity-close-btn:hover{background:#00000014}.esq-select-entity-toggle-icon{width:24px;height:24px;font-size:18px;flex-shrink:0;cursor:pointer;-webkit-user-select:none;user-select:none}.esq-select-entity-active-node{background-color:#add8e6!important}.esq-select-entity-mouse-node{background-color:#e8f5fa}.esq-select-entity-overlay-text{font-size:9pt;font-weight:400;margin-left:2px}esq-select-entity-dialog mat-dialog-actions button:first-child,esq-select-acct-dialog mat-dialog-actions button:first-child,esq-move-dialog mat-dialog-actions button:first-child{border:1px solid #888}\n"] }]
        }], ctorParameters: () => [{ type: i1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }], propDecorators: { onCancel: [{
                type: HostListener,
                args: ['keydown.escape']
            }] } });

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 03/31/2026 mir0n  initial: org-only tree, confirm inside dialog, keyboard/mouse nav
* 04/02/2026 mir0n  lazy initialization of flatTreeDataSource
*                   message(s) text corrected
* 04/07/2026 mir0n  movingNodeKind from data.nodeKind; use for esquireCmdMove
* 04/12/2026 mir0n  extend EsqSelectEntityDialog; MOVE_TREE_KINDS={0,20}; drop own tree/BehaviorSubject;
*                   callApi inherited from base (removed duplicate field)
* 04/17/2026 mir0n  import consolidation
*/
class EsqMoveDialog extends EsqSelectEntityDialog {
    static MOVE_TREE_KINDS = new Set([0, 20]);
    movingNode;
    movingNodeKind;
    restApi;
    constructor(dialogRef, data) {
        var movingNode = data.node;
        var orgParent = movingNode.parent;
        while (orgParent && !orgParent.kind.org)
            orgParent = orgParent.parent;
        data.title = 'Move: ' + movingNode.name;
        data.resizeKey = 'move:' + (data.userId || '');
        data.headerIcon = movingNode.kind.icon;
        data.entityId = orgParent?.entityId || '';
        data.treeDs = data.selectorFactory?.createFlatTreeSelector(EsqMoveDialog.MOVE_TREE_KINDS);
        super(dialogRef, data);
        this.movingNode = movingNode;
        this.movingNodeKind = data.nodeKind;
        this.restApi = data.restApi;
    }
    isSelectable(node) {
        return node.kind.org;
    }
    canSelect() {
        var ret = false;
        if (this.selectedNode) {
            var sameParent = this.selectedNode.entityId === this.orgParentEntityId();
            if (!sameParent) {
                if (this.movingNode.kind.org) {
                    ret = !this.isAncestorOrSelf(this.movingNode, this.selectedNode);
                }
                else {
                    ret = true;
                }
            }
        }
        return ret;
    }
    async onSelect() {
        if (!this.canSelect() || !this.selectedNode)
            return;
        var dest = this.selectedNode;
        var confirmed = await this.callApi.confirmDlg(null, 'Move ' + this.movingNode.name, 'Move "' + this.movingNode.name + '" to "' + dest.name + '". Are you sure?', EsqExplorerCallApi.ConfirmFlag.YesNo, 0);
        if (confirmed !== 0) {
            return;
        }
        try {
            await firstValueFrom(this.restApi.esquireCmdMove(this.movingNodeKind, this.movingNode.entityId, dest.entityId));
            this.dialogRef.close(true);
        }
        catch (err) {
            var errMsg = EsqUtils.errorMessage(err);
            await this.callApi.confirmDlg(null, this.movingNode.name + ' Move Error', 'Move failed: ' + errMsg, EsqExplorerCallApi.ConfirmFlag.Ok);
        }
    }
    orgParentEntityId() {
        var node = this.movingNode.parent;
        while (node && !node.kind.org)
            node = node.parent;
        return node?.entityId ?? '';
    }
    isAncestorOrSelf(moving, dest) {
        var ret = dest.entityId === moving.entityId;
        var node = dest.parent;
        while (!ret && node) {
            ret = node.entityId === moving.entityId;
            node = node.parent;
        }
        return ret;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqMoveDialog, deps: [{ token: i1.MatDialogRef }, { token: MAT_DIALOG_DATA }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: EsqMoveDialog, isStandalone: true, selector: "esq-move-dialog", usesInheritance: true, ngImport: i0, template: "<!--\r\n  Esquire frameworks (tm)\r\n\r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"resizeKey\"\r\n>\r\n  <div>\r\n    @if (loading()) {\r\n      <span class=\"esq-loading-div\"></span>\r\n    } @else if (headerIcon) {\r\n      <img [src]=\"headerIcon\" class=\"esq-base-icon\"/>\r\n    } @else {\r\n      <span style=\"width:24px;display:inline-block;\"></span>\r\n    }\r\n  </div>\r\n  <div>{{dialogTitle}}</div>\r\n  <button class=\"esq-select-entity-close-btn\" (click)=\"onCancel()\">&#x2715;</button>\r\n</mat-toolbar>\r\n\r\n<div class=\"esq-select-entity-tree-panel\">\r\n  <mat-tree [dataSource]=\"treeDs.selectDs\" [levelAccessor]=\"treeDs.levelAccessor\">\r\n    <mat-tree-node *matTreeNodeDef=\"let node\" matTreeNodePadding matTreeNodePaddingIndent=\"16\"\r\n        id=\"select-entity-node-{{node.id}}\"\r\n        class=\"esq-select-entity-tree-node\"\r\n        tabindex=\"0\"\r\n        [ngClass]=\"{\r\n            'esq-select-entity-active-node': selectedNode === node,\r\n            'esq-select-entity-mouse-node': hoveredNode === node && selectedNode !== node\r\n        }\"\r\n        (click)=\"onNodeClick(node)\"\r\n        (dblclick)=\"onNodeDblClick(node)\"\r\n        (keydown)=\"onNodeKeydown($event, node)\"\r\n        (mouseenter)=\"hoveredNode = node\"\r\n        (mouseleave)=\"hoveredNode = null\"\r\n        (focus)=\"hoveredNode = node\"\r\n        (blur)=\"hoveredNode = null\">\r\n      @if (treeDs.isExpandable(node)) {\r\n        <mat-icon class=\"esq-select-entity-toggle-icon\"\r\n          (click)=\"onToggleClick(node, $event)\"\r\n          (dblclick)=\"onToggleDblClick(node, $event)\">{{node.expanded() ? 'expand_more' : 'chevron_right'}}</mat-icon>\r\n      } @else {\r\n        <span style=\"width:24px;display:inline-block;flex-shrink:0;\"></span>\r\n      }\r\n      <img [src]=\"node.kind.icon\" class=\"esq-base-icon\"/>\r\n      <span class=\"esq-select-entity-overlay-text\">{{node.name}}</span>\r\n    </mat-tree-node>\r\n  </mat-tree>\r\n</div>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  <button mat-raised-button [disabled]=\"!canSelect()\" (click)=\"onSelect()\">Select</button>\r\n  <button mat-raised-button (click)=\"onCancel()\">Cancel</button>\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-activation-note{margin:4px 16px 0;padding:10px 12px;border:1px solid #c9190b;border-left:4px solid #c9190b;border-radius:3px;background:#faeae8;color:#7d1007;font-size:10pt;font-weight:500;line-height:1.35}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n", "esq-select-entity-dialog,esq-select-acct-dialog,esq-move-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-select-entity-tree-panel{background:#fff;border:1px solid #bbb;box-shadow:inset 1px 1px 3px #00000026;margin:4px 10px;overflow-y:auto;flex:1 1 auto;min-height:0}.esq-select-entity-tree-node{display:flex;align-items:center;font-size:12px;min-height:18px;cursor:pointer}.esq-select-entity-close-btn{display:flex;align-items:center;justify-content:center;width:24px;height:24px;font-size:14px;line-height:1;background:none;border:none;cursor:pointer;padding:0;color:inherit}.esq-select-entity-close-btn:hover{background:#00000014}.esq-select-entity-toggle-icon{width:24px;height:24px;font-size:18px;flex-shrink:0;cursor:pointer;-webkit-user-select:none;user-select:none}.esq-select-entity-active-node{background-color:#add8e6!important}.esq-select-entity-mouse-node{background-color:#e8f5fa}.esq-select-entity-overlay-text{font-size:9pt;font-weight:400;margin-left:2px}esq-select-entity-dialog mat-dialog-actions button:first-child,esq-select-acct-dialog mat-dialog-actions button:first-child,esq-move-dialog mat-dialog-actions button:first-child{border:1px solid #888}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatToolbarModule }, { kind: "component", type: i3.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i4.MatButton, selector: "    button[matButton], a[matButton], button[mat-button], button[mat-raised-button],    button[mat-flat-button], button[mat-stroked-button], a[mat-button], a[mat-raised-button],    a[mat-flat-button], a[mat-stroked-button]  ", inputs: ["matButton"], exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatDialogModule }, { kind: "directive", type: i1.MatDialogActions, selector: "[mat-dialog-actions], mat-dialog-actions, [matDialogActions]", inputs: ["align"] }, { kind: "ngmodule", type: DragDropModule }, { kind: "directive", type: i5.CdkDrag, selector: "[cdkDrag]", inputs: ["cdkDragData", "cdkDragLockAxis", "cdkDragRootElement", "cdkDragBoundary", "cdkDragStartDelay", "cdkDragFreeDragPosition", "cdkDragDisabled", "cdkDragConstrainPosition", "cdkDragPreviewClass", "cdkDragPreviewContainer", "cdkDragScale"], outputs: ["cdkDragStarted", "cdkDragReleased", "cdkDragEnded", "cdkDragEntered", "cdkDragExited", "cdkDragDropped", "cdkDragMoved"], exportAs: ["cdkDrag"] }, { kind: "directive", type: i5.CdkDragHandle, selector: "[cdkDragHandle]", inputs: ["cdkDragHandleDisabled"] }, { kind: "component", type: MatTree, selector: "mat-tree", exportAs: ["matTree"] }, { kind: "directive", type: MatTreeNode, selector: "mat-tree-node", inputs: ["tabIndex", "disabled"], outputs: ["activation", "expandedChange"], exportAs: ["matTreeNode"] }, { kind: "directive", type: MatTreeNodeDef, selector: "[matTreeNodeDef]", inputs: ["matTreeNodeDefWhen", "matTreeNode"] }, { kind: "directive", type: MatTreeNodePadding, selector: "[matTreeNodePadding]", inputs: ["matTreeNodePadding", "matTreeNodePaddingIndent"] }, { kind: "ngmodule", type: MatIconModule }, { kind: "component", type: i6.MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "directive", type: EsqDialogResizeDirective, selector: "[esqDialogResize]", inputs: ["esqDialogResize"] }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqMoveDialog, decorators: [{
            type: Component,
            args: [{ selector: 'esq-move-dialog', standalone: true, imports: [
                        CommonModule,
                        MatToolbarModule,
                        MatButtonModule,
                        MatDialogModule,
                        DragDropModule,
                        MatTree,
                        MatTreeNode,
                        MatTreeNodeDef,
                        MatTreeNodePadding,
                        MatIconModule,
                        EsqDialogResizeDirective,
                    ], encapsulation: ViewEncapsulation.None, template: "<!--\r\n  Esquire frameworks (tm)\r\n\r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<mat-toolbar class=\"mat-elevation-z2 esq-dialog-toolbar\"\r\n    cdkDrag\r\n    cdkDragRootElement=\".cdk-overlay-pane\"\r\n    cdkDragHandle\r\n    cdkDragBoundary=\".cdk-overlay-container\"\r\n    [esqDialogResize]=\"resizeKey\"\r\n>\r\n  <div>\r\n    @if (loading()) {\r\n      <span class=\"esq-loading-div\"></span>\r\n    } @else if (headerIcon) {\r\n      <img [src]=\"headerIcon\" class=\"esq-base-icon\"/>\r\n    } @else {\r\n      <span style=\"width:24px;display:inline-block;\"></span>\r\n    }\r\n  </div>\r\n  <div>{{dialogTitle}}</div>\r\n  <button class=\"esq-select-entity-close-btn\" (click)=\"onCancel()\">&#x2715;</button>\r\n</mat-toolbar>\r\n\r\n<div class=\"esq-select-entity-tree-panel\">\r\n  <mat-tree [dataSource]=\"treeDs.selectDs\" [levelAccessor]=\"treeDs.levelAccessor\">\r\n    <mat-tree-node *matTreeNodeDef=\"let node\" matTreeNodePadding matTreeNodePaddingIndent=\"16\"\r\n        id=\"select-entity-node-{{node.id}}\"\r\n        class=\"esq-select-entity-tree-node\"\r\n        tabindex=\"0\"\r\n        [ngClass]=\"{\r\n            'esq-select-entity-active-node': selectedNode === node,\r\n            'esq-select-entity-mouse-node': hoveredNode === node && selectedNode !== node\r\n        }\"\r\n        (click)=\"onNodeClick(node)\"\r\n        (dblclick)=\"onNodeDblClick(node)\"\r\n        (keydown)=\"onNodeKeydown($event, node)\"\r\n        (mouseenter)=\"hoveredNode = node\"\r\n        (mouseleave)=\"hoveredNode = null\"\r\n        (focus)=\"hoveredNode = node\"\r\n        (blur)=\"hoveredNode = null\">\r\n      @if (treeDs.isExpandable(node)) {\r\n        <mat-icon class=\"esq-select-entity-toggle-icon\"\r\n          (click)=\"onToggleClick(node, $event)\"\r\n          (dblclick)=\"onToggleDblClick(node, $event)\">{{node.expanded() ? 'expand_more' : 'chevron_right'}}</mat-icon>\r\n      } @else {\r\n        <span style=\"width:24px;display:inline-block;flex-shrink:0;\"></span>\r\n      }\r\n      <img [src]=\"node.kind.icon\" class=\"esq-base-icon\"/>\r\n      <span class=\"esq-select-entity-overlay-text\">{{node.name}}</span>\r\n    </mat-tree-node>\r\n  </mat-tree>\r\n</div>\r\n\r\n<mat-dialog-actions align=\"center\">\r\n  <button mat-raised-button [disabled]=\"!canSelect()\" (click)=\"onSelect()\">Select</button>\r\n  <button mat-raised-button (click)=\"onCancel()\">Cancel</button>\r\n</mat-dialog-actions>\r\n", styles: [".esq-dialog{resize:both;overflow:auto;max-width:80vw!important;min-width:20vw!important;max-height:80vh!important;min-height:20vh!important}.esq-dialog .mat-mdc-dialog-container .mdc-dialog__surface{margin:0;padding:0;border:2px outset #ccc;background:#f7f7f5;color:#000;height:100%;display:flex;flex-direction:column}.esq-dialog .mat-mdc-dialog-container{max-width:100vw!important;min-width:20vw!important;max-height:100vh!important;min-height:20vh!important;padding:0;border-radius:4px;box-sizing:border-box;outline:0}.esq-dialog .esq-dialog-toolbar{top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:10pt;font-weight:400;margin:0;display:grid;grid-template-columns:32px auto 32px;gap:0px}.esq-dialog .esq-simple-grid2{min-height:16px;vertical-align:middle;text-align:left;color:#000;justify-content:flex-start;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-grid-input-text textarea{resize:none;overflow:hidden;width:100%;min-height:22px;box-sizing:border-box;border:1px solid #ccc;font-family:inherit;font-size:inherit;line-height:1.4;padding:2px 4px}.esq-dialog .esq-grid-input-text textarea:read-only{border:none;border-bottom:1px solid #ccc;background:transparent}.esq-dialog .esq-grid-input{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:grid;grid-template-columns:123px minmax(0,1fr);gap:4px;box-sizing:border-box}.esq-dialog .esq-grid-input input[type=text]{max-width:100%;box-sizing:border-box;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px}.esq-dialog .esq-grid-input input.esq-number-input{text-align:right}.esq-dialog .esq-grid-input input[readonly]{background-color:#f0f0f0;border:none;border-bottom:1px solid #ccc;pointer-events:none}.esq-dialog .esq-grid-input input.esq-node-prop{border-bottom:none}.esq-dialog .esq-grid-input input[readonly]:focus{outline:none}.esq-dialog .esq-grid-input .esq-nullable-input{display:inline-flex;flex-wrap:nowrap;align-items:center;max-width:100%;min-width:0}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=text]{flex:0 1 auto;min-width:0;max-width:100%}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]::-webkit-clear-button{display:none}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]{flex:0 1 auto;min-width:0;max-width:100%;height:24px;border:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>input[type=date]:read-only{border:none;border-bottom:1px solid #ccc}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:#fff;margin-left:-15px;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-null-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-null-clear:hover,.esq-dialog .esq-grid-input .esq-null-clear:active{background:#f5f5f5}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear{flex:0 0 auto;width:12px;height:18px;display:inline-flex;align-items:center;justify-content:center;background:none;margin-left:0;position:relative;left:0;font-size:18px;cursor:pointer;-webkit-user-select:none;user-select:none;z-index:1;border:none;padding:0;outline:none}.esq-dialog .esq-grid-input .esq-nullable-input>.esq-date-clear:focus-visible{outline:1px solid #1976d2;border-radius:2px}.esq-dialog .esq-grid-input .esq-date-clear:hover,.esq-dialog .esq-grid-input .esq-date-clear:active{background:#f5f5f5}.esq-dialog .esq-checkbox{width:16px;height:16px;cursor:pointer;accent-color:#337ab7}.esq-dialog .esq-checkbox:disabled{cursor:default;opacity:.6;pointer-events:none}.esq-dialog .esq-simple-grid-dropdown{min-height:16px;vertical-align:middle;text-align:left;white-space:normal;word-wrap:break-word;font-size:10pt;font-weight:400;display:inline-grid;grid-template-columns:123px auto;gap:4px}.esq-dialog .esq-simple-grid-dropdown select{width:auto;padding:4px 8px;font-size:10pt;border:1px solid #ccc;border-radius:2px;background-color:#fff;box-sizing:border-box}.esq-dialog .esq-simple-grid-dropdown select:disabled{background-color:#f0f0f0;color:#000;-webkit-text-fill-color:black;opacity:1;border:none;border-bottom:1px solid #ccc;pointer-events:none;-webkit-appearance:none;-moz-appearance:none;appearance:none}.esq-dialog .esq-base-icon{top:0;left:0;position:relative;height:20px;width:20px;vertical-align:middle;z-index:1}.esq-dialog .esq-overlay-icon{position:relative;height:12px;width:12px;top:0;left:-6px;z-index:2}.esq-dialog .esq-icon-button{transform:scale(.75)!important}.esq-dialog .esq-tab-image-container{display:grid;place-items:center}.esq-dialog .esq-tab-image{min-height:120px;max-height:240px}.esq-dialog .esq-name-image{height:64px}.esq-dialog .esq-mat-tab-group{height:100%}.esq-dialog .esq-mat-tab-group .mdc-tab-indicator .mdc-tab-indicator__content.mdc-tab-indicator__content--underline{border-top-width:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab{margin-right:1px;min-width:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab:last-child{margin-right:0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab.mdc-tab--active{border-top:2px solid #ccc;border-left:2px solid #ccc;border-right:1px solid #ccc;background-color:#f0f0f0}.esq-dialog .esq-mat-tab-group .mat-mdc-tab{font-size:10pt;font-weight:400;background-color:#ccc;border-radius:10px 10px 0 0;border-top:2px solid #aaa;border-left:2px solid #aaa;border-right:1px solid #aaa;height:32px;max-width:120px}.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-other-tab-content .mat-tab-body-content{overflow:hidden!important}.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-mdc-tab-body-content,.esq-dialog .esq-mat-tab-group .esq-first-tab-content .mat-tab-body-content{overflow:auto!important}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper h3{font-size:12pt;font-weight:400}.esq-dialog .esq-mat-tab-group .mat-mdc-tab-body-wrapper{font-size:10pt;font-weight:400;background-color:#f0f0f0;border-left:2px solid #ccc;border-right:1px solid #ccc;border-bottom:1px solid #ccc;height:100vh;padding:10px}.esq-dialog esq-tab-field{display:block;width:100%}.esq-dialog esq-tab-field:has(esq-tab-string){height:100%}.esq-dialog esq-tab-string{display:block;width:100%;height:100%}.esq-dialog .esq-icon-green{color:green}.esq-dialog .esq-icon-blue{color:#00f}.esq-dialog .esq-icon-red{color:red}.esq-dialog esq-confirm-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-dialog .esq-confirm-content{flex:1 1 auto;overflow:auto;min-height:0;padding:16px;min-width:260px;font-size:10pt;white-space:pre-wrap}.esq-dialog .esq-dialog-resize-se{width:12px!important;height:12px!important;background:linear-gradient(135deg,transparent 50%,rgba(0,0,0,.25) 50%)}.esq-dialog mat-dialog-actions button{min-width:88px}.esq-dialog .esq-activation-note{margin:4px 16px 0;padding:10px 12px;border:1px solid #c9190b;border-left:4px solid #c9190b;border-radius:3px;background:#faeae8;color:#7d1007;font-size:10pt;font-weight:500;line-height:1.35}.esq-dialog .esq-loading-div{position:relative;top:4px;left:0;height:16px;width:24px;display:inline-block;background-position:center;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}\n", "esq-select-entity-dialog,esq-select-acct-dialog,esq-move-dialog{display:flex;flex-direction:column;flex:1 1 auto;min-height:0}.esq-select-entity-tree-panel{background:#fff;border:1px solid #bbb;box-shadow:inset 1px 1px 3px #00000026;margin:4px 10px;overflow-y:auto;flex:1 1 auto;min-height:0}.esq-select-entity-tree-node{display:flex;align-items:center;font-size:12px;min-height:18px;cursor:pointer}.esq-select-entity-close-btn{display:flex;align-items:center;justify-content:center;width:24px;height:24px;font-size:14px;line-height:1;background:none;border:none;cursor:pointer;padding:0;color:inherit}.esq-select-entity-close-btn:hover{background:#00000014}.esq-select-entity-toggle-icon{width:24px;height:24px;font-size:18px;flex-shrink:0;cursor:pointer;-webkit-user-select:none;user-select:none}.esq-select-entity-active-node{background-color:#add8e6!important}.esq-select-entity-mouse-node{background-color:#e8f5fa}.esq-select-entity-overlay-text{font-size:9pt;font-weight:400;margin-left:2px}esq-select-entity-dialog mat-dialog-actions button:first-child,esq-select-acct-dialog mat-dialog-actions button:first-child,esq-move-dialog mat-dialog-actions button:first-child{border:1px solid #888}\n"] }]
        }], ctorParameters: () => [{ type: i1.MatDialogRef }, { type: undefined, decorators: [{
                    type: Inject,
                    args: [MAT_DIALOG_DATA]
                }] }] });

/**
 * Handler for CMD_MOVE command
 * Opens move dialog and refreshes tree on success
 */
class EsqMoveCommandHandler {
    getSelectorFactory;
    constructor(getSelectorFactory) {
        this.getSelectorFactory = getSelectorFactory;
    }
    canHandle(cmd) {
        return cmd === EsqExplorerCallApi.CMD_MOVE;
    }
    /**
     * Execute with node context (from call())
     */
    async executeWithNode(context) {
        var asOwner = context.selectMode === SelectMode.SelectTree;
        return this.openMoveDialog(context.node, context.nodeKind, context.dialog, context.restApi, context.callApi, context.userId, (entityId) => context.host?.onTreeRefresh(entityId, asOwner));
    }
    /**
     * Execute with entity context (from calle())
     * Fetches node first, then opens dialog
     */
    async executeWithEntity(context) {
        // Fetch entity node (entityKind already normalized by doEntityCommand)
        var node = await this.fetchNode(context.restApi, context.entityKind, context.entityId, context.entityName);
        if (!node) {
            return;
        }
        var asOwner = context.selectMode === SelectMode.SelectTree;
        return this.openMoveDialog(node, context.entityKind, context.dialog, context.restApi, context.callApi, context.userId, (entityId) => context.host?.onTreeRefresh(entityId, asOwner));
    }
    /**
     * Fetch node from entity parameters
     */
    async fetchNode(restApi, entityKind, entityId, entityName) {
        var _enode_;
        if (entityId.length > 0) {
            _enode_ = await firstValueFrom(restApi.esquireEntityNode(entityKind, entityId, "")).catch(console.error);
        }
        else {
            _enode_ = await firstValueFrom(restApi.esquireEntityNode(entityKind, "", entityName)).catch(console.error);
        }
        return _enode_ ? new EsqTreeNode(_enode_, undefined) : undefined;
    }
    /**
     * Open move dialog and handle result
     */
    async openMoveDialog(node, nodeKind, dialog, restApi, callApi, userId, onRefresh) {
        var dialogRef = dialog.open(EsqMoveDialog, {
            autoFocus: false,
            panelClass: 'esq-dialog',
            data: {
                node,
                nodeKind,
                selectorFactory: this.getSelectorFactory(),
                restApi,
                callApi,
                userId
            }
        });
        dialogRef.updateSize('280px', '460px');
        // Wait for result
        var moved = await new Promise(resolve => dialogRef.afterClosed().subscribe((r) => resolve(r === true)));
        // Refresh on success
        if (moved) {
            setTimeout(() => onRefresh(node.entityId), 250);
        }
    }
}

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 02/01/2026 mir0n  dynamic toolbar
*                   context menu added
*                   toolbar is in synch with context menu
*                   normalized keyboard actions
* 02/12/2026 mir0n  EsqNodeType in explicit file
* 02/13/2026 mir0n  EsqNodeType renamed with EsqObjectKind
* 02/17/2026 mir0n  use CMD_DEFAULT constant from EsqExplorerCallApi
*                   use EsqAccessProfile from esquire.ui/api
* 03/20/2026 mir0n  implements EsqExplorerHost; self-registers via registerHost in ngOnInit()
*                   onBtnRefreshClick: gotoTreeNode fallback for link-variant node restore
* 03/26/2026 mir0n  canCreateKind(); onTreeRefreshSelect(); setErrorMessage() delegation
*                   onBtnRefreshClickAndSelect(); esqExplorerHost input; errorMessage signal
* 03/28/2026 mir0n  onTreeRefresh() consolidated: entityId/asOwner optional params; onBtnRefreshClickAndSelectOwner() added
* 03/31/2026 mir0n  CMD_MOVE: doMoveCommand() opens EsqMoveDialog; canCmdClick() refactored; cannot move yourself
* 04/02/2026 mir0n  registration of Move command handler
*                   onCmdClick() : bypass location for refresh selection
*                   api.call(): added subCmd, selectMode
* 04/08/2026 mir0n  ExplorerHost registration redesigned : fanout host events to any number of registered hosts
*                   handle EsqExplorerHost.setLoading()
* 04/12/2026 mir0n  esqDatasource @Input: accept external EsqFlatTreeDatasource; backward compatible
* 04/13/2026 mir0n  generic submenu: EsqSubMenuItem, activeSubItems, prepareSubmenu(), canSubCmdClick(), onSubCmdClick()
* 04/14/2026 mir0n  esqSubItemDisabled @Input callback; isSubItemDisabled() hook; prepareSubmenu(menu) param
* 04/17/2026 mir0n  import consolidation
*/
class EsqExplorerComponent extends EsqExplorerHostDummy {
    dialog;
    esqRestApi = null;
    esqExplorerCallApi = null;
    esqCommandMenuItems = [];
    activeSubItems = [];
    activeCmd = '';
    esqAccessProfile = null;
    esqDatasource;
    esqSubItemDisabled;
    treeLevelAccessor = (dataNode) => dataNode.level;
    datasource;
    listColumns = [];
    listColumnsDisplayed = [];
    listNodeFocused = null;
    listNodeOwner = null;
    listNodeExecuted = null;
    listNodeHoveredIndex = -1;
    listNodeOwnerPath = signal("", ...(ngDevMode ? [{ debugName: "listNodeOwnerPath" }] : []));
    errorMessage = signal('', ...(ngDevMode ? [{ debugName: "errorMessage" }] : []));
    errorReport = undefined;
    listNodeHistoryStack = [];
    listNodeHistoryIndex = -1;
    treeNodePostFocus = null;
    treeNodeActive = null;
    treeNodeEntered = null;
    treeNodeLastFocus = null;
    _tree;
    sidenav;
    contextMenuTrigger;
    menuItemOpen;
    menuItemDetails;
    contextMenuPosition = { x: 0, y: 0 };
    contextMenuNode = null;
    contextMenuInList = false; // true when right-clicking on list item
    contextMenuParent = null;
    contextNewMenuItems = [];
    toolbarNewMenuItems = [];
    treeItself;
    matRows; // Assuming MatRow is a directive applied to your rows
    initialDataLoading = signal(true, ...(ngDevMode ? [{ debugName: "initialDataLoading" }] : []));
    dataLoading = signal(false, ...(ngDevMode ? [{ debugName: "dataLoading" }] : []));
    treeOnFocus = false;
    constructor(dialog) {
        super();
        this.dialog = dialog;
        afterEveryRender(() => {
            if (this.treeNodePostFocus) {
                this.setFocusTreeNode(this.treeNodePostFocus);
                this.treeNodePostFocus = null;
            }
        });
    }
    async ngAfterViewInit() {
        this.treeItself = this._tree;
    }
    onTreeRefresh(entityId, asOwner) {
        if (entityId && asOwner) {
            void this.onBtnRefreshClickAndSelectOwner(entityId);
        }
        else if (entityId) {
            void this.onBtnRefreshClickAndSelect(entityId);
        }
        else {
            void this.onBtnRefreshClick();
        }
    }
    setLoading(on) {
        this.dataLoading.set(on);
    }
    async onBtnRefreshClickAndSelect(entityId) {
        await this.onBtnRefreshClick();
        var n = await this.datasource.gotoListNode(entityId);
        if (n && n instanceof EsqTreeNode) {
            var found = n;
            this.listNodeOwner = found.parent;
            this.updatePath();
            this.updateToolbarNewMenuItems();
            this.toggleTreeSelect(found.parent);
            this.doSelectListNode(found, true);
        }
    }
    async onBtnRefreshClickAndSelectOwner(entityId) {
        await this.onBtnRefreshClick();
        var ownerResult = await this.datasource.gotoTreeNode(entityId);
        if (ownerResult && ownerResult instanceof EsqTreeNode) {
            var ownerNode = ownerResult;
            if (ownerNode.expandable()) {
                this.treeItself.expand(ownerNode);
                this.datasource.selectOnTree(ownerNode);
                this.treeNodeActive = ownerNode;
                await this.doActivateListNode(ownerNode, false);
            }
        }
    }
    async ngOnInit() {
        if (!this.esqRestApi) {
            console.error("No esqRestApi defined");
        }
        this.esqExplorerCallApi?.registerHost(this);
        const moveHandler = new EsqMoveCommandHandler(() => this.getDatasource());
        this.esqExplorerCallApi?.registerHandler(moveHandler);
        this.datasource = this.esqDatasource ?? new EsqFlatTreeDatasource(this.esqRestApi);
        await this.datasource.loadInitialData();
        this.listNodeOwner = this.datasource.data4tree[0];
        if (this.listNodeOwner) {
            this.updatePath();
            this.updateToolbarNewMenuItems();
            this.treeNodeActive = this.listNodeOwner;
            await this.datasource.loadChildren(this.listNodeOwner);
            if (this.datasource.data4list.length > 0) {
                this.listNodeFocused = this.datasource.data4list[0];
                this.listNodeHistoryStack[0] = this.listNodeOwner;
                this.listNodeHistoryIndex = 0;
            }
            this.listColumns = this.listNodeOwner.kind.listHeaders;
            this.listColumnsDisplayed = this.listColumns.map((x) => x.columnDef);
            this.treeNodePostFocus = this.treeNodeActive;
            this.initialDataLoading.set(false);
        }
    }
    toggleSideNav() {
        if (this.sidenav) {
            this.sidenav.toggle();
        }
    }
    /**
     * Get datasource for external command handler registration
     */
    getDatasource() {
        return this.datasource;
    }
    ngOnDestroy() {
        this.esqExplorerCallApi?.unregisterHost(this);
    }
    hasIcon(node) {
        return (node.kind.icon.length > 0);
    }
    nodeIcon(node) {
        return node.kind.icon;
    }
    nodeStatusIcon(node) {
        return EsqNodeStatusFactory.instanceOf(node.statusCode).icon;
    }
    updatePath() {
        var path = "";
        if (this.listNodeOwner) {
            let node = this.listNodeOwner;
            var first = true;
            do {
                path = node.name + (first ? "" : "/") + path;
                node = node?.parent;
                first = false;
            } while (node);
        }
        this.listNodeOwnerPath.update(() => path);
    }
    // Number of buttons on the right side of the toolbar (for grid layout)
    rightButtonsCount() {
        return this.esqCommandMenuItems.length + 3;
    }
    ;
    // ==== context menu generic behavior =====
    findDefaultMenuItem() {
        if (this.contextMenuNode?.expandable()) {
            return this.menuItemOpen;
        }
        else {
            return this.menuItemDetails;
        }
    }
    openContextMenu(event, node, parent) {
        this.contextMenuNode = node;
        this.contextMenuParent = parent;
        if (this.contextMenuInList && node) {
            this.contextNewMenuItems = [];
        }
        else {
            this.contextNewMenuItems = EsqContextMenuBuilder.buildNewMenuItems(parent);
        }
        this.contextMenuPosition.x = event.clientX;
        this.contextMenuPosition.y = event.clientY;
        this.contextMenuTrigger.openMenu();
        // Focus the default menu item after menu opens
        setTimeout(() => {
            const defaultMenuItem = this.findDefaultMenuItem();
            if (defaultMenuItem?.nativeElement) {
                defaultMenuItem.nativeElement.focus();
            }
        }, 0);
    }
    onListContextMenu(event, node) {
        event.preventDefault();
        event.stopPropagation();
        this.contextMenuInList = true; // Clicking on list item - disable "New..."
        this.openContextMenu(event, node, node.parent ?? this.listNodeOwner ?? null);
    }
    onTreeContextMenu(event, node) {
        event.preventDefault();
        event.stopPropagation();
        this.contextMenuInList = false; // Tree nodes can be containers
        // For tree nodes, the parent for "New..." should be the node itself (create children under it)
        this.openContextMenu(event, node, node);
    }
    onEmptyListContextMenu(event) {
        const target = event.target;
        if (target?.closest('tr.mat-row')) {
            return; // row will handle its own context menu
        }
        event.preventDefault();
        event.stopPropagation();
        this.contextMenuInList = false; // Empty space - enable "New..."
        this.openContextMenu(event, null, this.listNodeOwner ?? null);
    }
    onEmptyTreeContextMenu(event) {
        const target = event.target;
        if (target?.closest('.esq-tree-node')) {
            return; // node will handle its own context menu
        }
        event.preventDefault();
        event.stopPropagation();
        this.contextMenuInList = false; // Empty space - enable "New..."
        this.openContextMenu(event, null, this.treeNodeActive ?? this.listNodeOwner ?? null);
    }
    updateToolbarNewMenuItems() {
        // Build menu items for toolbar "New" button based on current selection
        this.toolbarNewMenuItems = EsqContextMenuBuilder.buildNewMenuItems(this.listNodeOwner);
    }
    // ===== optional external commands on the context menu and toolbar =====
    getSelectedNode(menu) {
        var ret = null;
        if (menu) {
            ret = this.contextMenuNode;
        }
        else {
            if (this.treeOnFocus) {
                ret = this.treeNodeActive;
            }
            else {
                ret = this.listNodeFocused;
            }
        }
        return ret;
    }
    canCmdClick(cmd, menu) {
        var ret = false;
        var node = this.getSelectedNode(menu);
        if (node && this.esqAccessProfile) {
            ret = node.kind.isCommandAllowed(cmd);
            if (ret) {
                if (cmd == EsqExplorerCallApi.CMD_MOVE &&
                    node.entityId === this.esqAccessProfile?.id) {
                    // you cannot move yourself
                    ret = false;
                }
                else {
                    ret = this.esqAccessProfile.isCommandAllowed(cmd, node.entityId, node.kind.id);
                }
            }
        }
        return ret;
    }
    canCreateKind(kindId) {
        var ret = !this.esqAccessProfile ||
            this.esqAccessProfile.isCommandAllowed(EsqExplorerCallApi.CMD_NEW, "", kindId);
        return ret;
    }
    async onCmdClick(cmd, menu) {
        if (this.canCmdClick(cmd, menu)) {
            var selectMode = this.treeOnFocus
                ? SelectMode.SelectTree
                : SelectMode.SelectList;
            await this.doExplorerCommand(cmd, null, this.getSelectedNode(menu), selectMode);
        }
    }
    // ===== optional "New" command on the context menu and toolbar =====
    canCmdNewClick(menu) {
        if (menu) {
            return this.contextNewMenuItems.length > 0;
        }
        return this.toolbarNewMenuItems.length > 0;
    }
    async onCmdNewClick(typeId, menu) {
        if (this.canCmdNewClick(menu)) {
            var node = menu ? this.contextMenuParent : this.listNodeOwner;
            if (node) {
                EsqUtils.log("onCmdDetailsClick[");
                await this.doExplorerCreate(node, typeId);
                EsqUtils.log("]onCmdDetailsClick");
            }
        }
    }
    // ===== optional submenu commands on context menu and toolbar =====
    canSubCmdClick(item, menu) {
        var ret = (item.subItems?.length ?? 0) > 0;
        if (ret) {
            ret = this.canCmdClick(item.cmd, menu);
        }
        return ret;
    }
    prepareSubmenu(item, menu) {
        var node = this.getSelectedNode(menu);
        this.activeCmd = item.cmd;
        this.activeSubItems = (item.subItems ?? []).map(sub => ({
            ...sub,
            disabled: sub.disabled || this.isSubItemDisabled(item.cmd, sub.subCmd, node),
        }));
    }
    isSubItemDisabled(cmd, subCmd, node) {
        return this.esqSubItemDisabled?.(cmd, subCmd, node) ?? false;
    }
    async onSubCmdClick(subCmd, menu) {
        var selectMode = this.treeOnFocus
            ? SelectMode.SelectTree
            : SelectMode.SelectList;
        await this.doExplorerCommand(this.activeCmd, subCmd, this.getSelectedNode(menu), selectMode);
    }
    // ===== default actions : Open and Details =====
    canMenuOpenClick() {
        var ret = false;
        var node = this.contextMenuNode;
        if (node) {
            ret = node.expandable();
        }
        return ret;
    }
    async onMenuOpenClick() {
        if (!this.contextMenuNode)
            return;
        // Open means navigate into the node (select it and load its children)
        if (this.contextMenuInList) {
            // For list items, select and execute the default action
            this.doSelectListNode(this.contextMenuNode, true);
            await this.doDefaultListNode();
        }
        else {
            // For tree nodes, expand/activate them
            await this.toggleTreeActivate(this.contextMenuNode, true);
        }
    }
    canCmdDetailsClick(menu) {
        return this.getSelectedNode(menu) != null;
    }
    async onCmdDetailsClick(menu) {
        EsqUtils.log("onCmdDetailsClick[");
        await this.doExplorerCommand(EsqExplorerCallApi.CMD_DEFAULT, null, this.getSelectedNode(menu));
        EsqUtils.log("]onCmdDetailsClick");
    }
    // ===== Goto command =====
    canCmdGotoClick(menu) {
        var node = this.getSelectedNode(menu);
        return !!node && (node.linkId ?? '') !== '';
    }
    async onCmdGotoClick(menu) {
        if (this.canCmdGotoClick(menu)) {
            var node = this.getSelectedNode(menu);
            if (node) {
                const id = node.linkId;
                this.dataLoading.set(true);
                let n = await this.datasource.gotoListNode(id);
                if (n && n instanceof EsqTreeNode) {
                    const node = n;
                    this.toggleTreeSelect(node.parent);
                    this.doSelectListNode(node, true);
                }
                this.dataLoading.set(false);
            }
        }
    }
    // ===== Navigation section  =====
    canCmdBackClick() {
        return this.listNodeHistoryIndex > 0
            && this.listNodeHistoryStack.length > this.listNodeHistoryIndex;
    }
    async onCmdBackClick() {
        if (this.canCmdBackClick()) {
            this.listNodeHistoryIndex--;
            let node = this.listNodeHistoryStack[this.listNodeHistoryIndex];
            this.doTreeExpandSelect(node);
        }
    }
    canCmdForwardClick() {
        return this.listNodeHistoryStack.length > 0
            && this.listNodeHistoryIndex >= 0
            && this.listNodeHistoryIndex + 1 < this.listNodeHistoryStack.length;
    }
    async onCmdForwardClick() {
        if (this.canCmdForwardClick()) {
            this.listNodeHistoryIndex++;
            let node = this.listNodeHistoryStack[this.listNodeHistoryIndex];
            this.doTreeExpandSelect(node);
        }
    }
    canCmdUpClick() {
        var ret = false;
        if (this.listNodeOwner && this.listNodeOwner.parent) {
            ret = true;
        }
        return ret;
    }
    async onCmdUpClick() {
        if (this.canCmdUpClick()) {
            if (this.listNodeOwner && this.listNodeOwner.parent) {
                if (this.listNodeHistoryIndex > 0
                    && this.listNodeHistoryIndex + 1 < this.listNodeHistoryStack.length) {
                    this.listNodeHistoryStack = this.listNodeHistoryStack.slice(0, this.listNodeHistoryIndex + 1);
                }
                this.doTreeExpandSelect(this.listNodeOwner.parent);
            }
        }
    }
    // ==== rest but only Button commands =====
    async onBtnRefreshClick() {
        EsqUtils.log('onBtnRefreshClick[');
        this.initialDataLoading.set(true);
        var savedFocused = null;
        var savedOwner = null;
        if (this.listNodeFocused) {
            savedFocused = this.listNodeFocused;
            this.listNodeFocused = null;
        }
        if (this.listNodeOwner) {
            savedOwner = this.listNodeOwner;
        }
        this.datasource.clear();
        this.listNodeHistoryIndex = -1;
        this.listNodeHistoryStack = [];
        await this.datasource.loadInitialData();
        var restored = false;
        if (savedFocused) {
            var n = await this.datasource.gotoListNode(savedFocused.id);
            if (n && n instanceof EsqTreeNode) {
                var found = n;
                this.listNodeOwner = found.parent;
                this.updatePath();
                this.updateToolbarNewMenuItems();
                this.toggleTreeSelect(found.parent);
                this.doSelectListNode(found, true);
                restored = true;
            }
        }
        if (!restored && savedOwner) {
            var ownerResult = await this.datasource.gotoTreeNode(savedOwner.id);
            if (ownerResult && ownerResult instanceof EsqTreeNode) {
                var ownerNode = ownerResult;
                if (ownerNode.expandable()) {
                    this.treeItself.expand(ownerNode);
                    this.datasource.selectOnTree(ownerNode);
                    this.treeNodeActive = ownerNode;
                    await this.doActivateListNode(ownerNode, false);
                }
            }
        }
        this.initialDataLoading.set(false);
        EsqUtils.log(']onBtnRefreshClick');
    }
    canBtnMoreClick() {
        var ret = false;
        if (this.listNodeOwner) {
            ret = this.datasource.hasMoreChildren(this.listNodeOwner);
        }
        return ret;
    }
    async onBtnMoreClick() {
        if (this.canBtnMoreClick()) {
            this.dataLoading.set(true);
            await this.datasource.loadMoreChildren(this.listNodeOwner);
            this.dataLoading.set(false);
        }
    }
    //  end of UI commands
    async doExplorerCommand(cmd, subCmd, node, selectMode = SelectMode.None) {
        var ret = new Promise((resolve) => resolve());
        if (node && this.esqExplorerCallApi) {
            const api = this.esqExplorerCallApi;
            ret = api.call(cmd, subCmd, node, this.esqAccessProfile, selectMode);
        }
        return ret;
    }
    async doExplorerCreate(node, typeId) {
        if (node && this.esqExplorerCallApi) {
            const api = this.esqExplorerCallApi;
            return api.create(node, typeId);
        }
        else {
            return new Promise((resolve) => resolve());
        }
    }
    // ------------list view  events -----  
    onListFocus(node) {
        this.treeOnFocus = false;
        this.treeNodeEntered = null;
        if (this.treeNodeLastFocus) {
            this.treeNodeLastFocus = null;
        }
    }
    onListFocusOut(node) {
    }
    onListClick(node) {
        this.doSelectListNode(node, true);
    }
    onListDoubleClick(node) {
        this.doSelectListNode(node, true);
        this.doDefaultListNode();
    }
    isKeyPlain(event) {
        return !event.ctrlKey && !event.altKey && !event.shiftKey && !event.metaKey;
    }
    isOnlyCtrl(event) {
        return event.ctrlKey && !event.altKey && !event.shiftKey && !event.metaKey;
    }
    isOnlyAlt(event) {
        return !event.ctrlKey && event.altKey && !event.shiftKey && !event.metaKey;
    }
    async onListKeydown(event, node, index) {
        switch (event.key) {
            case 'ArrowUp':
                if (this.isOnlyCtrl(event)) {
                    event.preventDefault();
                    await this.onCmdUpClick();
                    // Restore focus to first item in new list
                    if (this.datasource.data4list.length > 0) {
                        this.doSelectListNode(this.datasource.data4list[0], true);
                    }
                }
                else if (this.isKeyPlain(event)) {
                    event.preventDefault();
                    this.onListArrowup(node, index);
                }
                break;
            case 'ArrowDown':
                if (this.isKeyPlain(event)) {
                    event.preventDefault();
                    this.onListArrowdown(node, index);
                }
                break;
            case 'ArrowLeft':
                if (this.isOnlyCtrl(event)) {
                    event.preventDefault();
                    await this.onCmdBackClick();
                    // Restore focus to first item in new list
                    if (this.datasource.data4list.length > 0) {
                        this.doSelectListNode(this.datasource.data4list[0], true);
                    }
                }
                break;
            case 'ArrowRight':
                if (this.isOnlyCtrl(event)) {
                    event.preventDefault();
                    await this.onCmdForwardClick();
                    // Restore focus to first item in new list
                    if (this.datasource.data4list.length > 0) {
                        this.doSelectListNode(this.datasource.data4list[0], true);
                    }
                }
                break;
            case 'Enter':
                if (this.isOnlyAlt(event)) {
                    event.preventDefault();
                    if (this.listNodeFocused) {
                        this.doExplorerCommand(EsqExplorerCallApi.CMD_DEFAULT, null, this.listNodeFocused);
                    }
                }
                else if (this.isKeyPlain(event)) {
                    event.preventDefault();
                    if (this.listNodeFocused) {
                        this.doSelectListNode(this.listNodeFocused, true);
                        this.doDefaultListNode();
                    }
                }
                break;
            case ' ': // Spacebar
                if (this.isKeyPlain(event)) {
                    event.preventDefault();
                    if (this.listNodeFocused) {
                        this.doSelectListNode(this.listNodeFocused, true);
                    }
                }
                break;
        }
    }
    onListArrowdown(node, index) {
        var nextRow;
        if (index < this.datasource.data4list.length - 1) {
            nextRow = this.datasource.data4list[index + 1];
        }
        if (nextRow) {
            this.doSelectListNode(nextRow, true);
        }
    }
    onListArrowup(node, index) {
        var nextRow;
        if (index > 0) {
            nextRow = this.datasource.data4list[index - 1];
        }
        if (nextRow) {
            this.doSelectListNode(nextRow, true);
        }
    }
    //----- tree view events ---------
    onTreeClick(node) {
        this.toggleTreeActivate(node, false);
    }
    onTreeDoubleClick(node) {
        this.toggleTreeExpandSelect(node);
    }
    onTreeNodeEnter(node) {
        this.treeNodeEntered = node;
    }
    onTreeNodeLeave() {
        this.treeNodeEntered = null;
    }
    async onTreeNodeExpansion($event, node) {
        EsqUtils.log("handleNodeExpansion[");
        this.dataLoading.set(true);
        await this.datasource.toggleOnTree(node);
        this.doActivateListExecuted();
        this.dataLoading.set(false);
        EsqUtils.log("]handleNodeExpansion");
    }
    onTreeFocus(node) {
        this.treeOnFocus = true;
    }
    onTreeFocusOut(node) {
        this.treeNodeLastFocus = node;
    }
    async onTreeKeydown(event, node) {
        switch (event.key) {
            case 'ArrowUp':
                if (this.isOnlyCtrl(event)) {
                    event.preventDefault();
                    await this.onCmdUpClick();
                    // Restore focus to the active tree node
                    if (this.treeNodeActive) {
                        this.setFocusTreeNode(this.treeNodeActive);
                    }
                }
                else if (this.isKeyPlain(event)) {
                    event.preventDefault();
                    this.onTreeNodeEnter(node);
                }
                break;
            case 'ArrowDown':
                if (this.isKeyPlain(event)) {
                    event.preventDefault();
                    this.onTreeNodeEnter(node);
                }
                break;
            case 'ArrowLeft':
                if (this.isOnlyCtrl(event)) {
                    event.preventDefault();
                    await this.onCmdBackClick();
                    // Restore focus to active tree node
                    if (this.treeNodeActive) {
                        this.setFocusTreeNode(this.treeNodeActive);
                    }
                }
                else if (this.isKeyPlain(event)) {
                    event.preventDefault();
                    this.onTreeLeft(node);
                }
                break;
            case 'ArrowRight':
                if (this.isOnlyCtrl(event)) {
                    event.preventDefault();
                    await this.onCmdForwardClick();
                    // Restore focus to active tree node
                    if (this.treeNodeActive) {
                        this.setFocusTreeNode(this.treeNodeActive);
                    }
                }
                else if (this.isKeyPlain(event)) {
                    event.preventDefault();
                    this.onTreeRight(node);
                }
                break;
            case 'Enter':
                if (this.isOnlyAlt(event)) {
                    event.preventDefault();
                    this.doExplorerCommand(EsqExplorerCallApi.CMD_DEFAULT, null, node);
                }
                else if (this.isKeyPlain(event)) {
                    event.preventDefault();
                    this.toggleTreeActivate(node, false);
                    this.treeItself.toggle(node);
                }
                break;
            case ' ': // Spacebar
                if (this.isKeyPlain(event)) {
                    event.preventDefault();
                    this.toggleTreeActivate(node, false);
                }
                break;
            //      case 'Back':
            //        if (this.isKeyPlain(event)) {
            //          event.preventDefault();
            //          this.onCmdBackClick();
            //        }
            //        break;
        }
    }
    onTreeLeft(node) {
        //xxx: sometimes tree getting late
        if (this.treeItself.isExpanded(node) || node.expanded()) {
            this.treeItself.toggle(node);
            this.toggleTreeSelect(node);
        }
        this.onTreeNodeEnter(node);
    }
    onTreeRight(node) {
        //xxx: sometimes tree getting late
        if (node.expandable() && !(this.treeItself.isExpanded(node) && node.expanded())) {
            this.treeItself.toggle(node);
            this.toggleTreeSelect(node);
        }
        this.onTreeNodeEnter(node);
    }
    // -- actions --- 
    doSelectListNode(node, focused) {
        if (node) {
            EsqUtils.log("select[", focused);
            this.dataLoading.set(true);
            const index = this.datasource.data4list.indexOf(node);
            this.listNodeFocused = node;
            if (focused) {
                setTimeout(() => {
                    const nextRows = this.matRows.toArray();
                    const nextRowElement = nextRows[index].nativeElement;
                    nextRowElement.focus();
                }, 0);
            }
            this.dataLoading.set(false);
            EsqUtils.log("]select");
        }
    }
    async doDefaultListNode() {
        EsqUtils.log('runDefault[', this.listNodeFocused);
        this.dataLoading.set(true);
        let doDefault = false;
        let doActivate = false;
        if (this.listNodeFocused) {
            const node = this.listNodeFocused;
            doActivate = true;
            if (!this.datasource.isVisibleOnTree(node)) {
                if (node.expandable()) {
                    EsqUtils.log('toggle');
                    this.treeItself.toggle(node.parent);
                    this.listNodeExecuted = node;
                }
                else {
                    doActivate = false;
                    ;
                    doDefault = true;
                }
            }
        }
        if (doActivate) {
            this.toggleTreeActivate(this.listNodeFocused, true);
        }
        this.dataLoading.set(false);
        if (doDefault) {
            await this.doExplorerCommand(EsqExplorerCallApi.CMD_DEFAULT, null, this.listNodeFocused);
        }
        EsqUtils.log(']runDefault');
    }
    doActivateListExecuted() {
        const node = this.listNodeExecuted;
        if (node) {
            this.listNodeExecuted = null;
            EsqUtils.log('doActivateListExecuted[', node);
            var i = 0;
            for (; i < 1000; i++) {
                setTimeout(() => {
                    let g = 1;
                }, 10);
                if (this.datasource.isVisibleOnTree(node)) {
                    break;
                }
            }
            if (this.datasource.isVisibleOnTree(node)) {
                EsqUtils.log('Asyn activate list IS executed  at ', i * 10, 'ms');
                this.toggleTreeActivate(node, true);
            }
            else {
                EsqUtils.log('Asyn activivate list IS NOT executed');
            }
            EsqUtils.log(']doActivateNode');
        }
    }
    async doActivateListNode(node, listFocused) {
        EsqUtils.log("doActivateListNode[" + listFocused);
        this.dataLoading.set(true);
        await this.datasource.loadChildren(node);
        if (this.listNodeOwner.kind != node.kind) {
            this.listColumns = node.kind.listHeaders;
            this.listColumnsDisplayed = this.listColumns.map((x) => x.columnDef);
            this.listColumnsDisplayed = [...this.listColumnsDisplayed];
        }
        this.treeNodePostFocus = null;
        if (this.datasource.data4list.length > 0) {
            this.doSelectListNode(this.datasource.data4list[0], listFocused);
        }
        if (this.listNodeOwner != node) {
            this.listNodeOwner = node;
            this.updatePath();
            this.updateToolbarNewMenuItems();
            if (this.listNodeHistoryIndex + 1 == this.listNodeHistoryStack.length) {
                if (this.listNodeHistoryStack[this.listNodeHistoryIndex] != node) {
                    this.listNodeHistoryStack[this.listNodeHistoryStack.length] = node;
                    if (this.listNodeHistoryStack.length > 5) {
                        this.listNodeHistoryStack.shift();
                    }
                    this.listNodeHistoryIndex = this.listNodeHistoryStack.length - 1;
                }
            }
        }
        this.dataLoading.set(false);
        EsqUtils.log("]doActivateListNode");
    }
    setFocusTreeNode(node) {
        // Find the corresponding DOM element
        const element = document.getElementById('node-' + node.id);
        if (element) {
            // Use setTimeout to ensure the element is rendered and available in the DOM
            setTimeout(() => {
                element.focus();
            }, 0);
        }
    }
    toggleTreeSelect(node) {
        if (this.treeNodeActive != node) {
            this.treeNodeActive = node;
            this.datasource.toggleTreeSelection(node);
        }
    }
    toggleTreeActivate(node, listFocused) {
        if (node && this.treeNodeActive != node) {
            this.treeNodeActive = node;
            this.datasource.toggleTreeSelection(node);
            if (node.expandable()) {
                this.doActivateListNode(node, listFocused);
            }
        }
    }
    toggleTreeExpandSelect(node) {
        this.treeItself.toggle(node);
        if (node.expandable()) {
            this.doActivateListNode(node, false);
        }
    }
    doTreeExpandSelect(node) {
        if (node && node.expandable()) {
            this.treeItself.expand(node);
            this.datasource.selectOnTree(node);
            this.treeNodeActive = node;
            //this.toggleTreeSelect(node);      
            //this.treeNodeActive = node;
            this.doActivateListNode(node, false);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqExplorerComponent, deps: [{ token: i1.MatDialog }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.16", type: EsqExplorerComponent, isStandalone: true, selector: "esqExplorer", inputs: { esqRestApi: "esqRestApi", esqExplorerCallApi: "esqExplorerCallApi", esqCommandMenuItems: "esqCommandMenuItems", esqAccessProfile: "esqAccessProfile", esqDatasource: "esqDatasource", esqSubItemDisabled: "esqSubItemDisabled" }, host: { classAttribute: "esq-explorer" }, viewQueries: [{ propertyName: "_tree", first: true, predicate: ["EsqExplTree"], descendants: true }, { propertyName: "sidenav", first: true, predicate: ["EsqSidenav"], descendants: true }, { propertyName: "contextMenuTrigger", first: true, predicate: ["contextMenuTrigger"], descendants: true, read: MatMenuTrigger }, { propertyName: "menuItemOpen", first: true, predicate: ["menuItemOpen"], descendants: true, read: ElementRef }, { propertyName: "menuItemDetails", first: true, predicate: ["menuItemDetails"], descendants: true, read: ElementRef }, { propertyName: "matRows", predicate: MatRow, descendants: true, read: ElementRef }], usesInheritance: true, ngImport: i0, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<div class=\"esq-explorer-container\">\r\n<mat-toolbar class=\"mat-elevation-z2 esq-toolbar\" [style.--right-buttons-count]=\"rightButtonsCount()\">\r\n\r\n  <button matIconButton\r\n    class = \"esq-icon-button\"\r\n    matTooltip = \"{{EsqSidenav.opened ? 'Hide tree navigation' : 'Open tree navigation'}}\" \r\n    (click)=\"EsqSidenav.toggle()\">\r\n    <mat-icon>\r\n        {{EsqSidenav.opened ? 'folder_open': 'folder_off'}}\"    \r\n    </mat-icon>\r\n  </button>\r\n\r\n  <button #esqBtnBack matIconButton \r\n    class = \"esq-icon-button\"\r\n    matTooltip=\"Back\"\r\n    disabled = \"{{!canCmdBackClick()}}\"\r\n    (click)=\"onCmdBackClick()\">\r\n    <mat-icon>arrow_back</mat-icon>\r\n  </button>\r\n\r\n  <button #esqBtnForward matIconButton \r\n    class = \"esq-icon-button\"\r\n    matTooltip=\"Forward\"\r\n    disabled = \"{{!canCmdForwardClick()}}\"\r\n   (click)=\"onCmdForwardClick()\">\r\n    <mat-icon>arrow_forward</mat-icon>\r\n  </button>\r\n\r\n  <button #esqBtnUp matIconButton \r\n    class = \"esq-icon-button\"\r\n    matTooltip=\"Up one level \"\r\n    disabled = \"{{!canCmdUpClick()}}\"\r\n    (click)=\"onCmdUpClick()\">\r\n    \r\n    <mat-icon>arrow_upward</mat-icon>\r\n  </button>\r\n\r\n  @if (initialDataLoading() || dataLoading()) {\r\n    <span class=\"esq-loading-div\" ></span>\r\n  } @else {\r\n    <button matIconButton \r\n      class = \"esq-icon-button\"\r\n      matTooltip=\"Refresh\"\r\n      (click)=\"onBtnRefreshClick()\">\r\n      <mat-icon>refresh</mat-icon>\r\n    </button>\r\n  }\r\n  <div ></div>\r\n\r\n  <div class=\"esq-path-bar\">\r\n    {{listNodeOwnerPath()}}\r\n  </div>\r\n\r\n  @for (item of esqCommandMenuItems.slice().reverse(); track item.cmd) {\r\n      @if (item.subItems !== undefined) {\r\n          <button matIconButton\r\n              class = \"esq-icon-button\"\r\n              matTooltip={{item.label}}\r\n              [disabled]=\"!canSubCmdClick(item, false)\"\r\n              [matMenuTriggerFor]=\"toolbarSubMenu\"\r\n              (click)=\"prepareSubmenu(item, false)\">\r\n              <mat-icon>{{item.icon}}</mat-icon>\r\n          </button>\r\n      } @else if (item.cmd === 'new') {\r\n          <button matIconButton\r\n              class = \"esq-icon-button\"\r\n              matTooltip={{item.label}}\r\n              [disabled]=\"!canCmdNewClick(false)\"\r\n              [matMenuTriggerFor]=\"toolbarNewMenu\">\r\n              <mat-icon>{{item.icon}}</mat-icon>\r\n          </button>\r\n      } @else {\r\n          <button matIconButton\r\n              class = \"esq-icon-button\"\r\n              matTooltip={{item.label}}\r\n              [disabled]=\"!canCmdClick(item.cmd, false)\"\r\n              (click)=\"onCmdClick(item.cmd, false)\">\r\n              <mat-icon>{{item.icon}}</mat-icon>\r\n          </button>\r\n      }\r\n  }\r\n\r\n  <button #matBtnDetails matIconButton\r\n    class = \"esq-icon-button\"\r\n    matTooltip=\"Details\"  \r\n    disabled = \"{{!canCmdDetailsClick(false)}}\"\r\n    (click)=\"onCmdDetailsClick(false)\">\r\n    <mat-icon>wysiwyg</mat-icon>\r\n  </button>\r\n\r\n  <button #esqBtnGoto matIconButton \r\n    class = \"esq-icon-button\"\r\n    matTooltip=\"Go to origin\"  \r\n    disabled = \"{{!canCmdGotoClick(false)}}\"\r\n    (click)=\"onCmdGotoClick(false)\">\r\n    <mat-icon>launch</mat-icon>\r\n  </button>\r\n\r\n  <button #esqBtnMore matIconButton\r\n    class = \"esq-icon-button\"\r\n    matTooltip=\"Load more...\"\r\n    disabled = \"{{!canBtnMoreClick()}}\"\r\n    (click)=\"onBtnMoreClick()\">\r\n    <mat-icon>rotate_right</mat-icon>\r\n  </button>\r\n\r\n</mat-toolbar>\r\n\r\n<div\r\n  #contextMenuTrigger=\"matMenuTrigger\"\r\n  class=\"esq-context-menu-anchor\"\r\n  [style.left.px]=\"contextMenuPosition.x\"\r\n  [style.top.px]=\"contextMenuPosition.y\"\r\n  [matMenuTriggerFor]=\"esqContextMenu\">\r\n</div>\r\n\r\n<mat-menu #esqContextMenu=\"matMenu\">\r\n\r\n  <button #menuItemOpen mat-menu-item\r\n      class=\"esq-menu-item\"\r\n      [disabled]=\"!canMenuOpenClick()\"\r\n      (click)=\"onMenuOpenClick()\">\r\n      <p class=\"esq-menu-grid\">\r\n          <span class=\"esq-menu-label\" [style.font-weight]=\"contextMenuNode?.expandable() ? 'bold' : 'normal'\">Open</span>\r\n          <span class=\"esq-menu-hotkey\">Enter</span>\r\n      </p>\r\n  </button>\r\n\r\n  <mat-divider></mat-divider>\r\n\r\n  <button mat-menu-item\r\n    class=\"esq-menu-item\"\r\n    [disabled]=\"!canCmdBackClick()\"\r\n    (click)=\"onCmdBackClick()\">\r\n      <p class=\"esq-menu-grid\">\r\n          <span class=\"esq-menu-label\">Back</span>\r\n          <span class=\"esq-menu-hotkey\">Ctrl+\u2B9C</span>\r\n      </p>\r\n  </button>\r\n\r\n  <button mat-menu-item\r\n      class=\"esq-menu-item\"\r\n      [disabled]=\"!canCmdForwardClick()\"\r\n      (click)=\"onCmdForwardClick()\">\r\n      <p class=\"esq-menu-grid\">\r\n          <span class=\"esq-menu-label\">Forward</span>\r\n          <span class=\"esq-menu-hotkey\">Ctrl+\u2B9E</span>\r\n      </p>\r\n  </button>\r\n\r\n  <button mat-menu-item\r\n      class=\"esq-menu-item\"\r\n      [disabled]=\"!canCmdUpClick()\"\r\n      (click)=\"onCmdUpClick()\">\r\n      <p class=\"esq-menu-grid\">\r\n          <span class=\"esq-menu-label\">Up</span>\r\n          <span class=\"esq-menu-hotkey\">Ctrl+\u2B9D</span>\r\n      </p>\r\n  </button>\r\n\r\n  <button mat-menu-item\r\n    class=\"esq-menu-item\"\r\n    [disabled]=\"!canCmdGotoClick(true)\"\r\n    (click)=\"onCmdGotoClick(true)\">\r\n      <p class=\"esq-menu-grid\">\r\n          <span class=\"esq-menu-label\">Go to origin</span>\r\n      </p>\r\n  </button>\r\n\r\n  <mat-divider></mat-divider>\r\n\r\n  <button #menuItemDetails mat-menu-item\r\n      class=\"esq-menu-item\"\r\n      [disabled]=\"!canCmdDetailsClick(true)\"\r\n      (click)=\"onCmdDetailsClick(true)\">\r\n      <p class=\"esq-menu-grid\">\r\n          <span class=\"esq-menu-label\" [style.font-weight]=\"contextMenuNode && !contextMenuNode.expandable() ? 'bold' : 'normal'\">Details</span>\r\n          <span class=\"esq-menu-hotkey\">Alt+Enter</span>\r\n      </p>\r\n  </button>\r\n\r\n  @for (item of esqCommandMenuItems; track item.cmd) {\r\n      @if (item.subItems !== undefined) {\r\n          <button mat-menu-item\r\n                  class=\"esq-menu-item\"\r\n                  [disabled]=\"!canSubCmdClick(item, true)\"\r\n                  [matMenuTriggerFor]=\"contextSubMenu\"\r\n                  (click)=\"prepareSubmenu(item, true)\">\r\n              <p class=\"esq-menu-grid\">\r\n                  <span class=\"esq-menu-label\">{{item.label}}</span>\r\n              </p>\r\n          </button>\r\n      } @else if (item.cmd === 'new') {\r\n          <mat-divider></mat-divider>\r\n          <button mat-menu-item\r\n                  class=\"esq-menu-item\"\r\n                  [disabled]=\"!canCmdNewClick(true)\"\r\n                  [matMenuTriggerFor]=\"contextNewSubmenu\">\r\n              <p class=\"esq-menu-grid\">\r\n                  <span class=\"esq-menu-label\">{{item.label}}</span>\r\n              </p>\r\n          </button>\r\n      } @else {\r\n          <button mat-menu-item\r\n                  class=\"esq-menu-item\"\r\n                  [disabled]=\"!canCmdClick(item.cmd, true)\"\r\n                  (click)=\"onCmdClick(item.cmd, true)\">\r\n              <p class=\"esq-menu-grid\">\r\n                  <span class=\"esq-menu-label\">{{item.label}}</span>\r\n              </p>\r\n          </button>\r\n      }\r\n  }\r\n</mat-menu>\r\n\r\n<mat-menu #contextSubMenu=\"matMenu\">\r\n  @for (sub of activeSubItems; track sub.subCmd) {\r\n    <button mat-menu-item class=\"esq-menu-item\"\r\n        [disabled]=\"sub.disabled\"\r\n        (click)=\"onSubCmdClick(sub.subCmd, true)\">\r\n      @if (sub.icon) {\r\n        <img [src]=\"sub.icon\" class=\"esq-menu-icon\"/>\r\n      }\r\n      <span class=\"esq-menu-label\">{{sub.label}}</span>\r\n    </button>\r\n  }\r\n</mat-menu>\r\n\r\n<mat-menu #contextNewSubmenu=\"matMenu\">\r\n  @for (item of contextNewMenuItems; track item.kind.id) {\r\n    <button\r\n      mat-menu-item\r\n      class=\"esq-menu-item\"\r\n      [disabled]=\"!canCreateKind(item.kind.id)\"\r\n      (click)=\"onCmdNewClick(item.kind.id,true)\">\r\n      @if (item.icon) {\r\n        <img [src]=\"item.icon\" class=\"esq-menu-icon\"/>\r\n      }\r\n      <span class=\"esq-menu-label\">{{item.label}}</span>\r\n    </button>\r\n  }\r\n</mat-menu>\r\n\r\n<mat-menu #toolbarSubMenu=\"matMenu\">\r\n  @for (sub of activeSubItems; track sub.subCmd) {\r\n    <button mat-menu-item class=\"esq-menu-item\"\r\n        [disabled]=\"sub.disabled\"\r\n        (click)=\"onSubCmdClick(sub.subCmd, false)\">\r\n      @if (sub.icon) {\r\n        <img [src]=\"sub.icon\" class=\"esq-menu-icon\"/>\r\n      }\r\n      <span class=\"esq-menu-label\">{{sub.label}}</span>\r\n    </button>\r\n  }\r\n</mat-menu>\r\n\r\n<mat-menu #toolbarNewMenu=\"matMenu\">\r\n  @for (item of toolbarNewMenuItems; track item.kind.id) {\r\n    <button\r\n      mat-menu-item\r\n      class=\"esq-menu-item\"\r\n      [disabled]=\"!canCreateKind(item.kind.id)\"\r\n      (click)=\"onCmdNewClick(item.kind.id,false)\">\r\n      @if (item.icon) {\r\n        <img [src]=\"item.icon\" class=\"esq-menu-icon\"/>\r\n      }\r\n      <span class=\"esq-menu-label\">{{item.label}}</span>\r\n    </button>\r\n  }\r\n</mat-menu>\r\n\r\n<mat-sidenav-container class=\"esq-sidenav-container\" esqResize>\r\n    <mat-sidenav \r\n      #EsqSidenav\r\n      style=\"width: 250px\"\r\n      role=\"navigation\"\r\n      mode=\"side\" \r\n      opened \r\n      class=\"esq-sidenav\"\r\n      [fixedInViewport]= \"false\" \r\n      [fixedTopGap]= \"0\" \r\n      [fixedBottomGap]= \"0\"\r\n      (contextmenu)=\"onEmptyTreeContextMenu($event)\"      \r\n    >\r\n    \r\n      @if (initialDataLoading()) {\r\n        <div>\r\n          <span style=\"position:relative; left:18px;\">...Loading initial data...</span>\r\n        </div>      \r\n      }\r\n      <mat-tree #EsqExplTree\r\n        [dataSource]=\"datasource.tree\"\r\n        [levelAccessor]=\"treeLevelAccessor\">\r\n        <mat-tree-node\r\n          *matTreeNodeDef=\"let _node let i = index\"\r\n          #nodeElement [attr.id]=\"'node-' + _node.id\"\r\n          matTreeNodePadding\r\n          matTreeNodePaddingIndent=\"30\"\r\n          class=\"esq-tree-node\"\r\n          (expandedChange)=\"onTreeNodeExpansion($event,_node)\" \r\n          (contextmenu)=\"onTreeContextMenu($event, _node)\"\r\n          (click)=\"onTreeClick(_node)\" \r\n          (dblclick)=\"onTreeDoubleClick(_node)\"\r\n          (mouseenter)=\"onTreeNodeEnter(_node)\" \r\n          (mouseleave)=\"onTreeNodeLeave()\"\r\n          (focus)=\"onTreeFocus(_node)\"\r\n          (focusout)=\"onTreeFocusOut(_node)\"\r\n          (keydown)=\"onTreeKeydown($event, node)\"\r\n          [ngClass]=\"{ 'esq-active-node-highlight': treeNodeActive === _node && treeOnFocus,  'esq-active-node-outlight': treeNodeActive === _node && !treeOnFocus, 'esq-mouse-node-highlight': treeNodeEntered === _node}\"\r\n        >\r\n          @let node = _node | asEsqTreeNode;\r\n<!--   align-items: left; -->\r\n          <div style=\"display: flex; flex-direction: row; justify-items: left\">\r\n            <div \r\n              style=\"z-index:0; user-select: none; display: flex; flex-direction: row; align-items: center;\" \r\n            > \r\n              <mat-icon class=\"mat-icon-rtl-mirror\">\r\n                @if (node.hasChild()) {\r\n                      {{ node.expanded() ? 'expand_more' : 'chevron_right' }}\r\n                }\r\n              </mat-icon>\r\n              @if (hasIcon(node)) {\r\n                <img src=\"{{nodeIcon(node)}}\" class=\"esq-base-icon\"/>\r\n                <img src=\"{{nodeStatusIcon(node)}}\" class=\"esq-overlay-icon\" />\r\n              }\r\n              @if (node.hasMore()) {\r\n                  <div class=\"esq-overlay-text\"> {{ node.name }} ...</div>\r\n              } @else {\r\n                  <div class=\"esq-overlay-text\"> {{ node.name }}  </div>\r\n              }\r\n              </div> \r\n          </div>\r\n        </mat-tree-node>\r\n      </mat-tree>\r\n    </mat-sidenav>\r\n\r\n    <mat-sidenav-content (contextmenu)=\"onEmptyListContextMenu($event)\">\r\n      <table mat-table\r\n        #EsqExplList \r\n        [dataSource]=\"datasource.list\" \r\n        class=\"mat-table esq-table\"\r\n      >\r\n        @for (column of listColumns; track column.columnDef; let i = $index) {\r\n          <ng-container [matColumnDef]=\"column.columnDef!\" >\r\n            <th mat-header-cell *matHeaderCellDef  esqResize class=\"mat-elevation-z2 esq-elevation-z2\">\r\n              {{column.header}}\r\n            </th>\r\n            <td mat-cell *matCellDef=\"let node\" class=\"mat-cell esq-ellipsis-cell\">\r\n              @if (column.columnDef === 'name') {\r\n                <!--span class=\"esq-ellipsis-text\" -->\r\n                <span class=\"esq-ellipsis-text\">\r\n                  <img src=\"{{nodeIcon(node)}}\" class=\"esq-base-icon \"/>\r\n                  <img src=\"{{nodeStatusIcon(node)}}\" class=\"esq-overlay-icon\" />\r\n                  {{node.value(column.columnDef) }}\r\n                </span>\r\n                <!-- /span -->\r\n              } @else {\r\n                <span class=\"esq-ellipsis-text\">\r\n                  {{node.value(column.columnDef) }}\r\n                </span>\r\n              }\r\n            </td>\r\n          </ng-container>\r\n        }\r\n        <tr mat-header-row \r\n          *matHeaderRowDef=\"listColumnsDisplayed; sticky: true\" \r\n          class=\"mat-header-row esq-header-row\">\r\n        </tr>\r\n        <tr mat-row\r\n            *matRowDef=\"let node; let i = index; columns: listColumnsDisplayed;\" \r\n            class=\"mat-row esq-row\"\r\n            (contextmenu)=\"onListContextMenu($event, node)\"\r\n            (mouseover)=\"listNodeHoveredIndex = i\"\r\n            (mouseout)=\"listNodeHoveredIndex = -1\"\r\n            [ngClass]=\"{'esq-active-node-highlight': node === listNodeFocused && !treeOnFocus,  'esq-active-node-outlight': node === listNodeFocused && treeOnFocus, 'esq-mouse-node-highlight': listNodeHoveredIndex === i}\"\r\n            (click)=\"onListClick(node)\"\r\n            (dblclick)=\"onListDoubleClick(node)\"\r\n            (keydown)=\"onListKeydown($event, node, i)\"\r\n            (focus)=\"onListFocus(node)\"\r\n            (focusout)=\"onListFocusOut(node)\"\r\n            [tabindex]=\"node === listNodeFocused ? 0 : -1\"\r\n        >\r\n        </tr>  \r\n      </table>\r\n    </mat-sidenav-content>\r\n  </mat-sidenav-container>\r\n</div>  \r\n\r\n\r\n\r\n", styles: [".esq-explorer{position:relative;height:100%;min-height:0;box-sizing:border-box}.esq-explorer .esq-explorer-container{position:relative;height:100%}.esq-explorer .esq-toolbar{position:relative;top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:9pt;font-weight:400;margin:0;display:grid;grid-template-columns:repeat(6,18px) auto repeat(var(--right-buttons-count, 3),18px);gap:4px}.esq-explorer .esq-toolbar .esq-icon-button{transform:scale(.75)!important}.esq-explorer .esq-toolbar .esq-path-bar{border:1px solid #ccc;border-radius:16px;box-shadow:inset 1px 1px 1px #00000080;background-color:#0000;padding-left:10px;margin-left:10px}.esq-explorer .esq-icon-button-raised{border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0}.esq-explorer .esq-icon-button-downraised{border:1px solid #ccc;box-shadow:inset 1px 1px 1px #00000080}.esq-explorer .esq-toolbar-row{height:30px;border:4px black;background:#ebebeb80;justify-content:space-between}.esq-explorer .esq-ellipsis-cell{max-width:10px;overflow:hidden;-webkit-user-select:none!important;user-select:none!important;border:none!important}.esq-explorer .esq-ellipsis-text{white-space:nowrap;text-overflow:ellipsis;display:block}.esq-explorer .esq-elevation-z2{-webkit-user-select:none;user-select:none}.esq-explorer .esq-sidenav-container{position:absolute;inset:50px 0 0}.esq-explorer .esq-sidenav{display:flex;align-items:center;justify-content:center;white-space:nowrap;max-width:400px;min-width:100px;overflow:hidden}.esq-explorer .esq-tree-node{display:flex;align-items:start;flex-direction:column;font-size:12px;min-height:18px}.esq-explorer .esq-active-node-highlight{background-color:#add8e6}.esq-explorer .esq-active-node-outlight{background-color:#9df0c7}.esq-explorer .esq-mouse-node-highlight{background-color:#e8f5fa}.esq-explorer .esq-base-icon{position:relative;height:24px;width:24px;vertical-align:middle;bottom:0;left:0;z-index:1}.esq-explorer .esq-overlay-icon{position:relative;height:12px;width:12px;top:-4px;left:-6px;z-index:2}.esq-explorer .esq-overlay-text{font-size:9pt;font-weight:400;position:relative;bottom:0;left:-4px;z-index:3}.esq-explorer .esq-loading-icon{position:relative;height:16px;bottom:-4px;width:auto;display:block}.esq-explorer .esq-loading-div{position:relative;height:16px;left:4px;width:28px;display:block;background-position:right;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}.esq-explorer .esq-table{width:100%}.esq-explorer .esq-header-row{font-size:9pt;font-weight:400;height:18px;background-color:#f5f5f5;padding-bottom:2px}.esq-explorer .esq-row{font-size:9pt;font-weight:400;height:16px;border-bottom:none}.esq-explorer .esq-context-menu-anchor{position:fixed;z-index:10000;width:1px;height:1px;pointer-events:none}.esq-menu-item{line-height:1!important;min-height:12px!important}.esq-menu-grid{display:grid;grid-template-columns:120px 1fr;margin:0;height:12px}.esq-menu-label{font-size:9pt}.esq-menu-hotkey{font-size:9pt;color:#888}.esq-menu-icon{position:relative;height:18px!important;width:18px!important;vertical-align:middle;bottom:0;left:0;margin-right:4px!important;z-index:1}\n"], dependencies: [{ kind: "component", type: MatIcon, selector: "mat-icon", inputs: ["color", "inline", "svgIcon", "fontSet", "fontIcon"], exportAs: ["matIcon"] }, { kind: "ngmodule", type: MatButtonModule }, { kind: "component", type: i4.MatIconButton, selector: "button[mat-icon-button], a[mat-icon-button], button[matIconButton], a[matIconButton]", exportAs: ["matButton", "matAnchor"] }, { kind: "ngmodule", type: MatButtonToggleModule }, { kind: "ngmodule", type: MatToolbarModule }, { kind: "component", type: i3.MatToolbar, selector: "mat-toolbar", inputs: ["color"], exportAs: ["matToolbar"] }, { kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i2.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "ngmodule", type: MatSidenavModule }, { kind: "component", type: i5$1.MatSidenav, selector: "mat-sidenav", inputs: ["fixedInViewport", "fixedTopGap", "fixedBottomGap"], exportAs: ["matSidenav"] }, { kind: "component", type: i5$1.MatSidenavContainer, selector: "mat-sidenav-container", exportAs: ["matSidenavContainer"] }, { kind: "component", type: i5$1.MatSidenavContent, selector: "mat-sidenav-content" }, { kind: "ngmodule", type: MatTooltipModule }, { kind: "directive", type: i6$1.MatTooltip, selector: "[matTooltip]", inputs: ["matTooltipPosition", "matTooltipPositionAtOrigin", "matTooltipDisabled", "matTooltipShowDelay", "matTooltipHideDelay", "matTooltipTouchGestures", "matTooltip", "matTooltipClass"], exportAs: ["matTooltip"] }, { kind: "ngmodule", type: MatTableModule }, { kind: "component", type: i7.MatTable, selector: "mat-table, table[mat-table]", exportAs: ["matTable"] }, { kind: "directive", type: i7.MatHeaderCellDef, selector: "[matHeaderCellDef]" }, { kind: "directive", type: i7.MatHeaderRowDef, selector: "[matHeaderRowDef]", inputs: ["matHeaderRowDef", "matHeaderRowDefSticky"] }, { kind: "directive", type: i7.MatColumnDef, selector: "[matColumnDef]", inputs: ["matColumnDef"] }, { kind: "directive", type: i7.MatCellDef, selector: "[matCellDef]" }, { kind: "directive", type: i7.MatRowDef, selector: "[matRowDef]", inputs: ["matRowDefColumns", "matRowDefWhen"] }, { kind: "directive", type: i7.MatHeaderCell, selector: "mat-header-cell, th[mat-header-cell]" }, { kind: "directive", type: i7.MatCell, selector: "mat-cell, td[mat-cell]" }, { kind: "component", type: i7.MatHeaderRow, selector: "mat-header-row, tr[mat-header-row]", exportAs: ["matHeaderRow"] }, { kind: "component", type: i7.MatRow, selector: "mat-row, tr[mat-row]", exportAs: ["matRow"] }, { kind: "component", type: MatTree, selector: "mat-tree", exportAs: ["matTree"] }, { kind: "directive", type: MatTreeNode, selector: "mat-tree-node", inputs: ["tabIndex", "disabled"], outputs: ["activation", "expandedChange"], exportAs: ["matTreeNode"] }, { kind: "directive", type: MatTreeNodeDef, selector: "[matTreeNodeDef]", inputs: ["matTreeNodeDefWhen", "matTreeNode"] }, { kind: "directive", type: MatTreeNodePadding, selector: "[matTreeNodePadding]", inputs: ["matTreeNodePadding", "matTreeNodePaddingIndent"] }, { kind: "directive", type: EsqResizeDirective, selector: "[esqResize]", inputs: ["resizableTable"] }, { kind: "ngmodule", type: MatMenuModule }, { kind: "component", type: i8.MatMenu, selector: "mat-menu", inputs: ["backdropClass", "aria-label", "aria-labelledby", "aria-describedby", "xPosition", "yPosition", "overlapTrigger", "hasBackdrop", "class", "classList"], outputs: ["closed", "close"], exportAs: ["matMenu"] }, { kind: "component", type: i8.MatMenuItem, selector: "[mat-menu-item]", inputs: ["role", "disabled", "disableRipple"], exportAs: ["matMenuItem"] }, { kind: "directive", type: i8.MatMenuTrigger, selector: "[mat-menu-trigger-for], [matMenuTriggerFor]", inputs: ["mat-menu-trigger-for", "matMenuTriggerFor", "matMenuTriggerData", "matMenuTriggerRestoreFocus"], outputs: ["menuOpened", "onMenuOpen", "menuClosed", "onMenuClose"], exportAs: ["matMenuTrigger"] }, { kind: "ngmodule", type: MatDividerModule }, { kind: "component", type: i9.MatDivider, selector: "mat-divider", inputs: ["vertical", "inset"] }, { kind: "pipe", type: AsEsqTreeNodePipe, name: "asEsqTreeNode" }], encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.16", ngImport: i0, type: EsqExplorerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'esqExplorer', standalone: true, imports: [
                        MatIcon,
                        MatButtonModule,
                        MatButtonToggleModule,
                        MatToolbarModule,
                        CommonModule,
                        MatSidenavModule,
                        MatTooltipModule,
                        MatTableModule,
                        AsEsqTreeNodePipe,
                        MatTree,
                        MatTreeNode,
                        MatTreeNodeDef,
                        MatTreeNodePadding,
                        EsqResizeDirective,
                        MatMenuModule,
                        MatDividerModule,
                    ], encapsulation: ViewEncapsulation.None, host: { 'class': 'esq-explorer' }, template: "<!--\r\n  Esquire frameworks (tm)\r\n \r\n  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me\r\n  mailto:mir0n.the.programmer@gmail.com\r\n\r\n  History:\r\n-->\r\n<div class=\"esq-explorer-container\">\r\n<mat-toolbar class=\"mat-elevation-z2 esq-toolbar\" [style.--right-buttons-count]=\"rightButtonsCount()\">\r\n\r\n  <button matIconButton\r\n    class = \"esq-icon-button\"\r\n    matTooltip = \"{{EsqSidenav.opened ? 'Hide tree navigation' : 'Open tree navigation'}}\" \r\n    (click)=\"EsqSidenav.toggle()\">\r\n    <mat-icon>\r\n        {{EsqSidenav.opened ? 'folder_open': 'folder_off'}}\"    \r\n    </mat-icon>\r\n  </button>\r\n\r\n  <button #esqBtnBack matIconButton \r\n    class = \"esq-icon-button\"\r\n    matTooltip=\"Back\"\r\n    disabled = \"{{!canCmdBackClick()}}\"\r\n    (click)=\"onCmdBackClick()\">\r\n    <mat-icon>arrow_back</mat-icon>\r\n  </button>\r\n\r\n  <button #esqBtnForward matIconButton \r\n    class = \"esq-icon-button\"\r\n    matTooltip=\"Forward\"\r\n    disabled = \"{{!canCmdForwardClick()}}\"\r\n   (click)=\"onCmdForwardClick()\">\r\n    <mat-icon>arrow_forward</mat-icon>\r\n  </button>\r\n\r\n  <button #esqBtnUp matIconButton \r\n    class = \"esq-icon-button\"\r\n    matTooltip=\"Up one level \"\r\n    disabled = \"{{!canCmdUpClick()}}\"\r\n    (click)=\"onCmdUpClick()\">\r\n    \r\n    <mat-icon>arrow_upward</mat-icon>\r\n  </button>\r\n\r\n  @if (initialDataLoading() || dataLoading()) {\r\n    <span class=\"esq-loading-div\" ></span>\r\n  } @else {\r\n    <button matIconButton \r\n      class = \"esq-icon-button\"\r\n      matTooltip=\"Refresh\"\r\n      (click)=\"onBtnRefreshClick()\">\r\n      <mat-icon>refresh</mat-icon>\r\n    </button>\r\n  }\r\n  <div ></div>\r\n\r\n  <div class=\"esq-path-bar\">\r\n    {{listNodeOwnerPath()}}\r\n  </div>\r\n\r\n  @for (item of esqCommandMenuItems.slice().reverse(); track item.cmd) {\r\n      @if (item.subItems !== undefined) {\r\n          <button matIconButton\r\n              class = \"esq-icon-button\"\r\n              matTooltip={{item.label}}\r\n              [disabled]=\"!canSubCmdClick(item, false)\"\r\n              [matMenuTriggerFor]=\"toolbarSubMenu\"\r\n              (click)=\"prepareSubmenu(item, false)\">\r\n              <mat-icon>{{item.icon}}</mat-icon>\r\n          </button>\r\n      } @else if (item.cmd === 'new') {\r\n          <button matIconButton\r\n              class = \"esq-icon-button\"\r\n              matTooltip={{item.label}}\r\n              [disabled]=\"!canCmdNewClick(false)\"\r\n              [matMenuTriggerFor]=\"toolbarNewMenu\">\r\n              <mat-icon>{{item.icon}}</mat-icon>\r\n          </button>\r\n      } @else {\r\n          <button matIconButton\r\n              class = \"esq-icon-button\"\r\n              matTooltip={{item.label}}\r\n              [disabled]=\"!canCmdClick(item.cmd, false)\"\r\n              (click)=\"onCmdClick(item.cmd, false)\">\r\n              <mat-icon>{{item.icon}}</mat-icon>\r\n          </button>\r\n      }\r\n  }\r\n\r\n  <button #matBtnDetails matIconButton\r\n    class = \"esq-icon-button\"\r\n    matTooltip=\"Details\"  \r\n    disabled = \"{{!canCmdDetailsClick(false)}}\"\r\n    (click)=\"onCmdDetailsClick(false)\">\r\n    <mat-icon>wysiwyg</mat-icon>\r\n  </button>\r\n\r\n  <button #esqBtnGoto matIconButton \r\n    class = \"esq-icon-button\"\r\n    matTooltip=\"Go to origin\"  \r\n    disabled = \"{{!canCmdGotoClick(false)}}\"\r\n    (click)=\"onCmdGotoClick(false)\">\r\n    <mat-icon>launch</mat-icon>\r\n  </button>\r\n\r\n  <button #esqBtnMore matIconButton\r\n    class = \"esq-icon-button\"\r\n    matTooltip=\"Load more...\"\r\n    disabled = \"{{!canBtnMoreClick()}}\"\r\n    (click)=\"onBtnMoreClick()\">\r\n    <mat-icon>rotate_right</mat-icon>\r\n  </button>\r\n\r\n</mat-toolbar>\r\n\r\n<div\r\n  #contextMenuTrigger=\"matMenuTrigger\"\r\n  class=\"esq-context-menu-anchor\"\r\n  [style.left.px]=\"contextMenuPosition.x\"\r\n  [style.top.px]=\"contextMenuPosition.y\"\r\n  [matMenuTriggerFor]=\"esqContextMenu\">\r\n</div>\r\n\r\n<mat-menu #esqContextMenu=\"matMenu\">\r\n\r\n  <button #menuItemOpen mat-menu-item\r\n      class=\"esq-menu-item\"\r\n      [disabled]=\"!canMenuOpenClick()\"\r\n      (click)=\"onMenuOpenClick()\">\r\n      <p class=\"esq-menu-grid\">\r\n          <span class=\"esq-menu-label\" [style.font-weight]=\"contextMenuNode?.expandable() ? 'bold' : 'normal'\">Open</span>\r\n          <span class=\"esq-menu-hotkey\">Enter</span>\r\n      </p>\r\n  </button>\r\n\r\n  <mat-divider></mat-divider>\r\n\r\n  <button mat-menu-item\r\n    class=\"esq-menu-item\"\r\n    [disabled]=\"!canCmdBackClick()\"\r\n    (click)=\"onCmdBackClick()\">\r\n      <p class=\"esq-menu-grid\">\r\n          <span class=\"esq-menu-label\">Back</span>\r\n          <span class=\"esq-menu-hotkey\">Ctrl+\u2B9C</span>\r\n      </p>\r\n  </button>\r\n\r\n  <button mat-menu-item\r\n      class=\"esq-menu-item\"\r\n      [disabled]=\"!canCmdForwardClick()\"\r\n      (click)=\"onCmdForwardClick()\">\r\n      <p class=\"esq-menu-grid\">\r\n          <span class=\"esq-menu-label\">Forward</span>\r\n          <span class=\"esq-menu-hotkey\">Ctrl+\u2B9E</span>\r\n      </p>\r\n  </button>\r\n\r\n  <button mat-menu-item\r\n      class=\"esq-menu-item\"\r\n      [disabled]=\"!canCmdUpClick()\"\r\n      (click)=\"onCmdUpClick()\">\r\n      <p class=\"esq-menu-grid\">\r\n          <span class=\"esq-menu-label\">Up</span>\r\n          <span class=\"esq-menu-hotkey\">Ctrl+\u2B9D</span>\r\n      </p>\r\n  </button>\r\n\r\n  <button mat-menu-item\r\n    class=\"esq-menu-item\"\r\n    [disabled]=\"!canCmdGotoClick(true)\"\r\n    (click)=\"onCmdGotoClick(true)\">\r\n      <p class=\"esq-menu-grid\">\r\n          <span class=\"esq-menu-label\">Go to origin</span>\r\n      </p>\r\n  </button>\r\n\r\n  <mat-divider></mat-divider>\r\n\r\n  <button #menuItemDetails mat-menu-item\r\n      class=\"esq-menu-item\"\r\n      [disabled]=\"!canCmdDetailsClick(true)\"\r\n      (click)=\"onCmdDetailsClick(true)\">\r\n      <p class=\"esq-menu-grid\">\r\n          <span class=\"esq-menu-label\" [style.font-weight]=\"contextMenuNode && !contextMenuNode.expandable() ? 'bold' : 'normal'\">Details</span>\r\n          <span class=\"esq-menu-hotkey\">Alt+Enter</span>\r\n      </p>\r\n  </button>\r\n\r\n  @for (item of esqCommandMenuItems; track item.cmd) {\r\n      @if (item.subItems !== undefined) {\r\n          <button mat-menu-item\r\n                  class=\"esq-menu-item\"\r\n                  [disabled]=\"!canSubCmdClick(item, true)\"\r\n                  [matMenuTriggerFor]=\"contextSubMenu\"\r\n                  (click)=\"prepareSubmenu(item, true)\">\r\n              <p class=\"esq-menu-grid\">\r\n                  <span class=\"esq-menu-label\">{{item.label}}</span>\r\n              </p>\r\n          </button>\r\n      } @else if (item.cmd === 'new') {\r\n          <mat-divider></mat-divider>\r\n          <button mat-menu-item\r\n                  class=\"esq-menu-item\"\r\n                  [disabled]=\"!canCmdNewClick(true)\"\r\n                  [matMenuTriggerFor]=\"contextNewSubmenu\">\r\n              <p class=\"esq-menu-grid\">\r\n                  <span class=\"esq-menu-label\">{{item.label}}</span>\r\n              </p>\r\n          </button>\r\n      } @else {\r\n          <button mat-menu-item\r\n                  class=\"esq-menu-item\"\r\n                  [disabled]=\"!canCmdClick(item.cmd, true)\"\r\n                  (click)=\"onCmdClick(item.cmd, true)\">\r\n              <p class=\"esq-menu-grid\">\r\n                  <span class=\"esq-menu-label\">{{item.label}}</span>\r\n              </p>\r\n          </button>\r\n      }\r\n  }\r\n</mat-menu>\r\n\r\n<mat-menu #contextSubMenu=\"matMenu\">\r\n  @for (sub of activeSubItems; track sub.subCmd) {\r\n    <button mat-menu-item class=\"esq-menu-item\"\r\n        [disabled]=\"sub.disabled\"\r\n        (click)=\"onSubCmdClick(sub.subCmd, true)\">\r\n      @if (sub.icon) {\r\n        <img [src]=\"sub.icon\" class=\"esq-menu-icon\"/>\r\n      }\r\n      <span class=\"esq-menu-label\">{{sub.label}}</span>\r\n    </button>\r\n  }\r\n</mat-menu>\r\n\r\n<mat-menu #contextNewSubmenu=\"matMenu\">\r\n  @for (item of contextNewMenuItems; track item.kind.id) {\r\n    <button\r\n      mat-menu-item\r\n      class=\"esq-menu-item\"\r\n      [disabled]=\"!canCreateKind(item.kind.id)\"\r\n      (click)=\"onCmdNewClick(item.kind.id,true)\">\r\n      @if (item.icon) {\r\n        <img [src]=\"item.icon\" class=\"esq-menu-icon\"/>\r\n      }\r\n      <span class=\"esq-menu-label\">{{item.label}}</span>\r\n    </button>\r\n  }\r\n</mat-menu>\r\n\r\n<mat-menu #toolbarSubMenu=\"matMenu\">\r\n  @for (sub of activeSubItems; track sub.subCmd) {\r\n    <button mat-menu-item class=\"esq-menu-item\"\r\n        [disabled]=\"sub.disabled\"\r\n        (click)=\"onSubCmdClick(sub.subCmd, false)\">\r\n      @if (sub.icon) {\r\n        <img [src]=\"sub.icon\" class=\"esq-menu-icon\"/>\r\n      }\r\n      <span class=\"esq-menu-label\">{{sub.label}}</span>\r\n    </button>\r\n  }\r\n</mat-menu>\r\n\r\n<mat-menu #toolbarNewMenu=\"matMenu\">\r\n  @for (item of toolbarNewMenuItems; track item.kind.id) {\r\n    <button\r\n      mat-menu-item\r\n      class=\"esq-menu-item\"\r\n      [disabled]=\"!canCreateKind(item.kind.id)\"\r\n      (click)=\"onCmdNewClick(item.kind.id,false)\">\r\n      @if (item.icon) {\r\n        <img [src]=\"item.icon\" class=\"esq-menu-icon\"/>\r\n      }\r\n      <span class=\"esq-menu-label\">{{item.label}}</span>\r\n    </button>\r\n  }\r\n</mat-menu>\r\n\r\n<mat-sidenav-container class=\"esq-sidenav-container\" esqResize>\r\n    <mat-sidenav \r\n      #EsqSidenav\r\n      style=\"width: 250px\"\r\n      role=\"navigation\"\r\n      mode=\"side\" \r\n      opened \r\n      class=\"esq-sidenav\"\r\n      [fixedInViewport]= \"false\" \r\n      [fixedTopGap]= \"0\" \r\n      [fixedBottomGap]= \"0\"\r\n      (contextmenu)=\"onEmptyTreeContextMenu($event)\"      \r\n    >\r\n    \r\n      @if (initialDataLoading()) {\r\n        <div>\r\n          <span style=\"position:relative; left:18px;\">...Loading initial data...</span>\r\n        </div>      \r\n      }\r\n      <mat-tree #EsqExplTree\r\n        [dataSource]=\"datasource.tree\"\r\n        [levelAccessor]=\"treeLevelAccessor\">\r\n        <mat-tree-node\r\n          *matTreeNodeDef=\"let _node let i = index\"\r\n          #nodeElement [attr.id]=\"'node-' + _node.id\"\r\n          matTreeNodePadding\r\n          matTreeNodePaddingIndent=\"30\"\r\n          class=\"esq-tree-node\"\r\n          (expandedChange)=\"onTreeNodeExpansion($event,_node)\" \r\n          (contextmenu)=\"onTreeContextMenu($event, _node)\"\r\n          (click)=\"onTreeClick(_node)\" \r\n          (dblclick)=\"onTreeDoubleClick(_node)\"\r\n          (mouseenter)=\"onTreeNodeEnter(_node)\" \r\n          (mouseleave)=\"onTreeNodeLeave()\"\r\n          (focus)=\"onTreeFocus(_node)\"\r\n          (focusout)=\"onTreeFocusOut(_node)\"\r\n          (keydown)=\"onTreeKeydown($event, node)\"\r\n          [ngClass]=\"{ 'esq-active-node-highlight': treeNodeActive === _node && treeOnFocus,  'esq-active-node-outlight': treeNodeActive === _node && !treeOnFocus, 'esq-mouse-node-highlight': treeNodeEntered === _node}\"\r\n        >\r\n          @let node = _node | asEsqTreeNode;\r\n<!--   align-items: left; -->\r\n          <div style=\"display: flex; flex-direction: row; justify-items: left\">\r\n            <div \r\n              style=\"z-index:0; user-select: none; display: flex; flex-direction: row; align-items: center;\" \r\n            > \r\n              <mat-icon class=\"mat-icon-rtl-mirror\">\r\n                @if (node.hasChild()) {\r\n                      {{ node.expanded() ? 'expand_more' : 'chevron_right' }}\r\n                }\r\n              </mat-icon>\r\n              @if (hasIcon(node)) {\r\n                <img src=\"{{nodeIcon(node)}}\" class=\"esq-base-icon\"/>\r\n                <img src=\"{{nodeStatusIcon(node)}}\" class=\"esq-overlay-icon\" />\r\n              }\r\n              @if (node.hasMore()) {\r\n                  <div class=\"esq-overlay-text\"> {{ node.name }} ...</div>\r\n              } @else {\r\n                  <div class=\"esq-overlay-text\"> {{ node.name }}  </div>\r\n              }\r\n              </div> \r\n          </div>\r\n        </mat-tree-node>\r\n      </mat-tree>\r\n    </mat-sidenav>\r\n\r\n    <mat-sidenav-content (contextmenu)=\"onEmptyListContextMenu($event)\">\r\n      <table mat-table\r\n        #EsqExplList \r\n        [dataSource]=\"datasource.list\" \r\n        class=\"mat-table esq-table\"\r\n      >\r\n        @for (column of listColumns; track column.columnDef; let i = $index) {\r\n          <ng-container [matColumnDef]=\"column.columnDef!\" >\r\n            <th mat-header-cell *matHeaderCellDef  esqResize class=\"mat-elevation-z2 esq-elevation-z2\">\r\n              {{column.header}}\r\n            </th>\r\n            <td mat-cell *matCellDef=\"let node\" class=\"mat-cell esq-ellipsis-cell\">\r\n              @if (column.columnDef === 'name') {\r\n                <!--span class=\"esq-ellipsis-text\" -->\r\n                <span class=\"esq-ellipsis-text\">\r\n                  <img src=\"{{nodeIcon(node)}}\" class=\"esq-base-icon \"/>\r\n                  <img src=\"{{nodeStatusIcon(node)}}\" class=\"esq-overlay-icon\" />\r\n                  {{node.value(column.columnDef) }}\r\n                </span>\r\n                <!-- /span -->\r\n              } @else {\r\n                <span class=\"esq-ellipsis-text\">\r\n                  {{node.value(column.columnDef) }}\r\n                </span>\r\n              }\r\n            </td>\r\n          </ng-container>\r\n        }\r\n        <tr mat-header-row \r\n          *matHeaderRowDef=\"listColumnsDisplayed; sticky: true\" \r\n          class=\"mat-header-row esq-header-row\">\r\n        </tr>\r\n        <tr mat-row\r\n            *matRowDef=\"let node; let i = index; columns: listColumnsDisplayed;\" \r\n            class=\"mat-row esq-row\"\r\n            (contextmenu)=\"onListContextMenu($event, node)\"\r\n            (mouseover)=\"listNodeHoveredIndex = i\"\r\n            (mouseout)=\"listNodeHoveredIndex = -1\"\r\n            [ngClass]=\"{'esq-active-node-highlight': node === listNodeFocused && !treeOnFocus,  'esq-active-node-outlight': node === listNodeFocused && treeOnFocus, 'esq-mouse-node-highlight': listNodeHoveredIndex === i}\"\r\n            (click)=\"onListClick(node)\"\r\n            (dblclick)=\"onListDoubleClick(node)\"\r\n            (keydown)=\"onListKeydown($event, node, i)\"\r\n            (focus)=\"onListFocus(node)\"\r\n            (focusout)=\"onListFocusOut(node)\"\r\n            [tabindex]=\"node === listNodeFocused ? 0 : -1\"\r\n        >\r\n        </tr>  \r\n      </table>\r\n    </mat-sidenav-content>\r\n  </mat-sidenav-container>\r\n</div>  \r\n\r\n\r\n\r\n", styles: [".esq-explorer{position:relative;height:100%;min-height:0;box-sizing:border-box}.esq-explorer .esq-explorer-container{position:relative;height:100%}.esq-explorer .esq-toolbar{position:relative;top:0;height:48px;left:0;right:0;border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0;vertical-align:middle;font-size:9pt;font-weight:400;margin:0;display:grid;grid-template-columns:repeat(6,18px) auto repeat(var(--right-buttons-count, 3),18px);gap:4px}.esq-explorer .esq-toolbar .esq-icon-button{transform:scale(.75)!important}.esq-explorer .esq-toolbar .esq-path-bar{border:1px solid #ccc;border-radius:16px;box-shadow:inset 1px 1px 1px #00000080;background-color:#0000;padding-left:10px;margin-left:10px}.esq-explorer .esq-icon-button-raised{border:1px solid #ccc;box-shadow:2px 2px 5px #0003;background-color:#f0f0f0}.esq-explorer .esq-icon-button-downraised{border:1px solid #ccc;box-shadow:inset 1px 1px 1px #00000080}.esq-explorer .esq-toolbar-row{height:30px;border:4px black;background:#ebebeb80;justify-content:space-between}.esq-explorer .esq-ellipsis-cell{max-width:10px;overflow:hidden;-webkit-user-select:none!important;user-select:none!important;border:none!important}.esq-explorer .esq-ellipsis-text{white-space:nowrap;text-overflow:ellipsis;display:block}.esq-explorer .esq-elevation-z2{-webkit-user-select:none;user-select:none}.esq-explorer .esq-sidenav-container{position:absolute;inset:50px 0 0}.esq-explorer .esq-sidenav{display:flex;align-items:center;justify-content:center;white-space:nowrap;max-width:400px;min-width:100px;overflow:hidden}.esq-explorer .esq-tree-node{display:flex;align-items:start;flex-direction:column;font-size:12px;min-height:18px}.esq-explorer .esq-active-node-highlight{background-color:#add8e6}.esq-explorer .esq-active-node-outlight{background-color:#9df0c7}.esq-explorer .esq-mouse-node-highlight{background-color:#e8f5fa}.esq-explorer .esq-base-icon{position:relative;height:24px;width:24px;vertical-align:middle;bottom:0;left:0;z-index:1}.esq-explorer .esq-overlay-icon{position:relative;height:12px;width:12px;top:-4px;left:-6px;z-index:2}.esq-explorer .esq-overlay-text{font-size:9pt;font-weight:400;position:relative;bottom:0;left:-4px;z-index:3}.esq-explorer .esq-loading-icon{position:relative;height:16px;bottom:-4px;width:auto;display:block}.esq-explorer .esq-loading-div{position:relative;height:16px;left:4px;width:28px;display:block;background-position:right;background-repeat:no-repeat;background-image:url(data:image/gif;base64,R0lGODlhEAAQAHAAACH/C05FVFNDQVBFMi4wAwEAAAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQICAgODg4QEBAYGBgZGRkfHx8hISEkJCQlJSUxMTEyMjIzMzM0NDRERERHR0dcXFxfX19kZGRqampsbGxzc3N0dHR5eXl7e3uEhISGhoaOjo6WlpacnJyenp6fn5+goKCnp6evr6+ysrKzs7O0tLS6urq8vLy9vb2+vr7AwMDCwsLExMTFxcXKysrLy8vMzMzPz8/R0dHS0tLT09PU1NTV1dXW1tba2trc3Nzd3d3f39/g4ODj4+Pk5OTl5eXn5+fo6Ojp6enq6uru7u7v7+/w8PDy8vLz8/P19fX29vb6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlQD/CRxIsKDBgUgODiTRwcW/GiAU/gshAMADIUOCCIyxgmCSCwAAFKhBUESFIwRNJBggQYjEf0NQfEjR4+U/CwIQsFDIwcM/Gg1CjjgoJAIFIv82GHBgQ6GOgUVepJBhU6AMBQdEFFSRIQdBEgEAaPj3AsY/IxAClCD4A8OEGzsYEDjxD0YHHwaL/JuxoACKqntbHAwIACH5BAkKAP8ALAAAAAAQABAAhwQEBAYGBggICAoKCgsLCw0NDRUVFScnJyoqKjs7Ozw8PD4+PkBAQEFBQURERExMTFBQUFlZWWFhYW5ubm9vb3p6en9/f4CAgIGBgYKCgouLi4yMjJmZmZubm5ycnKKioqysrLCwsLW1tba2try8vL6+vr+/v8rKyszMzM3Nzc7Ozs/Pz9HR0dLS0tPT09TU1NbW1tjY2NnZ2dra2tvb29zc3N7e3uTk5Ojo6Onp6erq6u3t7e7u7vHx8fLy8vPz8/T09Pb29vf39/j4+Pr6+vz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiQAP8JHJhDxIgcAxMqvECAQAaFA3WMCBGDAQAADWJA/PehAIEKFQYIsPBPhYyEQzBclHCjRIkd/1ykUIjigQMSGxOW4LACR86BMBAAmJBTh4YW/4IGoDAk5wYWAk14gPFToRAXNDb2UHjiQIIZCkEQ1WnggIt/L14I7ABhps4T/2osUFBDoI2qESLcqDqw7saAACH5BAkKAP8ALAAAAAAQABAAhwQEBAUFBQYGBgcHBwkJCQ0NDRAQEBsbGyEhISMjIyUlJSsrKzQ0NDU1NTg4OEJCQkxMTFNTU1VVVVZWVmZmZmdnZ2hoaHV1dXZ2dnd3d3p6en9/f4CAgIODg4eHh4mJiYyMjI2NjaWlpampqaurq62trbm5ubq6uru7u729vcXFxcfHx8rKysvLy87Ozs/Pz9HR0dLS0tPT09XV1dbW1tfX19nZ2dra2tvb29zc3N3d3d7e3t/f3+Li4uPj4+Xl5ebm5urq6u7u7u/v7/Dw8PHx8fLy8vT09PX19fb29vj4+Pz8/P///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////wAAAAiXAP8JHPgvBw+CCAnKgOCgxD8lCf+pKAHkQwAAEWiAyMCCIAwFBTaIMCDgAoYBAB7oGMjiQIAMRVag6FEBAIAFOAYSIQEi58ATDBB48Dgk4owaRf8d4XCgQ0SBOg7+s0CAAsSIJlwI3DEixtOnSL4SFBJCww+ENEgkbJAAhsCz/1pQyIFQBQqBKSTYEChE7IkJN8QShIswIAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcQEBAREREWFhYaGhoeHh4pKSkqKiotLS00NDQ9PT1BQUFCQkJFRUVGRkZMTExSUlJYWFhbW1tnZ2dpaWlqampycnJ4eHh5eXl7e3uJiYmKioqMjIyRkZGYmJiZmZmampqenp6hoaGioqKjo6Onp6esrKyurq6wsLCzs7O3t7e7u7vFxcXHx8fKysrMzMzOzs7T09PU1NTV1dXW1tbY2NjZ2dna2trb29vc3Nzd3d3e3t7f39/g4ODi4uLj4+Pl5eXq6urr6+vt7e3v7+/w8PDy8vLz8/P09PT29vb39/f5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIlgD/CRz4T8gOgggJCqmAwAOShAJxwPhXwwAACDxSkNCBMEKBEkU0KBgBQkAADARxNBjwQWCPfxwCAJDwg6AMFUFsTnBw4qFAHxD/EUFBIUOOfyYYsAj6AAAAC0w2EBABkUYCpxH++WgxJCgIBAtWBEUo4wbBFyeKJKyRsMMBGQLV/osRIgnCHS4EzriQc+xAGi39Cv4XEAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUHBwcICAgKCgoREREVFRUnJycvLy8yMjI0NDQ4ODg9PT0+Pj5ERERHR0dJSUlUVFReXl5fX19kZGRsbGxtbW1ubm5wcHB1dXV4eHh8fHx/f3+FhYWKioqSkpKTk5OdnZ2ioqKlpaWmpqaoqKitra2zs7O0tLS4uLi5ubm8vLzAwMDHx8fIyMjLy8vNzc3Pz8/Q0NDR0dHS0tLU1NTV1dXW1tbZ2dna2trd3d3g4ODh4eHi4uLl5eXn5+fo6Ojq6urr6+vs7Ozt7e3u7u7v7+/w8PDx8fHy8vLz8/P09PT29vb39/f5+fn6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAInAD/CRz4zwfBgweJZHDAAuHAGjn+9UAg4AOTFiMiDpQBgQGOfyY62KiRgIAGgj8oROBBUMaBAReCoHSIwsMLJw4POjlBAQSRfy44aESoAECBFP9IKIDh8AYDAAZW/EvC0mGQEhhCGMkpEIaEByKUEKxhQqzAJBYCAGhQVaCKDQOb/KsAAMCCHQePCMQx4l+MCRBMcBWiQyBerogDAgAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUGBgYHBwcJCQkNDQ0QEBAVFRUcHBwgICAnJycuLi4zMzM9PT1AQEBFRUVOTk5QUFBSUlJXV1daWlpbW1tdXV1nZ2dtbW1zc3N3d3eBgYGDg4OEhISFhYWGhoaIiIiMjIyPj4+SkpKTk5OcnJyenp6fn5+hoaGioqKmpqaoqKiwsLC1tbW4uLi7u7u/v7/AwMDGxsbIyMjJycnKysrMzMzNzc3Pz8/Y2NjZ2dna2trb29vd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXm5ubq6urr6+vs7Ozt7e3u7u7v7+/w8PDy8vLz8/P09PT29vb39/f6+vr8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRwoMArBgwdjcMiBECGUDARQ/GNCBOELE0j+1RjxA4oIBiWkDISi4UFFghUEYDhohOFBGSBsNGw4JQiPgjOKzMTRYEGLfzskwJi5gkAADwJ9zAR6wcKNpf+arNjgwshBHQKH/FPyAgEACEAIFgnhpAcFBRpIGADg4CbBJv9IDABwQEWHCSxmpigAIEGNfycbEvkQ4QTCgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQFBQUPDw8UFBQVFRUXFxcYGBgeHh4mJiYoKCgyMjI0NDQ5OTk9PT0/Pz9AQEBISEhPT09XV1ddXV1gYGBkZGRqamp1dXV4eHiAgICCgoKKioqLi4uMjIyNjY2QkJCYmJiampqbm5ufn5+mpqanp6ewsLCzs7O1tbW3t7e4uLi6urq8vLy+vr6/v7/Dw8PFxcXJycnKysrLy8vQ0NDT09PU1NTW1tba2trb29vc3Nzd3d3e3t7f39/g4ODh4eHi4uLj4+Pk5OTl5eXn5+fp6enq6urr6+vs7Ozu7u7v7+/y8vLz8/P09PT29vb4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAImQD/CRxIsKBBgTdaMDlY0AkGBkAE+jC4Y4ZAGikEnoiwoqCJCgWfdCAAAgpBJUIM8kjxgyFDIgN7uNRhgUKOf0Q8pDwIo4AAFANNHizCIcPNf0pKaHBhsMcSgiYMAFhQw4lECwpGNBEI5UMAAANIaIAQosUBABIIymhgYIIIAgASsLjwgERBHC9yxEAAwIGNIEMWMlSxIYbBgAAh+QQJCgD/ACwAAAAAEAAQAIcEBAQHBwcMDAwPDw8SEhIUFBQVFRUWFhYaGhojIyMlJSUmJiYtLS00NDQ3Nzc6Ojo7Ozs8PDxMTExPT09ZWVlcXFxtbW1vb294eHh+fn6BgYGCgoKIiIiNjY2Ojo6UlJSVlZWYmJiZmZmenp6goKChoaGoqKirq6usrKywsLCxsbG1tbW4uLi5ubm8vLy9vb2+vr7AwMDDw8PFxcXHx8fIyMjMzMzPz8/T09PU1NTX19fa2trd3d3e3t7f39/g4ODi4uLj4+Pk5OTl5eXm5ubo6Ojr6+vs7Ozt7e3u7u7w8PDx8fHy8vLz8/P09PT29vb39/f4+Pj5+fn6+vr7+/v8/Pz///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8AAAAIoQD/CRxIsKBBgUeGHDxowgIRgUsMMnn4z0cNgSsw+CiIY4QTglJCSOBBMEqUg0eCEKThAUXEg1AE6ogA4ICKhSA2/HhhAAAAD1QMCnmgwAYQCgQYyDjopMWJJP90sPhAQofQgjkgCJiwY2CSDhUuDoxRAECCGTBQBOnRIICHJwN/XHCQIcWCAR6SiLBwo2CRHkZcIAig4Z+ShQKRlOBAsmBAADs=)}.esq-explorer .esq-table{width:100%}.esq-explorer .esq-header-row{font-size:9pt;font-weight:400;height:18px;background-color:#f5f5f5;padding-bottom:2px}.esq-explorer .esq-row{font-size:9pt;font-weight:400;height:16px;border-bottom:none}.esq-explorer .esq-context-menu-anchor{position:fixed;z-index:10000;width:1px;height:1px;pointer-events:none}.esq-menu-item{line-height:1!important;min-height:12px!important}.esq-menu-grid{display:grid;grid-template-columns:120px 1fr;margin:0;height:12px}.esq-menu-label{font-size:9pt}.esq-menu-hotkey{font-size:9pt;color:#888}.esq-menu-icon{position:relative;height:18px!important;width:18px!important;vertical-align:middle;bottom:0;left:0;margin-right:4px!important;z-index:1}\n"] }]
        }], ctorParameters: () => [{ type: i1.MatDialog }], propDecorators: { esqRestApi: [{
                type: Input
            }], esqExplorerCallApi: [{
                type: Input
            }], esqCommandMenuItems: [{
                type: Input
            }], esqAccessProfile: [{
                type: Input
            }], esqDatasource: [{
                type: Input
            }], esqSubItemDisabled: [{
                type: Input
            }], _tree: [{
                type: ViewChild,
                args: ['EsqExplTree']
            }], sidenav: [{
                type: ViewChild,
                args: ['EsqSidenav']
            }], contextMenuTrigger: [{
                type: ViewChild,
                args: ['contextMenuTrigger', { read: MatMenuTrigger }]
            }], menuItemOpen: [{
                type: ViewChild,
                args: ['menuItemOpen', { read: ElementRef }]
            }], menuItemDetails: [{
                type: ViewChild,
                args: ['menuItemDetails', { read: ElementRef }]
            }], matRows: [{
                type: ViewChildren,
                args: [MatRow, { read: ElementRef }]
            }] } });

/*
*  Esquire frameworks (tm)
*
*  Copyright(c) 2001, 2025 mir0n&co www.mir0n.me
*  mailto:mir0n.the.programmer@gmail.com
*
*  History:
* 04/17/2026 mir0n  export EsqFlatTreeSelector, EsqFlatTreeDatasource, EsqSelectEntityDialog
*/
//export const eeee = 'eeee';
//export * from './EsqTreeViewDatasource';
//export * from './EsqListViewDatasource';
//export * from './EsqFlatTreeDatasource';

/**
 * Generated bundle index. Do not edit.
 */

export { EsqExplorerComponent, EsqFlatTreeDatasource, EsqSelectEntityDialog };
//# sourceMappingURL=mir0n-pro-esquire.ui-explorer-flatTree.mjs.map
